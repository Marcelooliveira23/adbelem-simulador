"""
Aplicação Flask da Intranet AD Belém (API + arquivos do frontend).

Não rode este arquivo diretamente em produção: use `iniciar.py` (servidor waitress),
o EXE instalado, ou `wsgi.py` em hospedagens como o PythonAnywhere.
Para desenvolvimento: python src/backend/servidor.py  (modo debug, só nesta máquina)
"""
import os
import time
from datetime import datetime, timedelta

from flask import Flask, request, jsonify, send_from_directory, redirect
from flask_cors import CORS
from flask_jwt_extended import JWTManager, jwt_required

from app.auth_utils import criar_token, usuario_atual, requer_permissao, escopo_congregacao
from app.config import FRONTEND_DIR, chave_secreta
from app.database import DB_PATH, get_db, inicializar_banco
from app.models import Usuario, Perfil, Permissao
from app.routes.membros import registrar_membros
from app.routes.financeiro import registrar_financeiro
from app.routes.patrimonio import registrar_patrimonio
from app.routes.relatorios import registrar_relatorios
from app.routes.modulos import registrar_modulos
from app.routes.sistema import registrar_sistema
from app.routes.tesouraria_extra import registrar_tesouraria_extra
from app.routes.banco import registrar_banco
from app.routes.acertos import registrar_acertos
from app.routes.compras_estoque import registrar_compras_estoque
from app.routes.secretaria_extra import registrar_secretaria_extra
from app.routes.gestao import registrar_gestao
from app.routes.seguranca_rotas import registrar_seguranca
from app.routes.gestao2 import registrar_gestao2
from app.routes.tryout import registrar_tryout
from app.routes.pessoal import registrar_pessoal
from app.routes.importar import registrar_importar
from app.routes.docs import registrar_docs
from app.routes.perfis import registrar_perfis
from app.seguranca import (aplicar_cabecalhos, configurar_jwt, registrar_acesso, verificar_totp,
                           MAX_FALHAS_CONTA, BLOQUEIO_MIN)


app = Flask(__name__)
app.config['SECRET_KEY'] = chave_secreta()   # aleatória e persistente (nunca a do .env.example)
app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY') or app.config['SECRET_KEY']
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(
    seconds=int(os.environ.get('JWT_ACCESS_TOKEN_EXPIRES', 12 * 3600)))
app.json.ensure_ascii = False

# CORS só para origens configuradas (o frontend é servido pelo próprio servidor, mesma origem)
if os.environ.get('CORS_ORIGINS'):
    CORS(app, origins=[o.strip() for o in os.environ['CORS_ORIGINS'].split(',') if o.strip()])
jwt = JWTManager(app)
configurar_jwt(jwt)
aplicar_cabecalhos(app)


# Respostas JSON padronizadas para problemas de token (o frontend redireciona ao login)
@jwt.expired_token_loader
def _token_expirado(_header, _payload):
    return jsonify({'erro': 'Sessão expirada. Faça login novamente.'}), 401


@jwt.invalid_token_loader
@jwt.unauthorized_loader
def _token_invalido(motivo):
    return jsonify({'erro': 'Não autenticado', 'detalhe': motivo}), 401


# ============= AUTENTICAÇÃO =============

# Proteção contra tentativas de senha em massa: 8 erros em 15 minutos bloqueiam (por IP + e-mail)
_FALHAS_LOGIN = {}
LIMITE_FALHAS, JANELA_SEG = 8, 15 * 60


def _ip_cliente():
    return (request.headers.get('X-Real-IP') or request.headers.get('X-Forwarded-For', '').split(',')[0].strip()
            or request.remote_addr or '?')


@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json(silent=True) or {}
    email = (data.get('email') or '').strip().lower()
    senha = data.get('senha') or data.get('password')

    if not email or not senha:
        return jsonify({'erro': 'Email e senha são obrigatórios'}), 400

    chave = (_ip_cliente(), email)
    agora = time.time()
    falhas = [t for t in _FALHAS_LOGIN.get(chave, []) if agora - t < JANELA_SEG]
    if len(falhas) >= LIMITE_FALHAS:
        return jsonify({'erro': 'Muitas tentativas. Aguarde 15 minutos e tente de novo.'}), 429

    conn = get_db()
    try:
        usuario = conn.execute(
            'SELECT * FROM usuarios WHERE lower(email) = ? AND ativo = 1', (email,)).fetchone()
    finally:
        conn.close()

    ip, agente = _ip_cliente(), request.headers.get('User-Agent', '')

    def _falha(motivo, msg='Email ou senha inválidos', codigo=401, extra=None):
        _FALHAS_LOGIN[chave] = falhas + [agora]
        conn_f = get_db()
        try:
            if usuario:
                n = (usuario['falhas_login'] or 0) + 1
                bloq = (datetime.now() + timedelta(minutes=BLOQUEIO_MIN)).isoformat(timespec='seconds') \
                    if n >= MAX_FALHAS_CONTA else None
                conn_f.execute('UPDATE usuarios SET falhas_login = ?, bloqueado_ate = COALESCE(?, bloqueado_ate) WHERE id = ?',
                               (0 if bloq else n, bloq, usuario['id']))
            registrar_acesso(conn_f, email, usuario['id'] if usuario else None, False, motivo, ip, agente)
            conn_f.commit()
        finally:
            conn_f.close()
        return jsonify({'erro': msg, **(extra or {})}), codigo

    if usuario and usuario['bloqueado_ate'] and usuario['bloqueado_ate'] > datetime.now().isoformat(timespec='seconds'):
        return jsonify({'erro': f'Conta bloqueada por excesso de tentativas. Tente após '
                                f"{usuario['bloqueado_ate'][11:16]} ou peça ao administrador para desbloquear."}), 423
    if not usuario or not Usuario.verificar_senha(senha, usuario['senha_hash']):
        return _falha('senha incorreta' if usuario else 'e-mail não cadastrado')
    if usuario['totp_ativo']:
        codigo = data.get('codigo')
        if not codigo:
            return jsonify({'erro': 'Informe o código do aplicativo autenticador', 'precisa_2fa': True}), 401
        if not verificar_totp(usuario['totp_segredo'], codigo):
            return _falha('código 2FA incorreto', 'Código de verificação inválido', 401, {'precisa_2fa': True})
    _FALHAS_LOGIN.pop(chave, None)
    conn = get_db()
    try:
        conn.execute("UPDATE usuarios SET falhas_login = 0, bloqueado_ate = NULL, ultimo_login = ? WHERE id = ?",
                     (datetime.now().isoformat(timespec='seconds'), usuario['id']))
        registrar_acesso(conn, email, usuario['id'], True, '2FA' if usuario['totp_ativo'] else 'senha', ip, agente)
        conn.commit()
    finally:
        conn.close()

    perfil = Perfil.obter(usuario['perfil_id']) or {}
    return jsonify({
        'access_token': criar_token(usuario),
        'usuario': {
            'id': usuario['id'],
            'nome': usuario['nome'],
            'email': usuario['email'],
            'perfil': perfil.get('nome', 'Desconhecido'),
            'perfil_id': usuario['perfil_id'],
        },
        'trocar_senha': bool(usuario['trocar_senha']),
        '2fa': bool(usuario['totp_ativo']),
    }), 200


@app.route('/api/auth/perfis', methods=['GET'])
def listar_perfis():
    perfis = [{'id': pid, 'nome': p['nome'], 'descricao': p.get('descricao', '')}
              for pid, p in Perfil.listar().items()]
    return jsonify({'perfis': perfis}), 200


@app.route('/api/auth/verificar', methods=['GET'])
@jwt_required()
def verificar_token():
    return jsonify({'valido': True, 'usuario': usuario_atual()}), 200


@app.route('/api/auth/logout', methods=['POST'])
@jwt_required()
def logout():
    return jsonify({'msg': 'Logout realizado com sucesso'}), 200


# ============= USUÁRIOS =============

@app.route('/api/users/me', methods=['GET'])
@jwt_required()
def obter_usuario_atual():
    conn = get_db()
    try:
        u = conn.execute('SELECT * FROM usuarios WHERE id = ? AND ativo = 1',
                         (usuario_atual()['id'],)).fetchone()
    finally:
        conn.close()
    if not u:
        return jsonify({'erro': 'Usuário não encontrado'}), 404

    perfil = Perfil.obter(u['perfil_id']) or {}
    return jsonify({
        'id': u['id'], 'nome': u['nome'], 'email': u['email'],
        'perfil': perfil.get('nome', 'Desconhecido'), 'perfil_id': u['perfil_id'],
        'ativo': u['ativo'], 'criado_em': str(u['criado_em']),
    }), 200


@app.route('/api/users/listar', methods=['GET'])
@requer_permissao('usuarios.listar')
def listar_usuarios():
    conn = get_db()
    try:
        rows = conn.execute('''
            SELECT id, nome, email, perfil_id, ativo, criado_em
            FROM usuarios WHERE ativo = 1 ORDER BY nome''').fetchall()
    finally:
        conn.close()
    usuarios = []
    for u in rows:
        item = dict(u)
        item['perfil'] = (Perfil.obter(u['perfil_id']) or {}).get('nome', 'Desconhecido')
        item['criado_em'] = str(u['criado_em'])
        usuarios.append(item)
    return jsonify({'usuarios': usuarios}), 200


# ============= DASHBOARD =============

# Módulos da intranet (mesma numeração do protótipo aprovado).
# O nome é o prefixo usado nas permissões dos perfis (ex.: 'tesouraria.criar').
MODULOS = ['tesouraria', 'secretaria', 'membros', 'patrimonio', 'compras', 'congregacoes', 'relatorios', 'admin']
ACOES = ['consultar', 'criar', 'editar', 'deletar', 'aprovar', 'contribuintes', 'banco', 'pasta', 'auditoria']


def _nivel(user, modulo):
    """'C' = acesso completo, 'V' = somente consulta, None = sem acesso."""
    if not Permissao.tem_acesso(user, f'{modulo}.consultar'):
        return None
    pode_alterar = any(Permissao.tem_acesso(user, f'{modulo}.{a}') for a in ('criar', 'editar', 'deletar'))
    if pode_alterar and user.get('escopo') == 'congregacao':
        return 'E'   # lança só na própria congregação
    return 'C' if pode_alterar else 'V'


@app.route('/api/dashboard/permissoes', methods=['GET'])
@jwt_required()
def obter_permissoes():
    user = usuario_atual()
    permissoes = [
        {'modulo': modulo, 'acao': acao,
         'tem_acesso': Permissao.tem_acesso(user, f'{modulo}.{acao}')}
        for modulo in MODULOS
        for acao in ACOES
    ]
    niveis = {m: _nivel(user, m) for m in MODULOS}
    modulos = [m for m in MODULOS if niveis[m]]
    return jsonify({'usuario': user, 'permissoes': permissoes,
                    'niveis': niveis, 'modulos': modulos}), 200


@app.route('/api/dashboard/resumo', methods=['GET'])
@jwt_required()
def resumo_dashboard():
    """KPIs do dashboard. Cada número só é enviado se o perfil puder consultá-lo."""
    user = usuario_atual()
    pode = lambda acao: Permissao.tem_acesso(user, acao)  # noqa: E731

    cong = escopo_congregacao(user)
    # Só o que tem "de acordo"; dirigente vê apenas a própria congregação
    filtro = "COALESCE(aprovacao, 'aprovado') = 'aprovado'" + (f' AND congregacao_id = {int(cong)}' if cong is not None else '')

    conn = get_db()
    try:
        def valor(sql):
            return conn.execute(sql).fetchone()[0] or 0

        kpis = {
            'usuarios': valor('SELECT COUNT(*) FROM usuarios WHERE ativo = 1')
            if pode('admin.consultar') else None,
            'membros': valor(f"SELECT COUNT(*) FROM membros WHERE {filtro} AND status != 'inativo'")
            if pode('membros.consultar') else None,
            'saldo': round(valor(
                "SELECT COALESCE(SUM(CASE WHEN tipo = 'receita' THEN valor ELSE -valor END), 0) "
                f"FROM financeiro WHERE {filtro}"), 2) if pode('tesouraria.consultar') else None,
            'patrimonio': valor(f"SELECT COUNT(*) FROM patrimonio WHERE {filtro} AND status != 'descartado'")
            if pode('patrimonio.consultar') else None,
            'despesas_pendentes': valor(
                f"SELECT COUNT(*) FROM financeiro WHERE {filtro} AND tipo = 'despesa' AND status = 'pendente'")
            if pode('tesouraria.consultar') else None,
            'bens_manutencao': valor(f"SELECT COUNT(*) FROM patrimonio WHERE {filtro} AND status = 'manutencao'")
            if pode('patrimonio.consultar') else None,
        }
    finally:
        conn.close()

    return jsonify({'usuario': user['nome'], 'perfil': user['perfil'], 'kpis': kpis}), 200


# ============= SAÚDE / FRONTEND =============

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'message': 'Intranet AD Belém online', 'db': 'SQLite'}), 200


@app.route('/')
def index():
    return redirect('/frontend/login.html')


@app.route('/frontend/')
def frontend_index():
    return redirect('/frontend/login.html')


@app.route('/frontend/<path:filename>')
def servir_frontend(filename):
    return send_from_directory(FRONTEND_DIR, filename)


# ============= MÓDULOS =============
registrar_membros(app)
registrar_financeiro(app)
registrar_patrimonio(app)
registrar_relatorios(app)
registrar_modulos(app)
registrar_sistema(app)
registrar_tesouraria_extra(app)
registrar_banco(app)
registrar_acertos(app)
registrar_compras_estoque(app)
registrar_secretaria_extra(app)
registrar_gestao(app)
registrar_seguranca(app)
registrar_gestao2(app)
registrar_tryout(app)
registrar_pessoal(app)
registrar_importar(app)
registrar_docs(app)
registrar_perfis(app)


# ============= ERROS =============

@app.errorhandler(404)
def not_found(_error):
    return jsonify({'erro': 'Recurso não encontrado'}), 404


@app.errorhandler(405)
def method_not_allowed(_error):
    return jsonify({'erro': 'Método não permitido'}), 405


@app.errorhandler(500)
def internal_error(_error):
    return jsonify({'erro': 'Erro interno do servidor'}), 500


if __name__ == '__main__':
    # Desenvolvimento local apenas (debug ligado, acessível só nesta máquina)
    from app.seed import garantir_usuarios_teste
    inicializar_banco()
    garantir_usuarios_teste()
    print(f"Desenvolvimento: http://127.0.0.1:5000  |  banco: {DB_PATH}")
    app.run(debug=True, port=5000, host='127.0.0.1')
