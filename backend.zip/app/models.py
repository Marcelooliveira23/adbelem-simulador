"""Modelos de banco de dados"""
from werkzeug.security import generate_password_hash, check_password_hash

class Usuario:
    """Modelo de usuário"""
    
    @staticmethod
    def criar_hash_senha(senha):
        """Gera hash seguro da senha (scrypt; PBKDF2-SHA256 onde o scrypt não existe, como no simulador web)."""
        import hashlib
        if hasattr(hashlib, 'scrypt'):
            return generate_password_hash(senha)
        return generate_password_hash(senha, method='pbkdf2:sha256:600000')
    
    @staticmethod
    def verificar_senha(senha, hash_senha):
        """Verifica se a senha é válida"""
        return check_password_hash(hash_senha, senha)
    
    @staticmethod
    def criar(conexao, nome, email, senha, perfil_id):
        """Criar novo usuário"""
        cursor = conexao.cursor()
        hash_senha = Usuario.criar_hash_senha(senha)
        
        try:
            cursor.execute("""
                INSERT INTO usuarios (nome, email, senha_hash, perfil_id, ativo, criado_em)
                VALUES (?, ?, ?, ?, 1, datetime('now'))
            """, (nome, email, hash_senha, perfil_id))
            conexao.commit()
            return True
        except Exception as e:
            conexao.rollback()
            return False
    
    @staticmethod
    def buscar_por_email(conexao, email):
        """Buscar usuário pelo email"""
        cursor = conexao.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE email = ? AND ativo = 1", (email,))
        return cursor.fetchone()
    
    @staticmethod
    def buscar_por_id(conexao, usuario_id):
        """Buscar usuário pelo ID"""
        cursor = conexao.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE id = ? AND ativo = 1", (usuario_id,))
        return cursor.fetchone()

class Perfil:
    """Modelo de perfil de acesso"""
    
    # Matriz de acesso (escopo atual: Financeiro, Secretaria, Patrimônio + Presidência).
    # 'modulo.*' = completo; 'modulo.consultar' = só leitura. Ações especiais: aprovar ("de acordo"),
    # contribuintes (ver quem dizimou), banco (configurar a integração bancária).
    # Os números dos perfis são fixos: usuários já cadastrados guardam o número.
    # Presidência (Pastor Presidente e Vice): SOMENTE CONSULTA em todas as áreas, sem alterar nada.
    # Vê relatórios, o log de ações e a lista de usuários; não vê quem dizimou (sigilo da Tesouraria).
    _PRESIDENCIA = ['tesouraria.consultar', 'membros.consultar', 'congregacoes.consultar', 'secretaria.consultar',
                    'patrimonio.consultar', 'relatorios.consultar', 'admin.consultar', 'compras.consultar']
    _PEDE_COMPRAS = ['compras.consultar', 'compras.criar', 'compras.editar']   # pede; quem aprova é o Financeiro
    # pasta: a que departamento o perfil pertence. admin_pasta: o chefe da pasta pode dar/remover acessos
    # (somente perfis da própria pasta), para quando o Administrador de TI estiver indisponível.
    _ADMIN_PASTA = ['admin.consultar', 'admin.pasta']
    PERFIS = {
        1: {'nome': 'Administrador (TI)', 'permissoes': ['*'], 'pasta': None,
            'descricao': 'Acesso total: usuários de todas as pastas, configurações, backup e todos os módulos'},
        2: {'nome': 'Pastor Presidente', 'permissoes': _PRESIDENCIA + ['admin.auditoria'], 'pasta': None,
            'descricao': 'Somente consulta: vê todas as áreas, relatórios e o log de ações, sem alterar nada'},
        12: {'nome': 'Vice-Presidente', 'permissoes': _PRESIDENCIA + ['admin.auditoria'], 'pasta': None,
             'descricao': 'Mesmo acesso do Pastor Presidente'},
        # ---- Tesouraria ----
        3: {'nome': 'Tesoureiro (chefe)', 'pasta': 'tesouraria', 'admin_pasta': True,
            'permissoes': ['tesouraria.*', 'relatorios.*', 'congregacoes.consultar', 'membros.consultar', 'patrimonio.consultar',
                           'compras.consultar', 'compras.aprovar'] + _ADMIN_PASTA,
            'descricao': 'Financeiro completo, "de acordo", contribuintes, banco e aprovação de compras; administra os acessos da Tesouraria'},
        13: {'nome': 'Tesoureiro auxiliar', 'pasta': 'tesouraria',
             'permissoes': ['tesouraria.consultar', 'tesouraria.criar', 'tesouraria.editar', 'relatorios.consultar',
                            'congregacoes.consultar', 'membros.consultar'],
             'descricao': 'Lança receitas, despesas, caixa e acertos; não aprova, não exclui e não vê contribuintes'},
        14: {'nome': 'Consulta da Tesouraria', 'pasta': 'tesouraria',
             'permissoes': ['tesouraria.consultar', 'relatorios.consultar'],
             'descricao': 'Somente consulta da Tesouraria (ex.: contador, conselho)'},
        # ---- Secretaria ----
        4: {'nome': 'Secretário (chefe)', 'pasta': 'secretaria', 'admin_pasta': True,
            'permissoes': ['membros.*', 'secretaria.*', 'congregacoes.*', 'relatorios.*', 'patrimonio.consultar']
                          + _PEDE_COMPRAS + _ADMIN_PASTA,
            'descricao': 'Membros, cartas, modelos, arquivo digital, contratos e compras; administra os acessos da Secretaria'},
        15: {'nome': 'Secretário auxiliar', 'pasta': 'secretaria',
             'permissoes': ['membros.consultar', 'membros.criar', 'membros.editar', 'secretaria.consultar', 'secretaria.criar',
                            'secretaria.editar', 'congregacoes.consultar', 'relatorios.consultar', 'compras.consultar'],
             'descricao': 'Cadastra e edita membros, emite documentos e envia arquivos; não exclui nem altera modelos'},
        16: {'nome': 'Consulta da Secretaria', 'pasta': 'secretaria',
             'permissoes': ['membros.consultar', 'secretaria.consultar', 'congregacoes.consultar', 'relatorios.consultar'],
             'descricao': 'Somente consulta de membros e documentos'},
        # ---- Patrimônio ----
        5: {'nome': 'Patrimônio (chefe)', 'pasta': 'patrimonio', 'admin_pasta': True,
            'permissoes': ['patrimonio.*', 'relatorios.*', 'congregacoes.consultar'] + _PEDE_COMPRAS + _ADMIN_PASTA,
            'descricao': 'Bens, almoxarifado e pedidos de compra; administra os acessos do Patrimônio'},
        17: {'nome': 'Patrimônio auxiliar', 'pasta': 'patrimonio',
             'permissoes': ['patrimonio.consultar', 'patrimonio.criar', 'patrimonio.editar', 'congregacoes.consultar',
                            'relatorios.consultar', 'compras.consultar'],
             'descricao': 'Registra bens, entradas e saídas de material; não exclui'},
        18: {'nome': 'Consulta do Patrimônio', 'pasta': 'patrimonio',
             'permissoes': ['patrimonio.consultar', 'relatorios.consultar'],
             'descricao': 'Somente consulta do patrimônio e do almoxarifado'},
    }

    @staticmethod
    def pasta_que_administra(usuario):
        """Pasta cujos acessos o usuário pode administrar ('*' = todas, None = nenhuma)."""
        if Permissao.tem_acesso(usuario, 'admin.criar'):
            return '*'
        perfil = Perfil.obter(usuario.get('perfil_id')) or {}
        return perfil.get('pasta') if perfil.get('admin_pasta') else None

    @staticmethod
    def obter(perfil_id):
        """Obter info do perfil"""
        return Perfil.PERFIS.get(perfil_id)
    
    @staticmethod
    def listar():
        """Listar todos os perfis"""
        return Perfil.PERFIS

class Permissao:
    """Verificação de permissões"""
    
    @staticmethod
    def tem_acesso(usuario, acao):
        """Verificar se usuário tem permissão para ação"""
        if not usuario or not usuario.get('perfil_id'):
            return False
        
        perfil = Perfil.obter(usuario.get('perfil_id'))
        if not perfil:
            return False
        
        permissoes = perfil.get('permissoes', [])
        
        # Admin tem acesso a tudo
        if '*' in permissoes:
            return True
        
        # Verificar permissão exata ou wildcard
        if '.' in acao:
            modulo = acao.split('.')[0]
            return acao in permissoes or f"{modulo}.*" in permissoes
        
        return acao in permissoes
