"""Utilitários de autenticação/autorização.

O token JWT guarda o id do usuário como `sub` (string, exigido pelo PyJWT >= 2.10)
e os demais dados (nome, perfil) como claims adicionais.
"""
from functools import wraps

from flask import jsonify
from flask_jwt_extended import create_access_token, get_jwt, jwt_required

from app.models import Perfil, Permissao


def criar_token(usuario):
    """Gera o token JWT para uma linha da tabela `usuarios`."""
    perfil = Perfil.obter(usuario['perfil_id']) or {}
    claims = {
        'nome': usuario['nome'],
        'email': usuario['email'],
        'perfil_id': usuario['perfil_id'],
        'perfil': perfil.get('nome', 'Desconhecido'),
        'congregacao_id': usuario['congregacao_id'] if 'congregacao_id' in usuario.keys() else None,
        'tv': (usuario['token_versao'] if 'token_versao' in usuario.keys() else 0) or 0,
        'ts': bool(usuario['trocar_senha']) if 'trocar_senha' in usuario.keys() else False,
    }
    return create_access_token(identity=str(usuario['id']), additional_claims=claims)


def usuario_atual():
    """Dados do usuário autenticado (dict com id, nome, email, perfil_id, perfil)."""
    claims = get_jwt()
    return {
        'id': int(claims['sub']),
        'nome': claims.get('nome'),
        'email': claims.get('email'),
        'perfil_id': claims.get('perfil_id'),
        'perfil': claims.get('perfil'),
        'congregacao_id': claims.get('congregacao_id'),
        'escopo': (Perfil.obter(claims.get('perfil_id')) or {}).get('escopo'),
    }


def escopo_congregacao(user=None):
    """Id da congregação à qual o usuário está restrito, ou None se vê tudo."""
    user = user or usuario_atual()
    if user.get('escopo') == 'congregacao':
        return user.get('congregacao_id') or -1   # sem congregação definida: não vê nada
    return None


def requer_permissao(acao):
    """Decorator: exige JWT válido e a permissão `acao` (ex.: 'membros.criar')."""
    def decorator(fn):
        @wraps(fn)
        @jwt_required()
        def wrapper(*args, **kwargs):
            if get_jwt().get('ts'):
                return jsonify({'erro': 'Troque sua senha provisória para continuar', 'trocar_senha': True}), 403
            if not Permissao.tem_acesso(usuario_atual(), acao):
                return jsonify({'erro': 'Sem permissão para esta ação'}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def requer_login(fn):
    """Exige apenas estar logado (e já ter trocado a senha provisória)."""
    @wraps(fn)
    @jwt_required()
    def wrapper(*args, **kwargs):
        if get_jwt().get('ts'):
            return jsonify({'erro': 'Troque sua senha provisória para continuar', 'trocar_senha': True}), 403
        return fn(*args, **kwargs)
    return wrapper
