"""Controles contábeis compartilhados: plano de contas e bloqueio de meses fechados."""
from app.database import get_db


def competencia_de(data):
    """'2026-11-18' -> '2026-11'."""
    return (data or '')[:7]


def periodo_fechado(conn, data):
    """True se o mês da data já foi fechado pela Tesouraria (nada mais pode ser lançado, alterado ou excluído)."""
    if not data:
        return False
    return conn.execute('SELECT 1 FROM periodos_fechados WHERE competencia = ?', (competencia_de(data),)).fetchone() is not None


def msg_fechado(data):
    c = competencia_de(data)
    return (f'O mês {c[5:7]}/{c[:4]} já foi fechado pela Tesouraria. '
            'Para corrigir, o chefe da Tesouraria precisa reabrir o mês (fica registrado no log).')


def categorias_validas(tipo, conn=None):
    """Chaves aceitas como categoria (plano de contas ativo do tipo)."""
    proprio = conn is None
    conn = conn or get_db()
    try:
        return {r[0] for r in conn.execute('SELECT chave FROM plano_contas WHERE tipo = ? AND ativo = 1', (tipo,))}
    finally:
        if proprio:
            conn.close()
