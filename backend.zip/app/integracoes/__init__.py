"""Integrações externas (bancos)."""
