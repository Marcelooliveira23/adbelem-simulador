"""Cliente da API Pix do Banco do Brasil (padrão Pix do Banco Central).

Modo de uso previsto no servidor da igreja: CONSULTA PERIÓDICA (polling).
A cada N minutos o servidor pede ao BB os PIX recebidos no período e registra os novos.
Não é preciso expor o servidor à internet.

⚠️ CONFIRMAR NO PORTAL DO BB (developers.bb.com.br) antes de ligar em homologação/produção:
   - URLs de OAuth e da API (abaixo há valores padrão que devem ser conferidos);
   - nome do parâmetro da chave da aplicação (gw-dev-app-key em homologação / gw-app-key em produção);
   - escopos (ex.: pix.read) e a exigência de certificado (mTLS) em produção.
Estes valores ficam na configuração do sistema (Financeiro > Banco do Brasil > Configurar), não no código.
"""
import base64
import json
import ssl
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

PADROES = {
    'homologacao': {
        'oauth_url': 'https://oauth.hm.bb.com.br/oauth/token',
        'api_url': 'https://api.hm.bb.com.br/pix/v2',
        'param_chave_app': 'gw-dev-app-key',
    },
    'producao': {
        'oauth_url': 'https://oauth.bb.com.br/oauth/token',
        'api_url': 'https://api-pix.bb.com.br/pix/v2',
        'param_chave_app': 'gw-app-key',
    },
}


class ErroBanco(Exception):
    pass


class ClientePixBB:
    def __init__(self, modo, client_id, client_secret, chave_app, oauth_url=None, api_url=None,
                 param_chave_app=None, cert_path=None, key_path=None, escopo='pix.read', timeout=30):
        if modo not in PADROES:
            raise ErroBanco("Modo deve ser 'homologacao' ou 'producao'")
        base = PADROES[modo]
        self.oauth_url = oauth_url or base['oauth_url']
        self.api_url = (api_url or base['api_url']).rstrip('/')
        self.param_chave_app = param_chave_app or base['param_chave_app']
        self.client_id, self.client_secret, self.chave_app = client_id, client_secret, chave_app
        self.escopo, self.timeout = escopo, timeout
        self.ctx = ssl.create_default_context()
        if cert_path and key_path:              # mTLS (certificado da empresa cadastrado no BB)
            self.ctx.load_cert_chain(cert_path, key_path)
        self._token, self._expira = None, datetime.min.replace(tzinfo=timezone.utc)

    # ---------- HTTP ----------
    def _req(self, metodo, url, dados=None, cabecalhos=None):
        req = urllib.request.Request(url, data=dados, method=metodo, headers=cabecalhos or {})
        try:
            with urllib.request.urlopen(req, context=self.ctx, timeout=self.timeout) as r:
                return json.loads(r.read().decode('utf-8') or '{}')
        except urllib.error.HTTPError as e:
            corpo = e.read().decode('utf-8', 'replace')[:300]
            raise ErroBanco(f'BB respondeu {e.code}: {corpo}') from e
        except urllib.error.URLError as e:
            raise ErroBanco(f'Sem conexão com o BB: {e.reason}') from e

    def token(self):
        agora = datetime.now(timezone.utc)
        if self._token and agora < self._expira:
            return self._token
        basic = base64.b64encode(f'{self.client_id}:{self.client_secret}'.encode()).decode()
        dados = urllib.parse.urlencode({'grant_type': 'client_credentials', 'scope': self.escopo}).encode()
        r = self._req('POST', self.oauth_url, dados, {
            'Authorization': f'Basic {basic}', 'Content-Type': 'application/x-www-form-urlencoded'})
        if 'access_token' not in r:
            raise ErroBanco('O BB não devolveu o token de acesso')
        self._token = r['access_token']
        self._expira = agora + timedelta(seconds=int(r.get('expires_in', 600)) - 60)
        return self._token

    # ---------- Pix recebidos (padrão BACEN: GET /pix?inicio=&fim=) ----------
    def pix_recebidos(self, inicio, fim):
        """Lista os PIX recebidos entre `inicio` e `fim` (datetime com fuso). Percorre todas as páginas."""
        pagina, total_paginas, itens = 0, 1, []
        while pagina < total_paginas:
            qs = urllib.parse.urlencode({
                'inicio': inicio.isoformat(timespec='seconds'), 'fim': fim.isoformat(timespec='seconds'),
                'paginacao.paginaAtual': pagina, self.param_chave_app: self.chave_app})
            r = self._req('GET', f'{self.api_url}/pix?{qs}', cabecalhos={'Authorization': f'Bearer {self.token()}'})
            itens.extend(r.get('pix', []))
            pag = (r.get('parametros') or {}).get('paginacao') or {}
            total_paginas = int(pag.get('quantidadeDePaginas', 1) or 1)
            pagina += 1
        return itens


def normalizar_pix(pix):
    """Converte um item Pix do padrão BACEN no formato interno de movimento."""
    pagador = pix.get('pagador') or {}
    doc = pagador.get('cpf') or pagador.get('cnpj') or ''
    return {
        'tipo': 'pix',
        'identificador': pix['endToEndId'],
        'txid': pix.get('txid'),
        'valor': round(float(pix['valor']), 2),
        'horario': pix.get('horario'),
        'pagador_nome': (pagador.get('nome') or '').strip(),
        'pagador_documento': mascarar_documento(doc),
        'mensagem': (pix.get('infoPagador') or '').strip(),
    }


def mascarar_documento(doc):
    """LGPD: guarda só parte do CPF/CNPJ (ex.: ***.456.789-**)."""
    d = ''.join(ch for ch in str(doc) if ch.isdigit())
    if len(d) == 11:
        return f'***.{d[3:6]}.{d[6:9]}-**'
    if len(d) == 14:
        return f'**.{d[2:5]}.{d[5:8]}/****-**'
    return ''
