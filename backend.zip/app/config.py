"""Caminhos e configurações da aplicação (código-fonte, EXE instalado ou hospedagem).

- Código-fonte:   dados em <projeto>/dados/
- EXE instalado:  dados em %PROGRAMDATA%\\IntranetADBelem\\   (sobrevive a atualizações do programa)
- Qualquer caso:  a variável de ambiente DATA_DIR (ou SQLITE_PATH, só para o banco) tem prioridade.
"""
import os
import sys

CONGELADO = getattr(sys, 'frozen', False)
PORTATIL = False          # True quando roda como EXE (PyInstaller)

if CONGELADO:
    PASTA_PROGRAMA = getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
    FRONTEND_DIR = os.path.join(PASTA_PROGRAMA, 'frontend')
    _dados_padrao = os.path.join(os.environ.get('PROGRAMDATA', os.path.expanduser('~')), 'IntranetADBelem')
    # Versão portátil (pendrive / WhatsApp, para aprovação): "portatil.txt" ao lado do EXE -> dados na pasta do programa
    PASTA_EXE = os.path.dirname(sys.executable)
    PORTATIL = os.path.exists(os.path.join(PASTA_EXE, 'portatil.txt'))
    if PORTATIL:
        _dados_padrao = os.path.join(PASTA_EXE, 'dados')
else:
    BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))     # src/backend
    PROJETO_DIR = os.path.dirname(os.path.dirname(BACKEND_DIR))                   # raiz do repositório
    FRONTEND_DIR = os.path.join(PROJETO_DIR, 'src', 'frontend')
    _dados_padrao = os.path.join(PROJETO_DIR, 'dados')

DATA_DIR = os.environ.get('DATA_DIR') or _dados_padrao
os.makedirs(DATA_DIR, exist_ok=True)

DB_PATH = os.environ.get('SQLITE_PATH') or os.path.join(DATA_DIR, 'intranet_ad_belem.db')
SECRET_FILE = os.path.join(DATA_DIR, '.secret_key')
LOG_DIR = os.path.join(DATA_DIR, 'logs')
os.makedirs(LOG_DIR, exist_ok=True)


def chave_secreta():
    """SECRET_KEY do ambiente ou uma chave aleatória guardada em DATA_DIR (criada na primeira execução)."""
    if os.environ.get('SECRET_KEY'):
        return os.environ['SECRET_KEY']
    if not os.path.exists(SECRET_FILE):
        import secrets
        with open(SECRET_FILE, 'w', encoding='utf-8') as f:
            f.write(secrets.token_hex(32))
    with open(SECRET_FILE, encoding='utf-8') as f:
        return f.read().strip()
