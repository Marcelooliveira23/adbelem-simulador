"""Segurança da informação: política de senhas, 2FA (TOTP), bloqueio de conta, revogação de sessões,
cabeçalhos HTTP, trilha de auditoria encadeada (à prova de adulteração) e backups automáticos.

Tudo com a biblioteca padrão do Python (sem dependências novas).
"""
import base64
import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import struct
import threading
import time
from datetime import datetime, timedelta
from urllib.parse import quote

from app.config import DATA_DIR
from app.database import DB_PATH, get_db
from app.validacao import ErroValidacao

# ---------------------------------------------------------------- senhas
SENHAS_FRACAS = {'12345678', '123456789', 'senha123', 'senha1234', 'password', 'qwerty123', 'admin123', 'adbelem123',
                 'belem123', 'igreja123', 'jesus123', '11111111', 'abc12345', 'mudar123'}
MAX_FALHAS_CONTA = 5            # tentativas erradas seguidas antes de bloquear a conta
BLOQUEIO_MIN = 15


def validar_senha(senha, email='', nome=''):
    """Política: 8+ caracteres, letras e números, não óbvia e sem o nome/e-mail do usuário."""
    if len(senha or '') < 8:
        raise ErroValidacao('A senha deve ter pelo menos 8 caracteres')
    if not re.search(r'[A-Za-z]', senha) or not re.search(r'\d', senha):
        raise ErroValidacao('A senha deve ter letras e números')
    if senha.lower() in SENHAS_FRACAS:
        raise ErroValidacao('Senha muito comum. Escolha outra')
    partes = [p for p in re.split(r'[@.\s_-]+', f'{email} {nome}'.lower()) if len(p) >= 4]
    if any(p in senha.lower() for p in partes):
        raise ErroValidacao('A senha não pode conter seu nome ou e-mail')
    return senha


# ---------------------------------------------------------------- 2FA (TOTP, RFC 6238)
def novo_segredo_totp():
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip('=')


def _codigo_totp(segredo, contador):
    chave = base64.b32decode(segredo + '=' * (-len(segredo) % 8))
    h = hmac.new(chave, struct.pack('>Q', contador), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    return f"{(struct.unpack('>I', h[o:o + 4])[0] & 0x7FFFFFFF) % 1000000:06d}"


def verificar_totp(segredo, codigo, janela=1, agora=None):
    codigo = re.sub(r'\D', '', str(codigo or ''))
    if not segredo or len(codigo) != 6:
        return False
    passo = int((agora or time.time()) // 30)
    return any(hmac.compare_digest(_codigo_totp(segredo, passo + d), codigo) for d in range(-janela, janela + 1))


def uri_totp(segredo, email):
    return f'otpauth://totp/{quote("Intranet AD Belém")}:{quote(email)}?secret={segredo}&issuer={quote("Intranet AD Belém")}'


# ---------------------------------------------------------------- acessos (histórico de login)
def registrar_acesso(conn, email, usuario_id, sucesso, motivo, ip, agente):
    conn.execute('INSERT INTO acessos (usuario_id, email, ip, agente, sucesso, motivo) VALUES (?, ?, ?, ?, ?, ?)',
                 (usuario_id, email[:150], ip, (agente or '')[:200], 1 if sucesso else 0, motivo))


# ---------------------------------------------------------------- revogação de sessões
def configurar_jwt(jwt):
    """Sessão inválida se o usuário foi desativado ou trocou a senha/perfil depois de entrar (token_versao)."""
    @jwt.token_in_blocklist_loader
    def _revogado(_cabecalho, payload):
        conn = get_db()
        try:
            u = conn.execute('SELECT ativo, token_versao FROM usuarios WHERE id = ?', (payload.get('sub'),)).fetchone()
        finally:
            conn.close()
        return not u or not u['ativo'] or (u['token_versao'] or 0) != payload.get('tv', 0)

    @jwt.revoked_token_loader
    def _msg_revogado(_cabecalho, _payload):
        from flask import jsonify
        return jsonify({'erro': 'Sua sessão foi encerrada. Entre novamente.', 'sessao_encerrada': True}), 401


# ---------------------------------------------------------------- cabeçalhos HTTP
CSP = ("default-src 'self'; img-src 'self' data: blob:; script-src 'self' 'unsafe-inline'; "
       "style-src 'self' 'unsafe-inline'; connect-src 'self'; font-src 'self' data:; object-src 'none'; "
       "base-uri 'self'; form-action 'self'; frame-ancestors 'none'")


def aplicar_cabecalhos(app):
    @app.after_request
    def _cabecalhos(resp):
        from flask import request
        resp.headers.setdefault('X-Content-Type-Options', 'nosniff')
        resp.headers.setdefault('X-Frame-Options', 'DENY')
        resp.headers.setdefault('Referrer-Policy', 'same-origin')
        resp.headers.setdefault('Permissions-Policy', 'camera=(self), microphone=(), geolocation=(), payment=()')
        resp.headers.setdefault('Content-Security-Policy', CSP)
        resp.headers.setdefault('Cross-Origin-Opener-Policy', 'same-origin')
        if request.path.startswith('/api/'):
            resp.headers['Cache-Control'] = 'no-store'
        if request.is_secure or request.headers.get('X-Forwarded-Proto') == 'https':
            resp.headers.setdefault('Strict-Transport-Security', 'max-age=31536000')
        return resp


# ---------------------------------------------------------------- trilha de auditoria encadeada
def hash_auditoria(anterior, usuario_id, usuario_nome, modulo, acao, detalhe):
    base = '|'.join(str(x if x is not None else '') for x in (anterior, usuario_id, usuario_nome, modulo, acao, detalhe))
    return hashlib.sha256(base.encode('utf-8')).hexdigest()


def verificar_cadeia(conn):
    """Recalcula a cadeia do log. Qualquer alteração ou exclusão no meio aparece como quebra."""
    anterior, total, primeiro = None, 0, None
    for r in conn.execute('SELECT * FROM auditoria WHERE hash IS NOT NULL ORDER BY id'):
        primeiro = primeiro or r['id']
        if anterior is not None and r['hash_anterior'] != anterior:
            return {'integro': False, 'registro': r['id'], 'motivo': 'Registro anterior removido ou alterado', 'verificados': total}
        if hash_auditoria(r['hash_anterior'], r['usuario_id'], r['usuario_nome'], r['modulo'], r['acao'], r['detalhe']) != r['hash']:
            return {'integro': False, 'registro': r['id'], 'motivo': 'Conteúdo do registro foi alterado', 'verificados': total}
        anterior, total = r['hash'], total + 1
    return {'integro': True, 'verificados': total, 'desde_registro': primeiro}


TRIGGERS_AUDITORIA = [
    """CREATE TRIGGER IF NOT EXISTS auditoria_sem_update BEFORE UPDATE ON auditoria
       BEGIN SELECT RAISE(ABORT, 'O log de auditoria não pode ser alterado'); END""",
    """CREATE TRIGGER IF NOT EXISTS auditoria_sem_delete BEFORE DELETE ON auditoria
       BEGIN SELECT RAISE(ABORT, 'O log de auditoria não pode ser apagado'); END""",
]


# ---------------------------------------------------------------- backups
DIR_BACKUP = os.path.join(DATA_DIR, 'backups')
RETENCAO = 30


def fazer_backup(motivo='automatico'):
    """Cópia consistente do banco (API de backup do SQLite) e limpeza dos antigos (guarda os 30 mais recentes)."""
    os.makedirs(DIR_BACKUP, exist_ok=True)
    nome = f"intranet-{datetime.now():%Y%m%d-%H%M%S}-{re.sub(r'[^a-z]', '', motivo)[:12]}.db"
    destino = os.path.join(DIR_BACKUP, nome)
    origem = sqlite3.connect(DB_PATH)
    try:
        copia = sqlite3.connect(destino)
        with copia:
            origem.backup(copia)
        copia.close()
    finally:
        origem.close()
    arquivos = sorted(f for f in os.listdir(DIR_BACKUP) if f.endswith('.db'))
    for velho in arquivos[:-RETENCAO]:
        try:
            os.remove(os.path.join(DIR_BACKUP, velho))
        except OSError:
            pass
    return nome


def listar_backups():
    if not os.path.isdir(DIR_BACKUP):
        return []
    out = []
    for f in sorted(os.listdir(DIR_BACKUP), reverse=True):
        if f.endswith('.db'):
            st = os.stat(os.path.join(DIR_BACKUP, f))
            out.append({'nome': f, 'tamanho': st.st_size, 'data': datetime.fromtimestamp(st.st_mtime).isoformat(timespec='seconds')})
    return out


def iniciar_backup_diario():
    """Faz um backup ao iniciar (se o último tiver mais de 20 h) e depois a cada 24 h."""
    def rotina():
        while True:
            try:
                ultimos = listar_backups()
                if not ultimos or datetime.fromisoformat(ultimos[0]['data']) < datetime.now() - timedelta(hours=20):
                    fazer_backup('automatico')
            except Exception as e:   # nunca derruba o servidor
                print(f'[backup] falha: {e}')
            time.sleep(3600)
    threading.Thread(target=rotina, name='backup-diario', daemon=True).start()
