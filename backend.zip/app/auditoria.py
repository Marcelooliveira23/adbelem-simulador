"""Registro de ações (log de auditoria), consultado no módulo 14 · Administração."""
from flask_jwt_extended import verify_jwt_in_request

from app.database import get_db


def registrar(modulo, acao, detalhe='', conn=None):
    """Grava uma ação do usuário autenticado. Nunca interrompe a operação principal."""
    try:
        from app.auth_utils import usuario_atual
        verify_jwt_in_request(optional=True)
        try:
            u = usuario_atual()
        except Exception:
            u = {'id': None, 'nome': 'sistema'}
        proprio = conn is None
        conn = conn or get_db()
        from flask import has_request_context, request
        from app.seguranca import hash_auditoria
        detalhe = str(detalhe)[:500]
        ultimo = conn.execute('SELECT hash FROM auditoria WHERE hash IS NOT NULL ORDER BY id DESC LIMIT 1').fetchone()
        anterior = ultimo[0] if ultimo else 'inicio'
        ip = (request.headers.get('X-Forwarded-For', request.remote_addr or '').split(',')[0].strip()
              if has_request_context() else None)
        conn.execute('INSERT INTO auditoria (usuario_id, usuario_nome, modulo, acao, detalhe, ip, hash_anterior, hash) '
                     'VALUES (?,?,?,?,?,?,?,?)',
                     (u.get('id'), u.get('nome'), modulo, acao, detalhe, ip, anterior,
                      hash_auditoria(anterior, u.get('id'), u.get('nome'), modulo, acao, detalhe)))
        if proprio:
            conn.commit()
            conn.close()
    except Exception as e:  # o log nunca deve derrubar a requisição
        print(f'[auditoria] falha ao registrar: {e}')
