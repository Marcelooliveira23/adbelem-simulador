"""Dados de teste: um usuário por perfil e congregações fictícias.

Só cria o que ainda não existe (por e-mail / por tabela vazia), então pode rodar a cada início.
"""
from app.database import get_db
from app.models import Usuario

CONGREGACOES_TESTE = [
    ('Cong. Jardim A (fictícia)', 'Pr. Marcos Reis', 'Rua das Flores, 25', 'Jardim A', 'São José dos Campos', 'SP', -23.1790, -45.8869),
    ('Cong. Vila B (fictícia)', 'Pr. Paulo Dias', 'Rua B, 300', 'Vila B', 'São José dos Campos', 'SP', -23.2010, -45.9100),
    ('Cong. Centro C (fictícia)', 'Pr. André Luz', 'Rua C, 45', 'Centro', 'São José dos Campos', 'SP', -23.1870, -45.8840),
]

# (nome, email, senha, perfil_id, usa_congregacao)
USUARIOS_TESTE = [
    ('Administrador', 'admin@adbelem.com', 'admin123', 1, False),
    ('Pr. Presidente (teste)', 'pastor@adbelem.com', 'senha123', 2, False),
    ('Vice-Presidente (teste)', 'vice@adbelem.com', 'senha123', 12, False),
    ('Tesoureiro (teste)', 'tesoureiro@adbelem.com', 'senha123', 3, False),
    ('Secretário (teste)', 'secretario@adbelem.com', 'senha123', 4, False),
    ('Patrimônio (teste)', 'patrimonio@adbelem.com', 'senha123', 5, False),
]


def garantir_usuarios_teste():
    """Cria congregações de teste (se não houver nenhuma) e os usuários de teste ausentes.
    Retorna quantos usuários criou."""
    conn = get_db()
    try:
        modo_teste = (conn.execute("SELECT valor FROM configuracoes WHERE chave = 'modo_teste'").fetchone() or ['1'])[0] == '1'
        if modo_teste and not conn.execute('SELECT COUNT(*) FROM congregacoes').fetchone()[0]:
            conn.executemany('''INSERT INTO congregacoes (nome, dirigente, endereco, bairro, cidade, estado, latitude, longitude)
                                VALUES (?,?,?,?,?,?,?,?)''', CONGREGACOES_TESTE)
        primeira = conn.execute('SELECT MIN(id) FROM congregacoes').fetchone()[0]
        criados = 0
        for nome, email, senha, perfil_id, usa_cong in USUARIOS_TESTE:
            if conn.execute('SELECT 1 FROM usuarios WHERE lower(email) = ?', (email,)).fetchone():
                continue
            # em produção (modo de teste desligado) não recria contas fictícias; só garante um administrador
            if not modo_teste and (perfil_id != 1 or conn.execute(
                    'SELECT 1 FROM usuarios WHERE perfil_id = 1 AND ativo = 1').fetchone()):
                continue
            conn.execute('''INSERT INTO usuarios (nome, email, senha_hash, perfil_id, congregacao_id, ativo)
                            VALUES (?, ?, ?, ?, ?, 1)''',
                         (nome, email, Usuario.criar_hash_senha(senha), perfil_id, primeira if usa_cong else None))
            criados += 1
        # Perfis que saíram do escopo (Dirigente, Conselho, EBD, CFAO, Banda, CFO): contas ficam inativas
        from app.models import Perfil
        validos = tuple(Perfil.PERFIS)
        conn.execute(f"UPDATE usuarios SET ativo = 0 WHERE perfil_id NOT IN ({','.join('?' * len(validos))})", validos)
        conn.commit()
        return criados
    finally:
        conn.close()
