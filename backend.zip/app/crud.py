"""Rotas CRUD genéricas: listar, obter, criar, editar, excluir e "de acordo".

Uso:
    registrar_crud(app, rota='contratos', tabela='contratos', modulo='secretaria',
                   campos={'descricao': lambda d: texto(d, 'descricao', True), ...})

- Permissões: <modulo>.consultar / criar / editar / deletar / aprovar.
- escopo=True: a tabela tem congregacao_id; usuários com escopo de congregação
  (Dirigente) só veem e lançam na própria congregação.
- aprovacao=True: o que um usuário com escopo lança entra como 'pendente' e só
  vale depois do "de acordo" da sede (PATCH /api/<rota>/<id>/aprovacao).
"""
from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao, escopo_congregacao
from app.database import get_db, rows_to_dicts
from app.validacao import ErroValidacao, opcao, texto

STATUS_APROVACAO = ('aprovado', 'devolvido')


def registrar_crud(app, rota, tabela, modulo, campos, chave_lista=None, ordem='id DESC',
                   escopo=False, aprovacao=False, filtros=(), rotulo=None, depois_salvar=None):
    chave_lista = chave_lista or rota
    rotulo = rotulo or rota
    col_cong = ', (SELECT nome FROM congregacoes c WHERE c.id = t.congregacao_id) AS congregacao_nome' if escopo else ''

    def _where_escopo(params):
        cong = escopo_congregacao() if escopo else None
        if cong is not None:
            params.append(cong)
            return ' AND t.congregacao_id = ?', cong
        return '', None

    def _ler(data):
        return {nome: validar(data) for nome, validar in campos.items()}

    def listar():
        params = []
        where, _ = _where_escopo(params)
        for f in filtros:
            v = request.args.get(f)
            if v not in (None, ''):
                where += f' AND t.{f} = ?'
                params.append(v)
        conn = get_db()
        try:
            rows = conn.execute(f'SELECT t.*{col_cong} FROM {tabela} t WHERE 1=1{where} ORDER BY {ordem}',
                                params).fetchall()
            return jsonify({chave_lista: rows_to_dicts(rows)}), 200
        finally:
            conn.close()

    def obter(id):
        params = [id]
        where, _ = _where_escopo(params)
        conn = get_db()
        try:
            row = conn.execute(f'SELECT t.*{col_cong} FROM {tabela} t WHERE t.id = ?{where}', params).fetchone()
            if not row:
                return jsonify({'erro': 'Registro não encontrado'}), 404
            return jsonify(dict(row)), 200
        finally:
            conn.close()

    def criar():
        try:
            dados = _ler(request.get_json(silent=True) or {})
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        cong = escopo_congregacao() if escopo else None
        if cong is not None:
            dados['congregacao_id'] = cong
            if aprovacao:
                dados['aprovacao'] = 'pendente'
        conn = get_db()
        try:
            cols = list(dados)
            cur = conn.execute(f'INSERT INTO {tabela} ({", ".join(cols)}) VALUES ({", ".join("?" for _ in cols)})',
                               [dados[c] for c in cols])
            novo_id = cur.lastrowid
            if depois_salvar:
                depois_salvar(conn, novo_id, dados)
            registrar(modulo, f'Criou {rotulo} #{novo_id}', dados.get('nome') or dados.get('descricao')
                      or dados.get('titulo') or '', conn)
            conn.commit()
            pendente = dados.get('aprovacao') == 'pendente'
            return jsonify({'msg': 'Registro criado' + (' (aguardando o "de acordo" da sede)' if pendente else ''),
                            'id': novo_id, 'pendente': pendente}), 201
        finally:
            conn.close()

    def editar(id):
        try:
            dados = _ler(request.get_json(silent=True) or {})
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        params_esc = []
        where, cong = _where_escopo(params_esc)
        if cong is not None:
            dados['congregacao_id'] = cong
        conn = get_db()
        try:
            cols = list(dados)
            cur = conn.execute(f'UPDATE {tabela} AS t SET {", ".join(f"{c} = ?" for c in cols)} WHERE t.id = ?{where}',
                               [dados[c] for c in cols] + [id] + params_esc)
            if cur.rowcount == 0:
                return jsonify({'erro': 'Registro não encontrado'}), 404
            if depois_salvar:
                depois_salvar(conn, id, dados)
            registrar(modulo, f'Editou {rotulo} #{id}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Registro atualizado'}), 200
        finally:
            conn.close()

    def excluir(id):
        params = [id]
        where, _ = _where_escopo(params)
        conn = get_db()
        try:
            cur = conn.execute(f'DELETE FROM {tabela} AS t WHERE t.id = ?{where}', params)
            if cur.rowcount == 0:
                return jsonify({'erro': 'Registro não encontrado'}), 404
            registrar(modulo, f'Excluiu {rotulo} #{id}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Registro removido'}), 200
        finally:
            conn.close()

    def aprovar(id):
        data = request.get_json(silent=True) or {}
        try:
            status = opcao(data, 'status', STATUS_APROVACAO)
            obs = texto(data, 'obs', max_len=500)
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        if status == 'devolvido' and not obs:
            return jsonify({'erro': 'Informe o motivo da devolução'}), 400
        conn = get_db()
        try:
            cur = conn.execute(f'UPDATE {tabela} SET aprovacao = ?, obs_aprovacao = ? WHERE id = ?', (status, obs, id))
            if cur.rowcount == 0:
                return jsonify({'erro': 'Registro não encontrado'}), 404
            registrar(modulo, f'{"De acordo" if status == "aprovado" else "Devolveu"} {rotulo} #{id}', obs, conn)
            conn.commit()
            return jsonify({'msg': 'De acordo registrado' if status == 'aprovado' else 'Devolvido à congregação'}), 200
        finally:
            conn.close()

    base = f'/api/{rota}'
    ep = rota.replace('/', '_')
    app.add_url_rule(base, f'{ep}_listar', requer_permissao(f'{modulo}.consultar')(listar), methods=['GET'])
    app.add_url_rule(base, f'{ep}_criar', requer_permissao(f'{modulo}.criar')(criar), methods=['POST'])
    app.add_url_rule(f'{base}/<int:id>', f'{ep}_obter', requer_permissao(f'{modulo}.consultar')(obter), methods=['GET'])
    app.add_url_rule(f'{base}/<int:id>', f'{ep}_editar', requer_permissao(f'{modulo}.editar')(editar), methods=['PUT'])
    app.add_url_rule(f'{base}/<int:id>', f'{ep}_excluir', requer_permissao(f'{modulo}.deletar')(excluir), methods=['DELETE'])
    if aprovacao:
        app.add_url_rule(f'{base}/<int:id>/aprovacao', f'{ep}_aprovar',
                         requer_permissao(f'{modulo}.aprovar')(aprovar), methods=['PATCH'])
