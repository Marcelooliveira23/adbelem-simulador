"""Tryout (homologação) antes da produção.

- Resultados do roteiro de testes: cada testador marca cada cenário como OK, Falhou ou Não se aplica.
- Dados de demonstração: preenchem o sistema com uma rotina realista de igreja para o tryout.
- Preparar para produção: faz backup, apaga os dados de teste, desliga o modo de teste e
  desativa as contas fictícias (o log de auditoria é preservado).
"""
import os
import random
import shutil
from datetime import date, timedelta

from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao, requer_login, usuario_atual
from app.config import DATA_DIR
from app.database import get_db, rows_to_dicts
from app.models import Permissao
from app.seed import USUARIOS_TESTE
from app.seguranca import fazer_backup
from app.validacao import ErroValidacao, texto, opcao

FRASE_PRODUCAO = 'INICIAR PRODUCAO'
# Tabelas com dados operacionais (apagadas ao iniciar a produção). Usuários, plano de contas, modelos de cartas,
# configurações, acessos e o log de auditoria são mantidos.
TABELAS_OPERACIONAIS = [
    'membros', 'membros_fotos', 'financeiro', 'patrimonio', 'documentos', 'contratos', 'caixa_dias', 'campanhas',
    'extrato', 'banco_movimentos', 'acertos', 'congregacao_debitos', 'pedidos_compra', 'pedidos_itens', 'materiais',
    'materiais_mov', 'arquivos', 'fornecedores', 'contas_recorrentes', 'periodos_fechados', 'visitantes', 'departamentos',
    'patrimonio_mov', 'inventarios', 'inventario_itens', 'contas_financeiras', 'transferencias', 'orcamento', 'espacos',
    'eventos', 'escalas', 'registros_eclesiasticos', 'atas', 'ebd_classes', 'ebd_aulas', 'frequencia_cultos',
    'manutencoes_programadas', 'tryout_resultados', 'funcionarios',
]


def registrar_tryout(app):
    @app.route('/api/tryout/resultados', methods=['GET'])
    @requer_login
    def tryout_listar():
        eu = usuario_atual()
        ver_todos = Permissao.tem_acesso(eu, 'admin.auditoria')
        conn = get_db()
        try:
            sql = 'SELECT * FROM tryout_resultados' + ('' if ver_todos else ' WHERE usuario_id = ?') + ' ORDER BY data DESC'
            rows = rows_to_dicts(conn.execute(sql, () if ver_todos else (eu['id'],)))
            return jsonify({'resultados': rows, 'todos': ver_todos}), 200
        finally:
            conn.close()

    @app.route('/api/tryout/resultados', methods=['POST'])
    @requer_login
    def tryout_marcar():
        d = request.get_json(silent=True) or {}
        try:
            cenario = texto(d, 'cenario', obrigatorio=True, max_len=40)
            status = opcao(d, 'status', ('ok', 'falhou', 'na'))
            if not status:
                raise ErroValidacao('Informe o resultado')
            comentario = texto(d, 'comentario', max_len=1000)
            if status == 'falhou' and not comentario:
                raise ErroValidacao('Descreva o que aconteceu quando falhou')
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        eu = usuario_atual()
        conn = get_db()
        try:
            conn.execute('''INSERT INTO tryout_resultados (cenario, usuario_id, usuario_nome, perfil, status, comentario)
                            VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT (cenario, usuario_id) DO UPDATE SET status = excluded.status,
                            comentario = excluded.comentario, data = CURRENT_TIMESTAMP''',
                         (cenario, eu['id'], eu['nome'], eu['perfil'], status, comentario))
            conn.commit()
            return jsonify({'msg': 'Resultado registrado'}), 200
        finally:
            conn.close()

    # ------------------------------------------------ dados de demonstração
    @app.route('/api/admin/demo', methods=['POST'])
    @requer_permissao('admin.editar')
    def gerar_demo():
        conn = get_db()
        try:
            if conn.execute("SELECT valor FROM configuracoes WHERE chave = 'modo_teste'").fetchone() not in (None,) and \
                    conn.execute("SELECT valor FROM configuracoes WHERE chave = 'modo_teste'").fetchone()[0] == '0':
                return jsonify({'erro': 'O sistema já está em produção: dados de demonstração não são permitidos'}), 409
            if conn.execute('SELECT COUNT(*) FROM membros').fetchone()[0] >= 25:
                return jsonify({'erro': 'Já existem dados suficientes para o tryout'}), 409
            n = _popular_demo(conn, usuario_atual()['id'])
            registrar('admin', 'Gerou dados de demonstração para o tryout', f'{n} registro(s)', conn)
            conn.commit()
            return jsonify({'msg': f'Dados de demonstração criados ({n} registros)'}), 201
        finally:
            conn.close()

    # ------------------------------------------------ preparar para produção
    @app.route('/api/admin/producao', methods=['POST'])
    @requer_permissao('admin.editar')
    def preparar_producao():
        d = request.get_json(silent=True) or {}
        if (d.get('confirmacao') or '').strip().upper() != FRASE_PRODUCAO:
            return jsonify({'erro': f'Digite exatamente "{FRASE_PRODUCAO}" para confirmar'}), 400
        manter_cong = bool(d.get('manter_congregacoes'))
        backup = fazer_backup('preproducao')
        conn = get_db()
        try:
            totais = {}
            for t in TABELAS_OPERACIONAIS + ([] if manter_cong else ['congregacoes']):
                totais[t] = conn.execute(f'DELETE FROM {t}').rowcount
            conn.execute("DELETE FROM sqlite_sequence WHERE name IN ({})".format(
                ','.join('?' * len(TABELAS_OPERACIONAIS))), TABELAS_OPERACIONAIS)
            emails = [u[1] for u in USUARIOS_TESTE if u[3] != 1]
            conn.execute(f"UPDATE usuarios SET ativo = 0, token_versao = COALESCE(token_versao, 0) + 1 "
                         f"WHERE lower(email) IN ({','.join('?' * len(emails))})", emails)
            # admin de teste com senha padrão: troca obrigatória no próximo acesso
            conn.execute("UPDATE usuarios SET trocar_senha = 1, token_versao = COALESCE(token_versao, 0) + 1 "
                         "WHERE lower(email) = 'admin@adbelem.com'")
            conn.execute("INSERT INTO configuracoes (chave, valor) VALUES ('modo_teste', '0') "
                         "ON CONFLICT (chave) DO UPDATE SET valor = '0'")
            conn.execute("INSERT INTO configuracoes (chave, valor) VALUES ('producao_desde', ?) "
                         "ON CONFLICT (chave) DO UPDATE SET valor = excluded.valor", (date.today().isoformat(),))
            registrar('admin', 'Preparou o sistema para produção',
                      f'backup {backup}; {sum(totais.values())} registro(s) de teste apagados', conn)
            conn.commit()
        finally:
            conn.close()
        pasta_arq = os.path.join(DATA_DIR, 'arquivos')
        if os.path.isdir(pasta_arq):
            shutil.rmtree(pasta_arq, ignore_errors=True)
        return jsonify({'msg': 'Sistema pronto para produção. Entre novamente com a conta de administrador e troque a senha.',
                        'backup': backup, 'apagados': totais}), 200


# ------------------------------------------------------------------ gerador de demonstração
NOMES = ['Ana', 'Bruno', 'Carla', 'Daniel', 'Elaine', 'Fábio', 'Gabriela', 'Henrique', 'Isabel', 'João', 'Késia', 'Lucas',
         'Marta', 'Natanael', 'Olívia', 'Paulo', 'Raquel', 'Samuel', 'Tânia', 'Vitor', 'Débora', 'Ezequiel', 'Rute', 'Josué',
         'Priscila', 'Timóteo', 'Lídia', 'Gideão', 'Ester', 'Abel']
SOBRENOMES = ['Silva', 'Santos', 'Oliveira', 'Souza', 'Lima', 'Pereira', 'Costa', 'Rodrigues', 'Almeida', 'Nascimento']


def _popular_demo(conn, uid):
    rnd = random.Random(2026)
    hoje = date.today()
    congs = [r[0] for r in conn.execute('SELECT id FROM congregacoes').fetchall()]
    unidade = lambda: rnd.choice([None] + congs)  # noqa: E731
    n = 0
    funcoes = ['Membro'] * 6 + ['Cooperador(a)', 'Diácono', 'Diaconisa', 'Presbítero', 'Evangelista']
    membros = []
    for i in range(30):
        nome = f'{NOMES[i]} {rnd.choice(SOBRENOMES)} {rnd.choice(SOBRENOMES)}'
        nasc = date(rnd.randint(1950, 2008), rnd.randint(1, 12), rnd.randint(1, 28)).isoformat()
        cur = conn.execute('''INSERT INTO membros (nome, celular, data_nascimento, status, funcao, congregacao_id, sexo,
                                estado_civil, data_batismo, data_cadastro) VALUES (?, ?, ?, 'ativo', ?, ?, ?, ?, ?, ?)''',
                           (nome, f'(12) 9{rnd.randint(8000, 9999)}-{rnd.randint(1000, 9999)}', nasc, rnd.choice(funcoes),
                            unidade(), 'F' if NOMES[i][-1] == 'a' or NOMES[i] in ('Isabel', 'Ester', 'Rute', 'Lídia', 'Késia') else 'M',
                            rnd.choice(['solteiro', 'casado', 'casado', 'viuvo']),
                            date(rnd.randint(1990, 2025), rnd.randint(1, 12), rnd.randint(1, 28)).isoformat(), hoje.isoformat()))
        membros.append(cur.lastrowid)
        n += 1
    # contas financeiras e fornecedores
    caixa = conn.execute("INSERT INTO contas_financeiras (nome, tipo, saldo_inicial) VALUES ('Caixa da sede', 'caixa', 1500)").lastrowid
    banco = conn.execute("INSERT INTO contas_financeiras (nome, tipo, banco, saldo_inicial) VALUES ('Banco do Brasil – Conta A', 'banco', 'Banco do Brasil', 18000)").lastrowid
    forn = {}
    for nome, ramo in (('EDP Energia', 'Energia'), ('Sabesp', 'Água'), ('Gráfica Esperança', 'Gráfica'), ('CPAD Revistas', 'Material EBD')):
        forn[ramo] = conn.execute('INSERT INTO fornecedores (nome, ramo) VALUES (?, ?)', (nome, ramo)).lastrowid
        n += 1
    conn.execute("""INSERT INTO contas_recorrentes (descricao, fornecedor_id, categoria, valor, dia_vencimento, forma)
                    VALUES ('Conta de luz do templo', ?, 'agua_luz', 680, 10, 'boleto'), ('Conta de água', ?, 'agua_luz', 210, 15, 'boleto')""",
                 (forn['Energia'], forn['Água']))
    # 3 meses de lançamentos
    for m in range(3, -1, -1):
        base = (hoje.replace(day=1) - timedelta(days=30 * m)).replace(day=1)
        for semana in range(4):
            dia = min(base + timedelta(days=7 * semana + 6), hoje)
            for cat, faixa in (('dizimo', (2500, 5200)), ('oferta', (600, 1400))):
                conn.execute('''INSERT INTO financeiro (tipo, descricao, valor, data, categoria, status, forma, usuario_id, aprovacao,
                                  conta_id, membro_id) VALUES ('receita', ?, ?, ?, ?, 'confirmada', ?, ?, 'aprovado', ?, ?)''',
                             (f"{'Dízimos' if cat == 'dizimo' else 'Ofertas'} do culto de domingo", round(rnd.uniform(*faixa), 2),
                              dia.isoformat(), cat, rnd.choice(['dinheiro', 'pix']), uid, rnd.choice([caixa, banco]),
                              rnd.choice(membros) if cat == 'dizimo' and rnd.random() < .5 else None))
                n += 1
        for desc, cat, valor, fid in (('Conta de luz', 'agua_luz', 680, forn['Energia']), ('Conta de água', 'agua_luz', 210, forn['Água']),
                                      ('Prebenda pastoral', 'salario', 4500, None), ('Material de limpeza', 'material', 380, None),
                                      ('Oferta missionária', 'missoes', 1200, None)):
            dia = min(base + timedelta(days=rnd.randint(4, 25)), hoje)
            conn.execute('''INSERT INTO financeiro (tipo, descricao, valor, data, vencimento, categoria, status, forma, usuario_id,
                              aprovacao, conta_id, fornecedor_id) VALUES ('despesa', ?, ?, ?, ?, ?, ?, 'boleto', ?, 'aprovado', ?, ?)''',
                         (desc, valor, dia.isoformat(), dia.isoformat(), cat, 'pago' if m else rnd.choice(['pago', 'pendente']),
                          uid, banco, fid))
            n += 1
    # orçamento do ano
    for tipo, cat, v in (('receita', 'dizimo', 180000), ('receita', 'oferta', 48000), ('despesa', 'agua_luz', 11000),
                         ('despesa', 'salario', 54000), ('despesa', 'material', 5000), ('despesa', 'missoes', 15000)):
        conn.execute('INSERT OR REPLACE INTO orcamento (ano, tipo, categoria, valor_anual) VALUES (?, ?, ?, ?)', (hoje.year, tipo, cat, v))
    # secretaria: visitantes, departamentos, eventos, escalas, EBD, frequência, registros
    for i in range(8):
        conn.execute('''INSERT INTO visitantes (nome, telefone, data_visita, situacao, convidado_por, como_conheceu)
                        VALUES (?, ?, ?, ?, ?, ?)''',
                     (f'{rnd.choice(NOMES)} {rnd.choice(SOBRENOMES)}', f'(12) 9{rnd.randint(8000, 9999)}-{rnd.randint(1000, 9999)}',
                      (hoje - timedelta(days=rnd.randint(0, 40))).isoformat(),
                      rnd.choice(['novo', 'contatado', 'acompanhamento', 'integrado']), rnd.choice(NOMES), rnd.choice(['convite', 'redes', 'passando'])))
        n += 1
    for nome, tipo, lider in (('União de Mocidade', 'departamento', 'Lucas Costa'), ('Círculo de Oração', 'ministerio', 'Marta Lima'),
                              ('Departamento Infantil', 'departamento', 'Raquel Souza'), ('Coral Adoração', 'conjunto', 'Samuel Silva')):
        conn.execute('INSERT INTO departamentos (nome, tipo, lider) VALUES (?, ?, ?)', (nome, tipo, lider))
    templo = conn.execute("INSERT INTO espacos (nome, capacidade, recursos) VALUES ('Templo principal', 400, 'Som, projetor')").lastrowid
    salao = conn.execute("INSERT INTO espacos (nome, capacidade, recursos) VALUES ('Salão social', 80, 'Cozinha, mesas')").lastrowid
    conn.execute("INSERT INTO espacos (nome, capacidade) VALUES ('Sala da EBD 1', 30)")
    for k in range(0, 21, 7):
        dom = hoje + timedelta(days=(6 - hoje.weekday()) % 7 + k)
        ev = conn.execute('''INSERT INTO eventos (titulo, tipo, data, hora_inicio, hora_fim, espaco_id, responsavel)
                             VALUES ('Culto de celebração', 'culto', ?, '18:00', '20:30', ?, 'Pr. Presidente')''', (dom.isoformat(), templo)).lastrowid
        for funcao, pessoa in (('Porteiro', 'Paulo Lima'), ('Recepção', 'Ana Souza'), ('Som', 'Vitor Costa'), ('Diácono da Santa Ceia', 'Fábio Santos')):
            conn.execute('INSERT INTO escalas (data, evento_id, funcao, pessoa, confirmado) VALUES (?, ?, ?, ?, ?)',
                         (dom.isoformat(), ev, funcao, pessoa, rnd.choice([0, 1])))
        n += 5
    conn.execute('''INSERT INTO eventos (titulo, tipo, data, hora_inicio, hora_fim, espaco_id, responsavel)
                    VALUES ('Ensaio do coral', 'ensaio', ?, '19:00', '21:00', ?, 'Samuel Silva')''', ((hoje + timedelta(days=3)).isoformat(), salao))
    classes = []
    for nome, faixa, prof in (('Adultos', '18+', 'Pb. Daniel'), ('Jovens', '15-17', 'Ev. Lucas'), ('Juniores', '9-12', 'Irmã Rute')):
        classes.append((conn.execute('INSERT INTO ebd_classes (nome, faixa, professor, matriculados) VALUES (?, ?, ?, ?)',
                                     (nome, faixa, prof, rnd.randint(12, 35))).lastrowid))
    for k in range(1, 5):
        dom = hoje - timedelta(days=(hoje.weekday() + 1) % 7 + 7 * (k - 1))
        for c in classes:
            mat = conn.execute('SELECT matriculados FROM ebd_classes WHERE id = ?', (c,)).fetchone()[0]
            pres = rnd.randint(mat // 2, mat)
            conn.execute('''INSERT OR IGNORE INTO ebd_aulas (classe_id, data, licao, matriculados, presentes, visitantes, biblias, revistas, oferta)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                         (c, dom.isoformat(), f'Lição {10 + k}', mat, pres, rnd.randint(0, 4), pres - rnd.randint(0, 3),
                          pres - rnd.randint(0, 5), round(rnd.uniform(20, 90), 2)))
        conn.execute('''INSERT INTO frequencia_cultos (data, culto, adultos, criancas, visitantes, decisoes, pregador)
                        VALUES (?, 'Culto de domingo', ?, ?, ?, ?, 'Pr. Presidente')''',
                     (dom.isoformat(), rnd.randint(180, 260), rnd.randint(30, 60), rnd.randint(3, 15), rnd.randint(0, 4)))
        n += 4
    conn.execute('''INSERT INTO registros_eclesiasticos (tipo, data, nome, oficiante, livro, folha, numero)
                    VALUES ('batismo', ?, 'Gabriela Costa', 'Pr. Presidente', '3', '45', '1021')''', ((hoje - timedelta(days=60)).isoformat(),))
    # patrimônio
    for nome, cat, valor, vida in (('Mesa de som digital 32 canais', 'eletronico', 18000, 8), ('Projetor 5000 lumens', 'eletronico', 6500, 5),
                                   ('Teclado arranjador', 'instrumento', 7200, 10), ('Cadeiras plásticas (lote 100)', 'movel', 4500, 10),
                                   ('Ar-condicionado 60.000 BTU', 'eletronico', 14000, 10), ('Veículo utilitário', 'veiculo', 85000, 10)):
        conn.execute('''INSERT INTO patrimonio (nome, tombo, categoria, local, valor, status, data_aquisicao, vida_util_anos, espaco_id,
                          garantia_ate, aprovacao) VALUES (?, ?, ?, 'Templo', ?, 'bom', ?, ?, ?, ?, 'aprovado')''',
                     (nome, f'P-{rnd.randint(1000, 9999)}', cat, valor, (hoje - timedelta(days=rnd.randint(100, 2000))).isoformat(),
                      vida, templo, (hoje + timedelta(days=rnd.randint(-100, 300))).isoformat()))
        n += 1
    conn.execute('''INSERT INTO manutencoes_programadas (espaco, descricao, periodicidade_meses, proxima_data, prestador, custo_estimado)
                    VALUES ('Templo principal', 'Limpeza dos filtros do ar-condicionado', 3, ?, 'Clima Frio Ltda', 350),
                           ('Templo principal', 'Recarga dos extintores', 12, ?, 'Extintores SJC', 600)''',
                 ((hoje + timedelta(days=5)).isoformat(), (hoje - timedelta(days=2)).isoformat()))
    return n
