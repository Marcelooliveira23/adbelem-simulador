from datetime import date

from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao, usuario_atual, escopo_congregacao
from app.models import Permissao
from app.routes.tesouraria_extra import saldo_campanha
from app.database import get_db, rows_to_dicts
from app.periodos import periodo_fechado, msg_fechado, categorias_validas
from app.validacao import ErroValidacao, texto, opcao, numero, data_iso, inteiro, brl

CATEGORIAS_RECEITA = ('dizimo', 'oferta', 'oferta_alcada', 'campanha', 'evento', 'outro')
CATEGORIAS_DESPESA = ('manutencao', 'salario', 'agua_luz', 'aluguel', 'material_ebd', 'material', 'acao_social', 'missoes', 'evento', 'outro')
STATUS_DESPESA = ('pago', 'pendente')
FORMAS = ('dinheiro', 'pix', 'transferencia', 'cartao')

SELECT = '''SELECT f.id, f.data, f.descricao, f.tipo, f.valor, f.categoria, f.status, f.forma,
                   f.congregacao_id, f.aprovacao, f.obs_aprovacao, f.membro_id, f.campanha_id, f.caixa_id,
                   f.fornecedor_id, f.vencimento, f.documento, f.recorrente_id, f.conta_id,
                   (SELECT nome FROM contas_financeiras k WHERE k.id = f.conta_id) AS conta_nome,
                   (SELECT nome FROM fornecedores o WHERE o.id = f.fornecedor_id) AS fornecedor_nome,
                   (SELECT nome FROM campanhas k WHERE k.id = f.campanha_id) AS campanha_nome,
                   (SELECT nome FROM membros m WHERE m.id = f.membro_id) AS contribuinte,
                   (SELECT nome FROM congregacoes c WHERE c.id = f.congregacao_id) AS congregacao_nome
            FROM financeiro f'''


def _filtro_escopo(params):
    cong = escopo_congregacao()
    if cong is not None:
        params.append(cong)
        return ' AND f.congregacao_id = ?'
    return ''


def registrar_financeiro(app):

    @app.route('/api/financeiro', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def obter_financeiro():
        params = []
        where = _filtro_escopo(params)
        cong = request.args.get('congregacao_id')
        if cong == 'sede':
            where += ' AND f.congregacao_id IS NULL'
        elif cong:
            where += ' AND f.congregacao_id = ?'
            params.append(cong)
        conn = get_db()
        try:
            transacoes = rows_to_dicts(conn.execute(
                f'{SELECT} WHERE 1=1{where} ORDER BY f.data DESC, f.id DESC', params).fetchall())
        finally:
            conn.close()

        # Quem contribuiu e quanto: só a Tesouraria vê (os demais veem apenas os totais)
        if not Permissao.tem_acesso(usuario_atual(), 'tesouraria.contribuintes'):
            for t in transacoes:
                t['membro_id'] = None
                t['contribuinte'] = None

        # Só entra nos totais o que já recebeu o "de acordo" da sede
        validas = [t for t in transacoes if (t['aprovacao'] or 'aprovado') == 'aprovado']
        receitas = [t for t in transacoes if t['tipo'] == 'receita']
        despesas = [t for t in transacoes if t['tipo'] == 'despesa']
        total_receita = round(sum(t['valor'] for t in validas if t['tipo'] == 'receita'), 2)
        total_despesa = round(sum(t['valor'] for t in validas if t['tipo'] == 'despesa'), 2)
        total_dizimos = round(sum(t['valor'] for t in validas if t['tipo'] == 'receita' and t['categoria'] == 'dizimo'), 2)

        return jsonify({
            'saldo_total': round(total_receita - total_despesa, 2),
            'total_receita': total_receita,
            'total_despesa': total_despesa,
            'total_dizimos': total_dizimos,
            'pendentes_aprovacao': sum(1 for t in transacoes if t['aprovacao'] == 'pendente'),
            'transacoes': transacoes,
            'receitas': receitas,
            'despesas': despesas,
        }), 200

    def _inserir(tipo, status_opcoes, status_padrao):
        data = request.get_json(silent=True) or {}
        user = usuario_atual()
        categorias = tuple(categorias_validas(tipo))
        try:
            reg = {
                'tipo': tipo,
                'descricao': texto(data, 'descricao', obrigatorio=True, max_len=250),
                'valor': numero(data, 'valor', obrigatorio=True, positivo=True),
                'data': data_iso(data, 'data', obrigatorio=True),
                'categoria': opcao(data, 'categoria', categorias),
                'status': opcao(data, 'status', status_opcoes, padrao=status_padrao),
                'forma': opcao(data, 'forma', FORMAS, padrao='dinheiro'),
                'congregacao_id': inteiro(data, 'congregacao_id'),
                'membro_id': inteiro(data, 'membro_id') if tipo == 'receita' else None,
                'campanha_id': inteiro(data, 'campanha_id'),
                'fornecedor_id': inteiro(data, 'fornecedor_id') if tipo == 'despesa' else None,
                'vencimento': data_iso(data, 'vencimento') if tipo == 'despesa' else None,
                'documento': texto(data, 'documento', max_len=60),
                'conta_id': inteiro(data, 'conta_id'),
                'usuario_id': user['id'],
                'aprovacao': 'aprovado',
            }
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        cong = escopo_congregacao(user)
        if cong is not None:   # dirigente: lança na própria congregação e aguarda o "de acordo"
            reg['congregacao_id'] = cong
            reg['aprovacao'] = 'pendente'

        conn = get_db()
        try:
            if periodo_fechado(conn, reg['data']):
                return jsonify({'erro': msg_fechado(reg['data'])}), 409
            if reg['campanha_id']:
                camp = conn.execute('SELECT nome, restrito FROM campanhas WHERE id = ?', (reg['campanha_id'],)).fetchone()
                if not camp:
                    return jsonify({'erro': 'Campanha não encontrada'}), 400
                if tipo == 'despesa' and camp['restrito']:
                    arrecadado, gasto = saldo_campanha(conn, reg['campanha_id'])
                    if reg['valor'] > round(arrecadado - gasto, 2) + 0.001:
                        return jsonify({'erro': f"Saldo insuficiente no fundo \"{camp['nome']}\": "
                                                f"disponível {brl(arrecadado - gasto)}. O dinheiro de um fundo "
                                                f"restrito só pode ser usado na sua finalidade."}), 400
            cols = list(reg)
            cur = conn.execute(f'INSERT INTO financeiro ({", ".join(cols)}) VALUES ({", ".join("?" for _ in cols)})',
                               [reg[c] for c in cols])
            registrar('tesouraria', f'Lançou {tipo} #{cur.lastrowid}', f"{reg['descricao']} {brl(reg['valor'])}", conn)
            conn.commit()
            pendente = reg['aprovacao'] == 'pendente'
            msg = f'{tipo.capitalize()} adicionada' + (' (aguardando o "de acordo" da sede)' if pendente else '')
            return jsonify({'msg': msg, 'id': cur.lastrowid, 'pendente': pendente}), 201
        finally:
            conn.close()

    @app.route('/api/financeiro/receitas', methods=['POST'])
    @requer_permissao('tesouraria.criar')
    def criar_receita():
        return _inserir('receita', ('confirmada',), 'confirmada')

    @app.route('/api/financeiro/despesas', methods=['POST'])
    @requer_permissao('tesouraria.criar')
    def criar_despesa():
        return _inserir('despesa', STATUS_DESPESA, 'pendente')

    @app.route('/api/financeiro/<int:id>/status', methods=['PATCH'])
    @requer_permissao('tesouraria.editar')
    def alterar_status_despesa(id):
        try:
            status = opcao(request.get_json(silent=True) or {}, 'status', STATUS_DESPESA)
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        conn = get_db()
        try:
            _dt = conn.execute('SELECT data FROM financeiro WHERE id = ?', (id,)).fetchone()
            if _dt and periodo_fechado(conn, _dt[0]):
                return jsonify({'erro': msg_fechado(_dt[0])}), 409
            cur = conn.execute(
                "UPDATE financeiro SET status = ? WHERE id = ? AND tipo = 'despesa'", (status, id))
            if cur.rowcount == 0:
                return jsonify({'erro': 'Despesa não encontrada'}), 404
            registrar('tesouraria', f'Marcou despesa #{id} como {status}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Status atualizado'}), 200
        finally:
            conn.close()

    @app.route('/api/financeiro/<int:id>/aprovacao', methods=['PATCH'])
    @requer_permissao('tesouraria.aprovar')
    def aprovar_lancamento(id):
        data = request.get_json(silent=True) or {}
        try:
            status = opcao(data, 'status', ('aprovado', 'devolvido'))
            obs = texto(data, 'obs', max_len=500)
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        if status == 'devolvido' and not obs:
            return jsonify({'erro': 'Informe o motivo da devolução'}), 400
        conn = get_db()
        try:
            _dt = conn.execute('SELECT data FROM financeiro WHERE id = ?', (id,)).fetchone()
            if _dt and periodo_fechado(conn, _dt[0]):
                return jsonify({'erro': msg_fechado(_dt[0])}), 409
            cur = conn.execute('UPDATE financeiro SET aprovacao = ?, obs_aprovacao = ? WHERE id = ?', (status, obs, id))
            if cur.rowcount == 0:
                return jsonify({'erro': 'Lançamento não encontrado'}), 404
            registrar('tesouraria', f'{"De acordo no" if status == "aprovado" else "Devolveu o"} lançamento #{id}', obs, conn)
            conn.commit()
            return jsonify({'msg': 'De acordo registrado' if status == 'aprovado' else 'Devolvido à congregação'}), 200
        finally:
            conn.close()

    @app.route('/api/financeiro/contribuintes', methods=['GET'])
    @requer_permissao('tesouraria.contribuintes')
    def contribuintes():
        """Total de dízimos e ofertas por contribuinte no ano (informe anual)."""
        try:
            ano = inteiro(request.args, 'ano') or date.today().year
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        conn = get_db()
        try:
            rows = conn.execute('''
                SELECT m.id AS membro_id, m.nome,
                       (SELECT nome FROM congregacoes c WHERE c.id = m.congregacao_id) AS congregacao_nome,
                       SUM(CASE WHEN f.categoria = 'dizimo' THEN f.valor ELSE 0 END) AS dizimos,
                       SUM(CASE WHEN f.categoria != 'dizimo' THEN f.valor ELSE 0 END) AS outras,
                       COUNT(*) AS lancamentos, MAX(f.data) AS ultimo
                FROM financeiro f JOIN membros m ON m.id = f.membro_id
                WHERE f.tipo = 'receita' AND COALESCE(f.aprovacao, 'aprovado') = 'aprovado'
                  AND strftime('%Y', f.data) = ?
                GROUP BY m.id ORDER BY m.nome COLLATE NOCASE''', (str(ano),)).fetchall()
            return jsonify({'ano': ano, 'contribuintes': rows_to_dicts(rows)}), 200
        finally:
            conn.close()

    @app.route('/api/financeiro/<int:id>', methods=['DELETE'])
    @requer_permissao('tesouraria.deletar')
    def deletar_transacao(id):
        params = [id]
        where = _filtro_escopo(params)
        conn = get_db()
        try:
            _dt = conn.execute('SELECT data FROM financeiro WHERE id = ?', (id,)).fetchone()
            if _dt and periodo_fechado(conn, _dt[0]):
                return jsonify({'erro': msg_fechado(_dt[0])}), 409
            cur = conn.execute(f'DELETE FROM financeiro AS f WHERE f.id = ?{where}', params)
            if cur.rowcount == 0:
                return jsonify({'erro': 'Lançamento não encontrado'}), 404
            registrar('tesouraria', f'Excluiu lançamento #{id}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Lançamento removido'}), 200
        finally:
            conn.close()
