"""Rotas de segurança: 2FA, histórico de acessos, sessões, backups, integridade do log e LGPD."""
import json
import os
from datetime import date

from flask import request, jsonify, send_file
from flask_jwt_extended import jwt_required

from app.auditoria import registrar
from app.auth_utils import requer_permissao, usuario_atual, criar_token
from app.database import get_db, rows_to_dicts
from app.models import Perfil, Usuario
from app.seguranca import (novo_segredo_totp, verificar_totp, uri_totp, verificar_cadeia, fazer_backup,
                           listar_backups, DIR_BACKUP)

CAMPOS_PESSOAIS = ('email', 'telefone', 'celular', 'data_nascimento', 'endereco', 'bairro', 'cidade', 'estado', 'cep',
                   'cpf', 'rg', 'nome_pai', 'nome_mae', 'conjuge', 'naturalidade', 'profissao', 'observacoes')


def _erro(msg, codigo=400):
    return jsonify({'erro': str(msg)}), codigo


def registrar_seguranca(app):
    # ------------------------------------------------ minha conta: 2FA e sessões
    @app.route('/api/auth/minha-conta', methods=['GET'])
    @jwt_required()
    def minha_conta():
        conn = get_db()
        try:
            u = conn.execute('SELECT id, nome, email, totp_ativo, ultimo_login, senha_alterada_em, trocar_senha '
                             'FROM usuarios WHERE id = ?', (usuario_atual()['id'],)).fetchone()
            acessos = rows_to_dicts(conn.execute('SELECT data, ip, agente, sucesso, motivo FROM acessos '
                                                 'WHERE usuario_id = ? ORDER BY id DESC LIMIT 15', (u['id'],)))
            return jsonify({'usuario': dict(u), 'acessos': acessos}), 200
        finally:
            conn.close()

    @app.route('/api/auth/2fa/iniciar', methods=['POST'])
    @jwt_required()
    def iniciar_2fa():
        eu = usuario_atual()
        segredo = novo_segredo_totp()
        conn = get_db()
        try:
            if conn.execute('SELECT totp_ativo FROM usuarios WHERE id = ?', (eu['id'],)).fetchone()['totp_ativo']:
                return _erro('A verificação em duas etapas já está ativa')
            conn.execute('UPDATE usuarios SET totp_segredo = ? WHERE id = ?', (segredo, eu['id']))
            conn.commit()
        finally:
            conn.close()
        return jsonify({'segredo': segredo, 'uri': uri_totp(segredo, eu['email'])}), 200

    @app.route('/api/auth/2fa/ativar', methods=['POST'])
    @jwt_required()
    def ativar_2fa():
        eu = usuario_atual()
        conn = get_db()
        try:
            u = conn.execute('SELECT totp_segredo FROM usuarios WHERE id = ?', (eu['id'],)).fetchone()
            if not verificar_totp(u['totp_segredo'], (request.get_json(silent=True) or {}).get('codigo')):
                return _erro('Código incorreto. Confira a hora do celular e digite o código atual.')
            conn.execute('UPDATE usuarios SET totp_ativo = 1 WHERE id = ?', (eu['id'],))
            registrar('admin', 'Ativou a verificação em duas etapas', '', conn)
            conn.commit()
            return jsonify({'msg': 'Verificação em duas etapas ativada'}), 200
        finally:
            conn.close()

    @app.route('/api/auth/2fa/desativar', methods=['POST'])
    @jwt_required()
    def desativar_2fa():
        eu = usuario_atual()
        conn = get_db()
        try:
            u = conn.execute('SELECT senha_hash FROM usuarios WHERE id = ?', (eu['id'],)).fetchone()
            if not Usuario.verificar_senha((request.get_json(silent=True) or {}).get('senha') or '', u['senha_hash']):
                return _erro('Senha incorreta', 403)
            conn.execute('UPDATE usuarios SET totp_ativo = 0, totp_segredo = NULL WHERE id = ?', (eu['id'],))
            registrar('admin', 'Desativou a verificação em duas etapas', '', conn)
            conn.commit()
            return jsonify({'msg': 'Verificação em duas etapas desativada'}), 200
        finally:
            conn.close()

    @app.route('/api/auth/encerrar-sessoes', methods=['POST'])
    @jwt_required()
    def encerrar_sessoes():
        """Encerra as sessões abertas em outros aparelhos (celular perdido, computador compartilhado)."""
        uid = usuario_atual()['id']
        conn = get_db()
        try:
            conn.execute('UPDATE usuarios SET token_versao = COALESCE(token_versao, 0) + 1 WHERE id = ?', (uid,))
            registrar('admin', 'Encerrou as sessões em outros aparelhos', '', conn)
            conn.commit()
            novo = conn.execute('SELECT * FROM usuarios WHERE id = ?', (uid,)).fetchone()
            return jsonify({'msg': 'Sessões encerradas', 'access_token': criar_token(novo)}), 200
        finally:
            conn.close()

    # ------------------------------------------------ administração de contas
    def _pode_mexer(alvo_perfil):
        pasta = Perfil.pasta_que_administra(usuario_atual())
        return pasta == '*' or (pasta and (Perfil.obter(alvo_perfil) or {}).get('pasta') == pasta)

    @app.route('/api/admin/usuarios/<int:id>/desbloquear', methods=['POST'])
    @requer_permissao('admin.consultar')
    def desbloquear(id):
        conn = get_db()
        try:
            u = conn.execute('SELECT perfil_id, email FROM usuarios WHERE id = ?', (id,)).fetchone()
            if not u or not _pode_mexer(u['perfil_id']):
                return _erro('Sem permissão para esta conta', 403)
            reset_2fa = bool((request.get_json(silent=True) or {}).get('reset_2fa'))
            conn.execute('UPDATE usuarios SET falhas_login = 0, bloqueado_ate = NULL'
                         + (', totp_ativo = 0, totp_segredo = NULL' if reset_2fa else '') + ' WHERE id = ?', (id,))
            registrar('admin', f'Desbloqueou usuário #{id}' + (' e removeu o 2FA' if reset_2fa else ''), u['email'], conn)
            conn.commit()
            return jsonify({'msg': 'Conta desbloqueada' + (' e verificação em duas etapas removida' if reset_2fa else '')}), 200
        finally:
            conn.close()

    @app.route('/api/admin/acessos', methods=['GET'])
    @requer_permissao('admin.auditoria')
    def historico_acessos():
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('''SELECT a.*, u.nome FROM acessos a LEFT JOIN usuarios u ON u.id = a.usuario_id
                                                 ORDER BY a.id DESC LIMIT 500'''))
            resumo = conn.execute('''SELECT COUNT(*) AS falhas_24h FROM acessos WHERE sucesso = 0
                                     AND data >= datetime('now', '-1 day')''').fetchone()
            bloqueados = rows_to_dicts(conn.execute(
                "SELECT id, nome, email, bloqueado_ate FROM usuarios WHERE bloqueado_ate > ?",
                (date.today().isoformat(),)))
            return jsonify({'acessos': rows, 'falhas_24h': resumo['falhas_24h'], 'bloqueados': bloqueados}), 200
        finally:
            conn.close()

    @app.route('/api/admin/seguranca', methods=['GET'])
    @requer_permissao('admin.auditoria')
    def painel_seguranca():
        """Indicadores para o painel de segurança da Administração."""
        conn = get_db()
        try:
            u = conn.execute('''SELECT COUNT(*) AS ativos, SUM(totp_ativo) AS com_2fa, SUM(trocar_senha) AS senha_provisoria
                                FROM usuarios WHERE ativo = 1''').fetchone()
            admins_sem_2fa = rows_to_dicts(conn.execute(
                'SELECT nome, email, perfil_id FROM usuarios WHERE ativo = 1 AND COALESCE(totp_ativo, 0) = 0'))
            admins_sem_2fa = [x for x in admins_sem_2fa if x['perfil_id'] == 1 or (Perfil.obter(x['perfil_id']) or {}).get('admin_pasta')]
            senha_antiga = conn.execute("""SELECT COUNT(*) FROM usuarios WHERE ativo = 1 AND
                (senha_alterada_em IS NULL OR senha_alterada_em < date('now', '-180 day'))""").fetchone()[0]
            cadeia = verificar_cadeia(conn)
            from app.database import obter_config
            return jsonify({'usuarios_ativos': u['ativos'], 'com_2fa': u['com_2fa'] or 0,
                            'senha_provisoria': u['senha_provisoria'] or 0, 'senha_antiga': senha_antiga,
                            'chefes_sem_2fa': admins_sem_2fa, 'log_integro': cadeia,
                            'backups': listar_backups()[:10], 'modo_teste': obter_config('modo_teste', '1') == '1'}), 200
        finally:
            conn.close()

    @app.route('/api/admin/auditoria/verificar', methods=['GET'])
    @requer_permissao('admin.auditoria')
    def verificar_log():
        conn = get_db()
        try:
            return jsonify(verificar_cadeia(conn)), 200
        finally:
            conn.close()

    # ------------------------------------------------ backups
    @app.route('/api/admin/backups', methods=['GET'])
    @requer_permissao('admin.editar')
    def backups_listar():
        return jsonify({'backups': listar_backups(), 'pasta': DIR_BACKUP}), 200

    @app.route('/api/admin/backups', methods=['POST'])
    @requer_permissao('admin.editar')
    def backups_criar():
        nome = fazer_backup('manual')
        registrar('admin', 'Gerou backup manual', nome)
        return jsonify({'msg': 'Backup criado', 'nome': nome}), 201

    @app.route('/api/admin/backups/<nome>', methods=['GET'])
    @requer_permissao('admin.editar')
    def backups_baixar(nome):
        if '/' in nome or '\\' in nome or not nome.endswith('.db'):
            return _erro('Nome inválido')
        caminho = os.path.join(DIR_BACKUP, nome)
        if not os.path.isfile(caminho):
            return _erro('Backup não encontrado', 404)
        registrar('admin', 'Baixou backup', nome)
        return send_file(caminho, as_attachment=True, download_name=nome)

    # ------------------------------------------------ LGPD
    @app.route('/api/membros/<int:id>/dados-pessoais', methods=['GET'])
    @requer_permissao('membros.editar')
    def exportar_titular(id):
        """Relatório dos dados do titular (direito de acesso, art. 18 da LGPD)."""
        conn = get_db()
        try:
            m = conn.execute('SELECT * FROM membros WHERE id = ?', (id,)).fetchone()
            if not m:
                return _erro('Membro não encontrado', 404)
            docs = rows_to_dicts(conn.execute('SELECT tipo, numero, ano, criado_em FROM documentos WHERE membro_id = ?', (id,)))
            arqs = rows_to_dicts(conn.execute('SELECT titulo, categoria, criado_em FROM arquivos WHERE membro_id = ?', (id,)))
            registrar('membros', f'Exportou dados pessoais do membro #{id} (LGPD)', m['nome'], conn)
            conn.commit()
            corpo = json.dumps({'gerado_em': date.today().isoformat(), 'controlador': 'AD Belém – São José dos Campos',
                                'cadastro': dict(m), 'documentos_emitidos': docs, 'arquivos_guardados': arqs},
                               ensure_ascii=False, indent=2, default=str)
            return app.response_class(corpo, mimetype='application/json', headers={
                'Content-Disposition': f'attachment; filename=dados-membro-{id}.json'})
        finally:
            conn.close()

    @app.route('/api/membros/<int:id>/anonimizar', methods=['POST'])
    @requer_permissao('membros.deletar')
    def anonimizar(id):
        """Elimina os dados pessoais de quem saiu da igreja, mantendo os números históricos (art. 16 da LGPD)."""
        conn = get_db()
        try:
            m = conn.execute('SELECT nome, status FROM membros WHERE id = ?', (id,)).fetchone()
            if not m:
                return _erro('Membro não encontrado', 404)
            if m['status'] == 'ativo':
                return _erro('Só é possível anonimizar quem está inativo (desligado, transferido ou falecido)')
            conn.execute(f"UPDATE membros SET nome = ?, {', '.join(f'{c} = NULL' for c in CAMPOS_PESSOAIS)} WHERE id = ?",
                         (f'Titular anonimizado #{id}', id))
            conn.execute('UPDATE financeiro SET membro_id = NULL WHERE membro_id = ?', (id,))
            conn.execute('DELETE FROM membros_fotos WHERE membro_id = ?', (id,))
            conn.execute('UPDATE documentos SET membro_nome = ? WHERE membro_id = ?', (f'Titular anonimizado #{id}', id))
            registrar('membros', f'Anonimizou o membro #{id} (LGPD)', '', conn)
            conn.commit()
            return jsonify({'msg': 'Dados pessoais eliminados. Os registros históricos foram mantidos sem identificação.'}), 200
        finally:
            conn.close()
