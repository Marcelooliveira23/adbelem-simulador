"""Documentos editáveis por pasta: atas, contratos, contratos de imóveis, cartas, ofícios.

Enviar Word/PDF -> o sistema lê o texto e deixa editável -> cada "Salvar" cria uma revisão (histórico completo,
com quem alterou e o que mudou) -> exportar em Word (.docx) ou imprimir/salvar em PDF.
"Gerar novo" cria um documento a partir de outro (ex.: novo contrato de locação a partir do anterior).
"""
import os
import re
from datetime import date

from flask import request, jsonify, send_file

from app.auditoria import registrar
from app.auth_utils import requer_login, usuario_atual
from app.config import DATA_DIR
from app.database import get_db, rows_to_dicts
from app.documentos_editaveis import importar, limpar_html, gerar_docx, texto_puro
from app.models import Permissao
from app.validacao import ErroValidacao, texto, opcao

PASTAS = ('secretaria', 'tesouraria', 'patrimonio')
TIPOS = ('ata', 'contrato', 'contrato_imovel', 'carta', 'oficio', 'declaracao', 'regimento', 'outro')
LIMITE = 20 * 1024 * 1024
PASTA_ORIGINAIS = os.path.join(DATA_DIR, 'documentos_originais')


def _erro(msg, codigo=400):
    return jsonify({'erro': str(msg)}), codigo


def _pode(pasta, acao):
    return pasta in PASTAS and Permissao.tem_acesso(usuario_atual(), f'{pasta}.{acao}')


def _carregar(conn, did, acao='consultar'):
    d = conn.execute('SELECT * FROM docs_editaveis WHERE id = ?', (did,)).fetchone()
    if not d:
        raise LookupError
    if not _pode(d['pasta'], acao):
        raise PermissionError
    return d


def _nova_revisao(conn, did, versao, conteudo, comentario):
    conn.execute('INSERT INTO docs_revisoes (documento_id, versao, conteudo, comentario, autor) VALUES (?, ?, ?, ?, ?)',
                 (did, versao, conteudo, comentario, usuario_atual()['nome']))


def _criar(conn, titulo, tipo, pasta, conteudo, comentario, origem=None, gerado_de=None, modelo=0):
    eu = usuario_atual()['nome']
    cur = conn.execute('''INSERT INTO docs_editaveis (titulo, tipo, pasta, conteudo, versao, origem, gerado_de, modelo, criado_por, atualizado_por)
                          VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?)''', (titulo, tipo, pasta, conteudo, origem, gerado_de, modelo, eu, eu))
    _nova_revisao(conn, cur.lastrowid, 1, conteudo, comentario)
    return cur.lastrowid


def registrar_docs(app):
    @app.route('/api/docs', methods=['GET'])
    @requer_login
    def docs_listar():
        pastas = [p for p in PASTAS if _pode(p, 'consultar')]
        if request.args.get('pasta'):
            pastas = [p for p in pastas if p == request.args['pasta']]
        if not pastas:
            return _erro('Sem permissão', 403)
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute(f'''
                SELECT id, titulo, tipo, pasta, versao, status, modelo, origem, gerado_de, criado_por, atualizado_por, criado_em, atualizado_em,
                       arquivo_original IS NOT NULL AS tem_original
                FROM docs_editaveis WHERE pasta IN ({",".join("?" * len(pastas))}) ORDER BY atualizado_em DESC, id DESC''', pastas))
            return jsonify({'documentos': rows, 'pode_criar': [p for p in pastas if _pode(p, 'criar')]}), 200
        finally:
            conn.close()

    @app.route('/api/docs', methods=['POST'])
    @requer_login
    def docs_criar():
        d = request.get_json(silent=True) or {}
        try:
            pasta = opcao(d, 'pasta', PASTAS)
            if not pasta or not _pode(pasta, 'criar'):
                return _erro('Sem permissão para criar documentos nesta pasta', 403)
            titulo = texto(d, 'titulo', obrigatorio=True, max_len=200)
            tipo = opcao(d, 'tipo', TIPOS, padrao='outro')
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            did = _criar(conn, titulo, tipo, pasta, limpar_html(d.get('conteudo') or '<p></p>'), 'Criado em branco',
                         modelo=1 if d.get('modelo') else 0)
            registrar(pasta, f'Criou documento #{did}', titulo, conn)
            conn.commit()
            return jsonify({'msg': 'Documento criado', 'id': did}), 201
        finally:
            conn.close()

    @app.route('/api/docs/importar', methods=['POST'])
    @requer_login
    def docs_importar():
        f = request.form
        pasta = f.get('pasta')
        if pasta not in PASTAS or not _pode(pasta, 'criar'):
            return _erro('Sem permissão para enviar documentos nesta pasta', 403)
        arq = request.files.get('arquivo')
        if not arq:
            return _erro('Escolha o arquivo do Word ou PDF')
        dados = arq.read(LIMITE + 1)
        if len(dados) > LIMITE:
            return _erro('Arquivo maior que 20 MB')
        nome = arq.filename or 'documento'
        try:
            html = importar(nome, dados)
            titulo = texto(f, 'titulo', max_len=200) or os.path.splitext(os.path.basename(nome))[0]
            tipo = opcao(f, 'tipo', TIPOS, padrao='outro')
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            did = _criar(conn, titulo, tipo, pasta, html, f'Importado de {nome}', origem=nome)
            os.makedirs(PASTA_ORIGINAIS, exist_ok=True)
            ext = re.sub(r'[^a-z0-9]', '', os.path.splitext(nome)[1].lower())[:5]
            caminho = os.path.join(PASTA_ORIGINAIS, f'{did}.{ext}')
            with open(caminho, 'wb') as out:
                out.write(dados)
            conn.execute('UPDATE docs_editaveis SET arquivo_original = ? WHERE id = ?', (os.path.basename(caminho), did))
            registrar(pasta, f'Importou documento #{did}', f'{titulo} ({nome})', conn)
            conn.commit()
            return jsonify({'msg': 'Documento importado e pronto para editar', 'id': did, 'caracteres': len(texto_puro(html))}), 201
        finally:
            conn.close()

    @app.route('/api/docs/<int:did>', methods=['GET'])
    @requer_login
    def docs_obter(did):
        conn = get_db()
        try:
            d = _carregar(conn, did)
            return jsonify({**dict(d), 'pode_editar': _pode(d['pasta'], 'editar'), 'pode_criar': _pode(d['pasta'], 'criar')}), 200
        except LookupError:
            return _erro('Documento não encontrado', 404)
        except PermissionError:
            return _erro('Sem permissão', 403)
        finally:
            conn.close()

    @app.route('/api/docs/<int:did>', methods=['PUT'])
    @requer_login
    def docs_salvar(did):
        """Salvar = nova revisão (o conteúdo anterior continua guardado no histórico)."""
        d = request.get_json(silent=True) or {}
        conn = get_db()
        try:
            doc = _carregar(conn, did, 'editar')
            titulo = texto(d, 'titulo', max_len=200) or doc['titulo']
            status = opcao(d, 'status', ('rascunho', 'final'), padrao=doc['status'])
            tipo = opcao(d, 'tipo', TIPOS, padrao=doc['tipo'])
            novo = limpar_html(d['conteudo']) if 'conteudo' in d else doc['conteudo']
            comentario = texto(d, 'comentario', max_len=300)
            mudou = novo != doc['conteudo']
            versao = doc['versao'] + 1 if mudou else doc['versao']
            if mudou:
                _nova_revisao(conn, did, versao, novo, comentario or 'Edição')
            conn.execute('''UPDATE docs_editaveis SET titulo = ?, tipo = ?, status = ?, conteudo = ?, versao = ?, modelo = ?,
                              atualizado_por = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?''',
                         (titulo, tipo, status, novo, versao, 1 if d.get('modelo', doc['modelo']) else 0, usuario_atual()['nome'], did))
            registrar(doc['pasta'], f'Salvou documento #{did}' + (f' (revisão {versao})' if mudou else ''), comentario or titulo, conn)
            conn.commit()
            return jsonify({'msg': f'Salvo · revisão {versao}' if mudou else 'Salvo (sem alteração no texto)', 'versao': versao}), 200
        except LookupError:
            return _erro('Documento não encontrado', 404)
        except PermissionError:
            return _erro('Sem permissão para editar', 403)
        except ErroValidacao as e:
            return _erro(e)
        finally:
            conn.close()

    @app.route('/api/docs/<int:did>/revisoes', methods=['GET'])
    @requer_login
    def docs_revisoes(did):
        conn = get_db()
        try:
            _carregar(conn, did)
            rows = rows_to_dicts(conn.execute('''SELECT versao, comentario, autor, data, length(conteudo) AS tamanho
                                                 FROM docs_revisoes WHERE documento_id = ? ORDER BY versao DESC''', (did,)))
            return jsonify({'revisoes': rows}), 200
        except LookupError:
            return _erro('Documento não encontrado', 404)
        except PermissionError:
            return _erro('Sem permissão', 403)
        finally:
            conn.close()

    @app.route('/api/docs/<int:did>/revisoes/<int:versao>', methods=['GET'])
    @requer_login
    def docs_revisao(did, versao):
        conn = get_db()
        try:
            _carregar(conn, did)
            r = conn.execute('SELECT * FROM docs_revisoes WHERE documento_id = ? AND versao = ?', (did, versao)).fetchone()
            return (jsonify(dict(r)), 200) if r else _erro('Revisão não encontrada', 404)
        except LookupError:
            return _erro('Documento não encontrado', 404)
        except PermissionError:
            return _erro('Sem permissão', 403)
        finally:
            conn.close()

    @app.route('/api/docs/<int:did>/restaurar/<int:versao>', methods=['POST'])
    @requer_login
    def docs_restaurar(did, versao):
        """Volta ao texto de uma revisão antiga criando uma revisão nova (nada se perde)."""
        conn = get_db()
        try:
            doc = _carregar(conn, did, 'editar')
            r = conn.execute('SELECT conteudo FROM docs_revisoes WHERE documento_id = ? AND versao = ?', (did, versao)).fetchone()
            if not r:
                return _erro('Revisão não encontrada', 404)
            nova = doc['versao'] + 1
            _nova_revisao(conn, did, nova, r['conteudo'], f'Restaurado da revisão {versao}')
            conn.execute('UPDATE docs_editaveis SET conteudo = ?, versao = ?, atualizado_por = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?',
                         (r['conteudo'], nova, usuario_atual()['nome'], did))
            registrar(doc['pasta'], f'Restaurou documento #{did} para a revisão {versao}', doc['titulo'], conn)
            conn.commit()
            return jsonify({'msg': f'Revisão {versao} restaurada como revisão {nova}', 'versao': nova}), 200
        except LookupError:
            return _erro('Documento não encontrado', 404)
        except PermissionError:
            return _erro('Sem permissão para editar', 403)
        finally:
            conn.close()

    @app.route('/api/docs/<int:did>/duplicar', methods=['POST'])
    @requer_login
    def docs_duplicar(did):
        """Gerar novo documento a partir deste (nova carta, novo contrato de imóvel...)."""
        d = request.get_json(silent=True) or {}
        conn = get_db()
        try:
            doc = _carregar(conn, did)
            if not _pode(doc['pasta'], 'criar'):
                return _erro('Sem permissão para criar documentos nesta pasta', 403)
            titulo = texto(d, 'titulo', max_len=200) or f"{doc['titulo']} (novo {date.today().strftime('%d/%m/%Y')})"
            novo = _criar(conn, titulo, doc['tipo'], doc['pasta'], doc['conteudo'], f"Gerado a partir de \"{doc['titulo']}\" (rev. {doc['versao']})",
                          gerado_de=did)
            registrar(doc['pasta'], f'Gerou documento #{novo} a partir do #{did}', titulo, conn)
            conn.commit()
            return jsonify({'msg': 'Novo documento criado', 'id': novo}), 201
        except LookupError:
            return _erro('Documento não encontrado', 404)
        except PermissionError:
            return _erro('Sem permissão', 403)
        finally:
            conn.close()

    @app.route('/api/docs/<int:did>/word', methods=['GET'])
    @requer_login
    def docs_word(did):
        conn = get_db()
        try:
            doc = _carregar(conn, did)
            versao = request.args.get('versao')
            conteudo = doc['conteudo']
            if versao:
                r = conn.execute('SELECT conteudo FROM docs_revisoes WHERE documento_id = ? AND versao = ?', (did, versao)).fetchone()
                conteudo = r['conteudo'] if r else conteudo
            registrar(doc['pasta'], f'Exportou documento #{did} em Word', doc['titulo'], conn)
            conn.commit()
        except LookupError:
            return _erro('Documento não encontrado', 404)
        except PermissionError:
            return _erro('Sem permissão', 403)
        finally:
            conn.close()
        nome = re.sub(r'[^\w\- ]+', '', doc['titulo'], flags=re.UNICODE).strip()[:80] or 'documento'
        return app.response_class(gerar_docx(doc['titulo'], conteudo),
                                  mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                                  headers={'Content-Disposition': f"attachment; filename*=UTF-8''{__import__('urllib.parse').parse.quote(nome)}.docx"})

    @app.route('/api/docs/<int:did>/original', methods=['GET'])
    @requer_login
    def docs_original(did):
        conn = get_db()
        try:
            doc = _carregar(conn, did)
        except LookupError:
            return _erro('Documento não encontrado', 404)
        except PermissionError:
            return _erro('Sem permissão', 403)
        finally:
            conn.close()
        if not doc['arquivo_original']:
            return _erro('Este documento não veio de um arquivo', 404)
        caminho = os.path.join(PASTA_ORIGINAIS, os.path.basename(doc['arquivo_original']))
        if not os.path.isfile(caminho):
            return _erro('Arquivo original não encontrado', 404)
        return send_file(caminho, as_attachment=True, download_name=doc['origem'] or os.path.basename(caminho))

    @app.route('/api/docs/<int:did>', methods=['DELETE'])
    @requer_login
    def docs_excluir(did):
        conn = get_db()
        try:
            doc = _carregar(conn, did, 'deletar')
            conn.execute('DELETE FROM docs_revisoes WHERE documento_id = ?', (did,))
            conn.execute('DELETE FROM docs_editaveis WHERE id = ?', (did,))
            registrar(doc['pasta'], f'Excluiu documento #{did}', doc['titulo'], conn)
            conn.commit()
        except LookupError:
            return _erro('Documento não encontrado', 404)
        except PermissionError:
            return _erro('Sem permissão para excluir', 403)
        finally:
            conn.close()
        if doc['arquivo_original']:
            try:
                os.remove(os.path.join(PASTA_ORIGINAIS, os.path.basename(doc['arquivo_original'])))
            except OSError:
                pass
        return jsonify({'msg': 'Documento excluído'}), 200
