"""Compras (Secretaria/Patrimônio pedem, Financeiro aprova) e Almoxarifado (entrada geral, saída controlada).

Pedido de compra:  rascunho -> aguardando aprovação -> aprovado (gera a despesa na Tesouraria) | reprovado
                   -> entregue (opcional: cobra de cada congregação a sua parte, ex.: revistas da EBD)
Almoxarifado:      saldo = entradas - saídas (+ ajustes); saída nunca maior que o saldo.
"""
from datetime import date

from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao, usuario_atual
from app.crud import registrar_crud
from app.database import get_db, rows_to_dicts
from app.validacao import ErroValidacao, texto, numero, data_iso, inteiro, opcao, brl

TIPOS_PEDIDO = ('revistas_ebd', 'material', 'servico', 'outro')
CATEGORIA_DESPESA = {'revistas_ebd': 'material_ebd', 'material': 'material', 'servico': 'manutencao', 'outro': 'outro'}
CATEGORIAS_MATERIAL = ('limpeza', 'escritorio', 'ebd', 'santa_ceia', 'manutencao', 'copa', 'outro')


def _erro(msg, codigo=400):
    return jsonify({'erro': str(msg)}), codigo


def _ler_pedido(d):
    p = {
        'tipo': opcao(d, 'tipo', TIPOS_PEDIDO, 'revistas_ebd'),
        'descricao': texto(d, 'descricao', True, 200),
        'fornecedor': texto(d, 'fornecedor', max_len=150),
        'periodo': texto(d, 'periodo', max_len=60),
        'observacoes': texto(d, 'observacoes', max_len=1000),
    }
    itens = []
    for i, it in enumerate(d.get('itens') or [], start=1):
        try:
            itens.append({'descricao': texto(it, 'descricao', True, 150), 'congregacao_id': inteiro(it, 'congregacao_id'),
                          'quantidade': numero(it, 'quantidade', obrigatorio=True, positivo=True),
                          'valor_unitario': numero(it, 'valor_unitario', minimo=0)})
        except ErroValidacao as e:
            raise ErroValidacao(f'Item {i}: {e}')
    if not itens:
        raise ErroValidacao('Inclua ao menos um item no pedido')
    p['valor_total'] = round(sum(x['quantidade'] * x['valor_unitario'] for x in itens), 2)
    return p, itens


def registrar_compras_estoque(app):
    # =============================== Compras ===============================
    @app.route('/api/compras', methods=['GET'])
    @requer_permissao('compras.consultar')
    def listar_pedidos():
        conn = get_db()
        try:
            pedidos = rows_to_dicts(conn.execute('SELECT * FROM pedidos_compra ORDER BY id DESC LIMIT 300'))
            itens = rows_to_dicts(conn.execute('''SELECT i.*, COALESCE((SELECT nome FROM congregacoes c WHERE c.id = i.congregacao_id), 'Sede')
                                                  AS destino FROM pedidos_itens i'''))
            for p in pedidos:
                p['itens'] = [i for i in itens if i['pedido_id'] == p['id']]
            return jsonify({'pedidos': pedidos}), 200
        finally:
            conn.close()

    def _salvar_itens(conn, pedido_id, itens):
        conn.execute('DELETE FROM pedidos_itens WHERE pedido_id = ?', (pedido_id,))
        conn.executemany('INSERT INTO pedidos_itens (pedido_id, descricao, congregacao_id, quantidade, valor_unitario) VALUES (?,?,?,?,?)',
                         [(pedido_id, i['descricao'], i['congregacao_id'], i['quantidade'], i['valor_unitario']) for i in itens])

    @app.route('/api/compras', methods=['POST'])
    @requer_permissao('compras.criar')
    def criar_pedido():
        d = request.get_json(silent=True) or {}
        try:
            p, itens = _ler_pedido(d)
        except ErroValidacao as e:
            return _erro(e)
        p['status'] = 'aguardando_aprovacao' if d.get('enviar') else 'rascunho'
        p['solicitante'] = usuario_atual()['nome']
        conn = get_db()
        try:
            cols = list(p)
            cur = conn.execute(f'INSERT INTO pedidos_compra ({", ".join(cols)}) VALUES ({", ".join("?" * len(cols))})', [p[c] for c in cols])
            _salvar_itens(conn, cur.lastrowid, itens)
            registrar('compras', f'Criou pedido de compra #{cur.lastrowid}', f"{p['descricao']} {brl(p['valor_total'])}", conn)
            conn.commit()
            msg = 'Pedido enviado para aprovação do Financeiro' if p['status'] != 'rascunho' else 'Pedido salvo como rascunho'
            return jsonify({'msg': msg, 'id': cur.lastrowid}), 201
        finally:
            conn.close()

    @app.route('/api/compras/<int:id>', methods=['PUT'])
    @requer_permissao('compras.editar')
    def editar_pedido(id):
        try:
            p, itens = _ler_pedido(request.get_json(silent=True) or {})
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            atual = conn.execute('SELECT status FROM pedidos_compra WHERE id = ?', (id,)).fetchone()
            if not atual:
                return _erro('Pedido não encontrado', 404)
            if atual['status'] not in ('rascunho', 'reprovado'):
                return _erro('Só é possível alterar pedidos em rascunho ou reprovados', 409)
            conn.execute(f'UPDATE pedidos_compra SET {", ".join(f"{k} = ?" for k in p)}, status = ? WHERE id = ?',
                         [*p.values(), 'rascunho', id])
            _salvar_itens(conn, id, itens)
            registrar('compras', f'Editou pedido #{id}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Pedido atualizado'}), 200
        finally:
            conn.close()

    def _mudar_status(id, de, para, acao_log):
        conn = get_db()
        try:
            atual = conn.execute('SELECT * FROM pedidos_compra WHERE id = ?', (id,)).fetchone()
            if not atual:
                return None, _erro('Pedido não encontrado', 404), conn
            if atual['status'] not in de:
                return None, _erro(f"Ação não permitida com o pedido '{atual['status']}'", 409), conn
            return atual, None, conn
        except Exception:
            conn.close()
            raise

    @app.route('/api/compras/<int:id>/enviar', methods=['POST'])
    @requer_permissao('compras.criar')
    def enviar_pedido(id):
        atual, erro, conn = _mudar_status(id, ('rascunho', 'reprovado'), 'aguardando_aprovacao', 'Enviou')
        try:
            if erro:
                return erro
            conn.execute("UPDATE pedidos_compra SET status = 'aguardando_aprovacao' WHERE id = ?", (id,))
            registrar('compras', f'Enviou pedido #{id} para aprovação', '', conn)
            conn.commit()
            return jsonify({'msg': 'Pedido enviado para aprovação do Financeiro'}), 200
        finally:
            conn.close()

    @app.route('/api/compras/<int:id>/decidir', methods=['POST'])
    @requer_permissao('compras.aprovar')
    def decidir_pedido(id):
        d = request.get_json(silent=True) or {}
        try:
            decisao = opcao(d, 'decisao', ('aprovar', 'reprovar'))
            motivo = texto(d, 'motivo', max_len=500)
        except ErroValidacao as e:
            return _erro(e)
        if decisao == 'reprovar' and not motivo:
            return _erro('Informe o motivo da reprovação')
        atual, erro, conn = _mudar_status(id, ('aguardando_aprovacao',), None, '')
        try:
            if erro:
                return erro
            fin_id = None
            if decisao == 'aprovar':   # gera a despesa a pagar na Tesouraria
                cur = conn.execute('''INSERT INTO financeiro (tipo, descricao, valor, data, categoria, status, forma, usuario_id, aprovacao)
                                      VALUES ('despesa', ?, ?, date('now', 'localtime'), ?, 'pendente', 'transferencia', ?, 'aprovado')''',
                                   (f"Compra #{id}: {atual['descricao']}" + (f" ({atual['fornecedor']})" if atual['fornecedor'] else ''),
                                    atual['valor_total'], CATEGORIA_DESPESA[atual['tipo']], usuario_atual()['id']))
                fin_id = cur.lastrowid
            conn.execute('''UPDATE pedidos_compra SET status = ?, decidido_por = ?, decidido_em = datetime('now'), motivo = ?,
                            financeiro_id = ? WHERE id = ?''',
                         ('aprovado' if decisao == 'aprovar' else 'reprovado', usuario_atual()['nome'], motivo, fin_id, id))
            registrar('compras', f"{'Aprovou' if decisao == 'aprovar' else 'Reprovou'} pedido #{id}", motivo, conn)
            conn.commit()
            msg = (f"Pedido aprovado. Despesa de {brl(atual['valor_total'])} lançada na Tesouraria como 'a pagar'."
                   if decisao == 'aprovar' else 'Pedido reprovado e devolvido ao solicitante.')
            return jsonify({'msg': msg}), 200
        finally:
            conn.close()

    @app.route('/api/compras/<int:id>/entregar', methods=['POST'])
    @requer_permissao('compras.criar')
    def entregar_pedido(id):
        """Marca como entregue; opcionalmente cobra de cada congregação o valor dos itens destinados a ela."""
        cobrar = bool((request.get_json(silent=True) or {}).get('cobrar_congregacoes'))
        atual, erro, conn = _mudar_status(id, ('aprovado',), None, '')
        try:
            if erro:
                return erro
            cobrados = 0
            if cobrar:
                for c in conn.execute('''SELECT congregacao_id, SUM(quantidade * valor_unitario) AS total FROM pedidos_itens
                                         WHERE pedido_id = ? AND congregacao_id IS NOT NULL GROUP BY congregacao_id''', (id,)):
                    if c['total'] > 0:
                        conn.execute('INSERT INTO congregacao_debitos (congregacao_id, descricao, valor, pedido_id) VALUES (?,?,?,?)',
                                     (c['congregacao_id'], f"{atual['descricao']} (pedido #{id})", round(c['total'], 2), id))
                        cobrados += 1
            conn.execute("UPDATE pedidos_compra SET status = 'entregue', entregue_em = datetime('now') WHERE id = ?", (id,))
            registrar('compras', f'Pedido #{id} entregue', f'{cobrados} congregação(ões) cobrada(s)', conn)
            conn.commit()
            return jsonify({'msg': 'Entrega registrada' + (f'; {cobrados} congregação(ões) com débito para o próximo acerto' if cobrados else ''),
                            'cobradas': cobrados}), 200
        finally:
            conn.close()

    @app.route('/api/compras/<int:id>', methods=['DELETE'])
    @requer_permissao('compras.criar')
    def excluir_pedido(id):
        atual, erro, conn = _mudar_status(id, ('rascunho', 'reprovado'), None, '')
        try:
            if erro:
                return erro
            conn.execute('DELETE FROM pedidos_itens WHERE pedido_id = ?', (id,))
            conn.execute('DELETE FROM pedidos_compra WHERE id = ?', (id,))
            registrar('compras', f'Excluiu pedido #{id}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Pedido excluído'}), 200
        finally:
            conn.close()

    # ============================ Almoxarifado ============================
    registrar_crud(app, rota='almoxarifado/materiais', tabela='materiais', modulo='patrimonio', chave_lista='materiais',
                   rotulo='material', ordem='t.nome COLLATE NOCASE', campos={
                       'nome': lambda d: texto(d, 'nome', True, 120),
                       'categoria': lambda d: opcao(d, 'categoria', CATEGORIAS_MATERIAL, 'outro'),
                       'unidade_medida': lambda d: texto(d, 'unidade_medida', max_len=10) or 'un',
                       'estoque_minimo': lambda d: numero(d, 'estoque_minimo', minimo=0),
                       'ativo': lambda d: 0 if str(d.get('ativo', '1')) in ('0', 'false') else 1,
                   })

    SALDO = '''COALESCE((SELECT SUM(CASE WHEN tipo = 'saida' THEN -quantidade ELSE quantidade END)
                         FROM materiais_mov v WHERE v.material_id = m.id), 0)'''

    @app.route('/api/almoxarifado/saldos', methods=['GET'])
    @requer_permissao('patrimonio.consultar')
    def saldos():
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute(f'''
                SELECT m.*, {SALDO} AS saldo,
                       (SELECT SUM(quantidade * valor_unitario) / NULLIF(SUM(quantidade), 0) FROM materiais_mov v
                         WHERE v.material_id = m.id AND v.tipo = 'entrada' AND valor_unitario > 0) AS custo_medio
                FROM materiais m ORDER BY m.ativo DESC, m.nome COLLATE NOCASE'''))
            for r in rows:
                r['abaixo_minimo'] = bool(r['ativo'] and r['estoque_minimo'] and r['saldo'] < r['estoque_minimo'])
            return jsonify({'materiais': rows, 'abaixo_minimo': sum(r['abaixo_minimo'] for r in rows)}), 200
        finally:
            conn.close()

    @app.route('/api/almoxarifado/movimentos', methods=['GET'])
    @requer_permissao('patrimonio.consultar')
    def movimentos_estoque():
        params, where = [], ''
        if request.args.get('material_id'):
            where, params = ' WHERE v.material_id = ?', [request.args.get('material_id')]
        conn = get_db()
        try:
            rows = conn.execute(f'''SELECT v.*, m.nome AS material, m.unidade_medida,
                                           COALESCE((SELECT nome FROM congregacoes c WHERE c.id = v.destino_congregacao_id), '') AS destino
                                    FROM materiais_mov v JOIN materiais m ON m.id = v.material_id{where}
                                    ORDER BY v.data DESC, v.id DESC LIMIT 1000''', params).fetchall()
            return jsonify({'movimentos': rows_to_dicts(rows)}), 200
        finally:
            conn.close()

    @app.route('/api/almoxarifado/movimentos', methods=['POST'])
    @requer_permissao('patrimonio.criar')
    def registrar_movimento_estoque():
        d = request.get_json(silent=True) or {}
        try:
            m = {
                'material_id': inteiro(d, 'material_id', obrigatorio=True),
                'tipo': opcao(d, 'tipo', ('entrada', 'saida', 'ajuste')),
                'quantidade': numero(d, 'quantidade', obrigatorio=True),
                'valor_unitario': numero(d, 'valor_unitario', minimo=0),
                'data': data_iso(d, 'data') or date.today().isoformat(),
                'origem': texto(d, 'origem', max_len=120),
                'destino_congregacao_id': inteiro(d, 'destino_congregacao_id'),
                'recebido_por': texto(d, 'recebido_por', max_len=120),
                'observacao': texto(d, 'observacao', max_len=500),
            }
            if m['tipo'] != 'ajuste' and m['quantidade'] <= 0:
                raise ErroValidacao('A quantidade deve ser maior que zero')
            if m['tipo'] == 'saida' and not (m['destino_congregacao_id'] or m['recebido_por']):
                raise ErroValidacao('Na saída, informe a congregação de destino ou quem recebeu')
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            mat = conn.execute(f'SELECT m.nome, m.unidade_medida, {SALDO} AS saldo FROM materiais m WHERE m.id = ?',
                               (m['material_id'],)).fetchone()
            if not mat:
                return _erro('Material não encontrado', 404)
            if m['tipo'] == 'saida' and m['quantidade'] > mat['saldo'] + 1e-9:
                return _erro(f"Saldo insuficiente: há {mat['saldo']:g} {mat['unidade_medida']} de {mat['nome']} em estoque")
            m['criado_por'] = usuario_atual()['nome']
            cols = list(m)
            cur = conn.execute(f'INSERT INTO materiais_mov ({", ".join(cols)}) VALUES ({", ".join("?" * len(cols))})', [m[c] for c in cols])
            registrar('patrimonio', f"{m['tipo'].capitalize()} de material #{cur.lastrowid}", f"{mat['nome']}: {m['quantidade']:g}", conn)
            conn.commit()
            novo = mat['saldo'] + (-m['quantidade'] if m['tipo'] == 'saida' else m['quantidade'])
            return jsonify({'msg': f"{'Entrada' if m['tipo'] == 'entrada' else 'Saída' if m['tipo'] == 'saida' else 'Ajuste'} registrada. "
                                   f"Saldo de {mat['nome']}: {novo:g} {mat['unidade_medida']}", 'id': cur.lastrowid}), 201
        finally:
            conn.close()
