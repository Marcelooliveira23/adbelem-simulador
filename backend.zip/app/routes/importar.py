"""Rotas do importador: ler fonte -> analisar (novos, duplicados, inválidos) -> executar."""
from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_login, usuario_atual
from app.database import get_db
from app.importacao import (DESTINOS, ErroValidacao, norm, digitos, data_br, dinheiro, por_sinonimo, sugerir_mapa,
                            ler_arquivo, mysql_tabelas, mysql_ler, guardar, carregar, descartar,
                            SEXO, STATUS_MEMBRO, ESTADO_CIVIL, FUNCOES, CATEGORIA_BEM, STATUS_BEM, TIPO_FUNC)
from app.models import Permissao
from app.routes.membros import CAMPOS as CAMPOS_MEMBRO
from app.routes.patrimonio import CAMPOS as CAMPOS_BEM
from app.routes.pessoal import CAMPOS as CAMPOS_FUNC
from app.seguranca import fazer_backup
from app.validacao import texto

LIMITE_ARQUIVO = 25 * 1024 * 1024
DATAS = {'membros': ('data_nascimento', 'data_batismo', 'data_conversao', 'data_admissao'),
         'patrimonio': ('data_aquisicao',), 'funcionarios': ('data_admissao',), 'fornecedores': ()}
CAMPOS_FORN = {c: (lambda c: lambda d: texto(d, c, obrigatorio=(c == 'nome'), max_len=250))(c)
               for c, _r, _s in DESTINOS['fornecedores']['campos']}
VALIDADORES = {'membros': CAMPOS_MEMBRO, 'patrimonio': CAMPOS_BEM, 'funcionarios': CAMPOS_FUNC, 'fornecedores': CAMPOS_FORN}


def _erro(msg, codigo=400):
    return jsonify({'erro': str(msg)}), codigo


def _texto(v):
    if v is None:
        return ''
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def converter(destino, linha, mapa, ctx):
    """Linha da origem -> registro pronto para gravar. Devolve (registro, avisos). Lança ErroValidacao se inválida."""
    bruto = {campo: linha.get(col) for campo, col in mapa.items() if col}
    avisos, d = [], {}
    for campo, v in bruto.items():
        if campo in DATAS[destino]:
            try:
                d[campo] = data_br(v)
            except ErroValidacao as e:
                avisos.append(f'{campo}: {e} (ficou em branco)')
        elif campo in ('valor', 'remuneracao'):
            d[campo] = dinheiro(v)
        else:
            d[campo] = _texto(v)
    if 'congregacao' in d:                       # nome da congregação -> id
        nome = d.pop('congregacao')
        if nome and norm(nome) not in ('sede', 'matriz', 'templo sede', 'sede central'):
            d['congregacao_id'] = ctx['congregacoes'].get(norm(nome))
            if not d['congregacao_id']:
                avisos.append(f'congregação "{nome}" não cadastrada (ficou na Sede)')
    if destino == 'membros':
        if 'sexo' in d:
            d['sexo'] = por_sinonimo(d['sexo'], SEXO, '')
        if 'status' in d:
            d['status'] = por_sinonimo(d['status'], STATUS_MEMBRO, 'ativo')
        if 'estado_civil' in d:
            d['estado_civil'] = por_sinonimo(d['estado_civil'], ESTADO_CIVIL, '')
        if 'funcao' in d:
            original = d['funcao']
            d['funcao'] = por_sinonimo(original, FUNCOES, 'Membro')
            if original and d['funcao'] == 'Membro' and norm(original) != 'membro':
                avisos.append(f'função "{original}" ficou como Membro')
        if d.get('cpf') and len(digitos(d['cpf'])) == 10:
            d['cpf'] = '0' + digitos(d['cpf'])   # CPF que perdeu o zero à esquerda na planilha
    elif destino == 'patrimonio':
        d['categoria'] = por_sinonimo(d.get('categoria'), CATEGORIA_BEM, 'outro') if d.get('categoria') else \
            por_sinonimo(d.get('nome'), CATEGORIA_BEM, 'outro')
        d['status'] = por_sinonimo(d.get('status'), STATUS_BEM, 'bom')
        d['local'] = d.get('local') or 'Não informado'
    elif destino == 'funcionarios':
        d['tipo'] = por_sinonimo(d.get('tipo'), TIPO_FUNC, 'clt')
    reg = {}
    validadores = VALIDADORES[destino]
    for campo in list(d) + ['nome']:
        if campo in reg or campo not in validadores:
            if campo == 'congregacao_id':
                reg[campo] = d[campo]
            continue
        try:
            reg[campo] = validadores[campo](d)
        except ErroValidacao as e:
            if campo == 'nome':
                raise ErroValidacao('sem nome / descrição')
            if campo == 'cpf':
                avisos.append(f'CPF "{d.get("cpf")}" inválido (ficou em branco)')
                reg[campo] = None
            else:
                avisos.append(f'{campo}: {e} (ficou em branco)')
    return reg, avisos


def _indices(conn, destino):
    idx = {}
    if destino == 'membros':
        for r in conn.execute('SELECT id, nome, cpf, data_nascimento FROM membros'):
            if digitos(r['cpf']):
                idx[('cpf', digitos(r['cpf']))] = (r['id'], r['nome'])
            if r['data_nascimento']:
                idx[('nome_nasc', norm(r['nome']), r['data_nascimento'])] = (r['id'], r['nome'])
            idx.setdefault(('nome', norm(r['nome'])), (r['id'], r['nome']))
    elif destino == 'patrimonio':
        for r in conn.execute('SELECT id, nome, tombo, numero_serie, local, congregacao_id FROM patrimonio'):
            if r['tombo']:
                idx[('tombo', norm(r['tombo']))] = (r['id'], r['nome'])
            if r['numero_serie']:
                idx[('serie', norm(r['numero_serie']))] = (r['id'], r['nome'])
            idx[('nome_local', norm(r['nome']), norm(r['local']), r['congregacao_id'])] = (r['id'], r['nome'])
    else:
        doc = 'documento' if destino == 'fornecedores' else 'cpf'
        for r in conn.execute(f'SELECT id, nome, {doc} AS doc FROM {destino}'):
            if digitos(r['doc']):
                idx[('doc', digitos(r['doc']))] = (r['id'], r['nome'])
            idx.setdefault(('nome', norm(r['nome'])), (r['id'], r['nome']))
    return idx


def _chaves(destino, reg):
    if destino == 'membros':
        ch = []
        if digitos(reg.get('cpf')):
            ch.append((('cpf', digitos(reg['cpf'])), 'mesmo CPF'))
        if reg.get('data_nascimento'):
            ch.append((('nome_nasc', norm(reg['nome']), reg['data_nascimento']), 'mesmo nome e nascimento'))
        ch.append((('nome', norm(reg['nome'])), 'mesmo nome'))
        return ch
    if destino == 'patrimonio':
        ch = []
        if reg.get('tombo'):
            ch.append((('tombo', norm(reg['tombo'])), 'mesmo nº de tombo'))
        if reg.get('numero_serie'):
            ch.append((('serie', norm(reg['numero_serie'])), 'mesmo nº de série'))
        ch.append((('nome_local', norm(reg['nome']), norm(reg.get('local')), reg.get('congregacao_id')), 'mesma descrição e local'))
        return ch
    doc = reg.get('documento' if destino == 'fornecedores' else 'cpf')
    return ([(('doc', digitos(doc)), 'mesmo CNPJ/CPF')] if digitos(doc) else []) + [(('nome', norm(reg['nome'])), 'mesmo nome')]


def analisar(conn, destino, linhas, mapa):
    ctx = {'congregacoes': {norm(r['nome']): r['id'] for r in conn.execute('SELECT id, nome FROM congregacoes')}}
    idx, vistos = _indices(conn, destino), {}
    res = {'total': len(linhas), 'novos': [], 'duplicados': [], 'invalidos': [], 'avisos': []}
    for n, linha in enumerate(linhas, start=2):          # linha 1 = cabeçalho
        try:
            reg, avisos = converter(destino, linha, mapa, ctx)
        except ErroValidacao as e:
            res['invalidos'].append({'linha': n, 'erro': str(e)})
            continue
        res['avisos'] += [{'linha': n, 'aviso': a} for a in avisos]
        chaves = _chaves(destino, reg)
        dup = next(((idx[k], motivo) for k, motivo in chaves if k in idx), None)
        if dup:
            res['duplicados'].append({'linha': n, 'nome': reg['nome'], 'motivo': f'já cadastrado ({dup[1]})',
                                      'existente_id': dup[0][0], 'existente': dup[0][1], 'registro': reg})
            continue
        repetida = next(((vistos[k], motivo) for k, motivo in chaves if k in vistos), None)
        if repetida:
            res['duplicados'].append({'linha': n, 'nome': reg['nome'], 'motivo': f'repetido na planilha (linha {repetida[0]}, {repetida[1]})'})
            continue
        for k, _m in chaves:
            vistos[k] = n
        res['novos'].append(reg)
    return res


def registrar_importar(app):
    def _permitidos():
        eu = usuario_atual()
        return [k for k, v in DESTINOS.items() if Permissao.tem_acesso(eu, v['permissao'])]

    @app.route('/api/importar/destinos', methods=['GET'])
    @requer_login
    def importar_destinos():
        return jsonify({'destinos': [{'chave': k, 'rotulo': DESTINOS[k]['rotulo'],
                                      'campos': [{'campo': c, 'rotulo': r} for c, r, _s in DESTINOS[k]['campos']]}
                                     for k in _permitidos()]}), 200

    @app.route('/api/importar/ler', methods=['POST'])
    @requer_login
    def importar_ler():
        if not _permitidos():
            return _erro('Sem permissão para importar', 403)
        try:
            if 'arquivo' in request.files:
                arq = request.files['arquivo']
                dados = arq.read(LIMITE_ARQUIVO + 1)
                if len(dados) > LIMITE_ARQUIVO:
                    return _erro('Arquivo maior que 25 MB')
                tabelas, fonte = ler_arquivo(arq.filename or '', dados), arq.filename
            else:
                d = request.get_json(silent=True) or {}
                p = d.get('mysql') or {}
                if not p.get('banco'):
                    return _erro('Envie um arquivo ou informe a conexão MySQL (servidor, usuário, senha e banco)')
                if not d.get('tabela'):
                    return jsonify({'mysql_tabelas': mysql_tabelas(p)}), 200      # 1º passo: escolher a tabela
                tabelas, fonte = mysql_ler(p, d['tabela']), f"MySQL {p.get('host') or 'localhost'}/{p['banco']}"
        except ErroValidacao as e:
            return _erro(e)
        token = guardar(fonte, tabelas)
        registrar('admin', 'Leu fonte para importação', f'{fonte}: {sum(len(t["linhas"]) for t in tabelas.values())} linha(s)')
        return jsonify({'token': token, 'fonte': fonte, 'tabelas': [
            {'nome': n, 'colunas': t['colunas'], 'total': len(t['linhas']), 'amostra': t['linhas'][:3]} for n, t in tabelas.items()]}), 200

    def _preparar(d):
        destino = d.get('destino')
        if destino not in DESTINOS:
            raise ErroValidacao('Escolha o tipo de cadastro')
        if destino not in _permitidos():
            raise PermissionError
        dados = carregar(d.get('token'))
        tab = dados['tabelas'].get(d.get('tabela')) or (next(iter(dados['tabelas'].values())) if len(dados['tabelas']) == 1 else None)
        if not tab:
            raise ErroValidacao('Escolha a planilha/tabela')
        mapa = {k: v for k, v in (d.get('mapa') or sugerir_mapa(destino, tab['colunas'])).items() if v in tab['colunas']}
        if 'nome' not in mapa:
            raise ErroValidacao('Indique qual coluna tem o nome / descrição')
        return destino, dados, tab, mapa

    @app.route('/api/importar/analisar', methods=['POST'])
    @requer_login
    def importar_analisar():
        d = request.get_json(silent=True) or {}
        try:
            destino, _dados, tab, mapa = _preparar(d)
        except PermissionError:
            return _erro('Sem permissão para este cadastro', 403)
        except ErroValidacao as e:
            if 'nome' in str(e) and d.get('destino') in DESTINOS:
                dados = carregar(d.get('token')) if d.get('token') else None
                tab = dados and (dados['tabelas'].get(d.get('tabela')) or next(iter(dados['tabelas'].values())))
                return jsonify({'erro': str(e), 'mapa': sugerir_mapa(d['destino'], tab['colunas']) if tab else {}}), 400
            return _erro(e)
        conn = get_db()
        try:
            r = analisar(conn, destino, tab['linhas'], mapa)
        finally:
            conn.close()
        return jsonify({'mapa': mapa, 'total': r['total'], 'novos': len(r['novos']), 'amostra_novos': r['novos'][:5],
                        'duplicados': [{k: v for k, v in x.items() if k != 'registro'} for x in r['duplicados'][:300]],
                        'qtd_duplicados': len(r['duplicados']), 'invalidos': r['invalidos'][:300], 'qtd_invalidos': len(r['invalidos']),
                        'avisos': r['avisos'][:300], 'qtd_avisos': len(r['avisos'])}), 200

    @app.route('/api/importar/executar', methods=['POST'])
    @requer_login
    def importar_executar():
        d = request.get_json(silent=True) or {}
        try:
            destino, dados, tab, mapa = _preparar(d)
        except PermissionError:
            return _erro('Sem permissão para este cadastro', 403)
        except ErroValidacao as e:
            return _erro(e)
        modo = d.get('duplicados') if d.get('duplicados') in ('ignorar', 'completar') else 'ignorar'
        backup = fazer_backup('importacao')
        tabela = DESTINOS[destino]['tabela']
        conn = get_db()
        try:
            r = analisar(conn, destino, tab['linhas'], mapa)
            for reg in r['novos']:
                if destino in ('membros', 'patrimonio'):
                    reg = {**reg, 'aprovacao': 'aprovado'}
                cols = list(reg)
                conn.execute(f'INSERT INTO {tabela} ({", ".join(cols)}) VALUES ({", ".join("?" for _ in cols)})', [reg[c] for c in cols])
            completados = 0
            if modo == 'completar':                     # só preenche o que está vazio no cadastro existente
                for dup in r['duplicados']:
                    if not dup.get('existente_id'):
                        continue
                    campos = [c for c, v in dup['registro'].items() if v not in (None, '') and c != 'nome']
                    if campos:
                        conn.execute(f'UPDATE {tabela} SET ' + ', '.join(
                            f"{c} = CASE WHEN {c} IS NULL OR {c} = '' THEN ? ELSE {c} END" for c in campos) + ' WHERE id = ?',
                            [dup['registro'][c] for c in campos] + [dup['existente_id']])
                        completados += 1
            registrar(DESTINOS[destino]['permissao'].split('.')[0], f'Importou {DESTINOS[destino]["rotulo"]}',
                      f"{dados['fonte']}: {len(r['novos'])} novo(s), {len(r['duplicados'])} duplicado(s) "
                      f"({'completados' if modo == 'completar' else 'ignorados'}), {len(r['invalidos'])} inválido(s). Backup {backup}", conn)
            conn.commit()
        finally:
            conn.close()
        descartar(d.get('token'))
        return jsonify({'msg': f"{len(r['novos'])} cadastro(s) importado(s)", 'inseridos': len(r['novos']), 'completados': completados,
                        'duplicados': len(r['duplicados']), 'invalidos': len(r['invalidos']), 'backup': backup}), 201
