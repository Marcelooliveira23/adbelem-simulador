from datetime import datetime

from flask import request, jsonify

from app.auth_utils import requer_permissao, escopo_congregacao
from app.database import get_db, rows_to_dicts
from app.validacao import ErroValidacao, data_iso


def _filtro_unidade():
    """Cláusula e parâmetros para restringir a uma unidade (dirigente ou ?congregacao_id=)."""
    cong = escopo_congregacao()
    if cong is None:
        pedido = request.args.get('congregacao_id')
        if pedido == 'sede':
            return ' AND congregacao_id IS NULL', []
        if pedido:
            cong = int(pedido)
    if cong is not None:
        return ' AND congregacao_id = ?', [cong]
    return '', []


def registrar_relatorios(app):

    @app.route('/api/relatorios', methods=['GET'])
    @requer_permissao('relatorios.consultar')
    def obter_relatorios():
        try:
            data_inicio = data_iso(request.args, 'data_inicio')
            data_fim = data_iso(request.args, 'data_fim')
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400

        unid, p_unid = _filtro_unidade()
        # Membros e bens: só os aprovados; financeiro: aprovados e dentro do período
        mem = f"WHERE COALESCE(aprovacao, 'aprovado') = 'aprovado'{unid}"
        pat = f"WHERE COALESCE(aprovacao, 'aprovado') = 'aprovado'{unid}"
        fin, p_fin = f"WHERE COALESCE(aprovacao, 'aprovado') = 'aprovado'{unid}", list(p_unid)
        if data_inicio:
            fin += ' AND data >= ?'
            p_fin.append(data_inicio)
        if data_fim:
            fin += ' AND data <= ?'
            p_fin.append(data_fim)

        conn = get_db()
        try:
            def valor(sql, p=()):
                return conn.execute(sql, p).fetchone()[0] or 0

            def lista(sql, p=()):
                return rows_to_dicts(conn.execute(sql, p))

            # ---------- MEMBROS ----------
            total_membros = valor(f'SELECT COUNT(*) FROM membros {mem}', p_unid)
            membros_ativos = valor(f"SELECT COUNT(*) FROM membros {mem} AND status = 'ativo'", p_unid)
            membros_visitantes = valor(f"SELECT COUNT(*) FROM membros {mem} AND status = 'visitante'", p_unid)
            membros_cadastrados_mes = valor(
                f"SELECT COUNT(*) FROM membros {mem} AND data_cadastro >= date('now', 'localtime', 'start of month')",
                p_unid)
            membros_por_status = lista(
                f'SELECT status, COUNT(*) AS total FROM membros {mem} GROUP BY status ORDER BY total DESC', p_unid)
            membros_por_funcao = lista(
                f"SELECT COALESCE(funcao, 'Membro') AS funcao, COUNT(*) AS total FROM membros {mem} "
                f'GROUP BY 1 ORDER BY total DESC', p_unid)
            membros_recentes = lista(f'''
                SELECT nome, email, telefone, status, data_cadastro FROM membros {mem}
                ORDER BY data_cadastro DESC, id DESC LIMIT 10''', p_unid)

            # ---------- FINANCEIRO (no período) ----------
            total_receitas = valor(f"SELECT SUM(valor) FROM financeiro {fin} AND tipo = 'receita'", p_fin)
            total_despesas = valor(f"SELECT SUM(valor) FROM financeiro {fin} AND tipo = 'despesa'", p_fin)
            total_dizimos = valor(
                f"SELECT SUM(valor) FROM financeiro {fin} AND tipo = 'receita' AND categoria = 'dizimo'", p_fin)
            receitas_por_categoria = lista(f'''
                SELECT categoria, SUM(valor) AS total FROM financeiro {fin} AND tipo = 'receita'
                GROUP BY categoria ORDER BY total DESC''', p_fin)
            despesas_por_categoria = lista(f'''
                SELECT categoria, SUM(valor) AS total FROM financeiro {fin} AND tipo = 'despesa'
                GROUP BY categoria ORDER BY total DESC''', p_fin)
            transacoes = lista(f'''
                SELECT id, data, descricao, tipo, valor, categoria, status FROM financeiro {fin}
                ORDER BY data DESC, id DESC''', p_fin)
            por_unidade = lista(f'''
                SELECT COALESCE((SELECT nome FROM congregacoes c WHERE c.id = f.congregacao_id), 'Sede') AS unidade,
                       SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END) AS receitas,
                       SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END) AS despesas
                FROM financeiro f {fin} GROUP BY f.congregacao_id ORDER BY unidade''', p_fin)

            # ---------- PATRIMÔNIO ----------
            total_bens = valor(f'SELECT COUNT(*) FROM patrimonio {pat}', p_unid)
            bens_em_bom = valor(f"SELECT COUNT(*) FROM patrimonio {pat} AND status = 'bom'", p_unid)
            bens_manutencao = valor(f"SELECT COUNT(*) FROM patrimonio {pat} AND status = 'manutencao'", p_unid)
            valor_patrimonio = valor(f"SELECT SUM(valor) FROM patrimonio {pat} AND status != 'descartado'", p_unid)
            bens_por_categoria = lista(
                f'SELECT categoria, COUNT(*) AS total FROM patrimonio {pat} GROUP BY categoria ORDER BY total DESC', p_unid)
            bens_por_status = lista(
                f'SELECT status, COUNT(*) AS total FROM patrimonio {pat} GROUP BY status ORDER BY total DESC', p_unid)
            bens_manutencao_list = lista(f'''
                SELECT nome, local, valor, observacoes FROM patrimonio {pat} AND status = 'manutencao'
                ORDER BY nome COLLATE NOCASE''', p_unid)
        finally:
            conn.close()

        saldo = round(total_receitas - total_despesas, 2)
        agora = datetime.now().isoformat()
        saldo_txt = f'{saldo:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
        return jsonify({
            'periodo': {'inicio': data_inicio, 'fim': data_fim},
            'total_membros': total_membros,
            'membros_ativos': membros_ativos,
            'membros_visitantes': membros_visitantes,
            'membros_cadastrados_mes': membros_cadastrados_mes,
            'membros_por_status': membros_por_status,
            'membros_por_funcao': membros_por_funcao,
            'membros_recentes': membros_recentes,
            'total_receitas': round(total_receitas, 2),
            'total_despesas': round(total_despesas, 2),
            'saldo_financeiro': saldo,
            'total_dizimos': round(total_dizimos, 2),
            'receitas_por_categoria': receitas_por_categoria,
            'despesas_por_categoria': despesas_por_categoria,
            'financeiro_por_unidade': por_unidade,
            'transacoes': transacoes,
            'total_bens': total_bens,
            'bens_em_bom': bens_em_bom,
            'bens_manutencao': bens_manutencao,
            'valor_patrimonio': round(valor_patrimonio, 2),
            'bens_por_categoria': bens_por_categoria,
            'bens_por_status': bens_por_status,
            'bens_manutencao_list': bens_manutencao_list,
            'atividades': [
                {'data': agora, 'descricao': f'{total_membros} membro(s) cadastrado(s)', 'modulo': 'Membros'},
                {'data': agora, 'descricao': f'Saldo do período: R$ {saldo_txt}', 'modulo': 'Financeiro'},
                {'data': agora, 'descricao': f'{total_bens} bem(ns) no patrimônio', 'modulo': 'Patrimônio'},
            ],
        }), 200
