"""Níveis de acesso configuráveis: a Administração liga e desliga o que cada nível pode fazer em cada área.

Regras de segurança:
- O perfil Administrador (TI) não é alterável (evita ficar sem ninguém com acesso total).
- O Administrador (TI) altera qualquer outro nível.
- O chefe de uma pasta altera só os níveis auxiliar e consulta da própria pasta, e só pode liberar
  permissões que ele mesmo tem (ninguém dá mais acesso do que possui).
- Mudanças valem na hora (as permissões são conferidas a cada ação) e ficam no log de auditoria.
"""
import json

from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao, usuario_atual
from app.database import get_db
from app.models import Perfil, Permissao

# Áreas e ações que o sistema confere (cada uma vira uma chave liga/desliga na tela)
CATALOGO = [
    ('tesouraria', 'Financeiro (Tesouraria)', ['consultar', 'criar', 'editar', 'deletar', 'aprovar', 'contribuintes', 'banco']),
    ('secretaria', 'Secretaria', ['consultar', 'criar', 'editar', 'deletar']),
    ('membros', 'Rol de membros', ['consultar', 'criar', 'editar', 'deletar', 'aprovar']),
    ('patrimonio', 'Patrimônio', ['consultar', 'criar', 'editar', 'deletar', 'aprovar']),
    ('compras', 'Pedidos de compra', ['consultar', 'criar', 'editar', 'aprovar']),
    ('congregacoes', 'Congregações', ['consultar', 'criar', 'editar', 'deletar']),
    ('relatorios', 'Relatórios', ['consultar']),
    ('admin', 'Administração', ['consultar', 'auditoria']),
]
ROTULO_ACAO = {'consultar': 'Consultar', 'criar': 'Lançar / cadastrar', 'editar': 'Alterar', 'deletar': 'Excluir',
               'aprovar': 'Aprovar', 'contribuintes': 'Ver dizimistas', 'banco': 'Banco do Brasil', 'auditoria': 'Log de ações'}
TODAS = {f'{m}.{a}' for m, _r, acoes in CATALOGO for a in acoes}


def efetivas(perfil):
    """Permissões explícitas (sem curingas) que um perfil tem dentro do catálogo."""
    return sorted(p for p in TODAS if _tem(perfil['permissoes'], p)) if perfil else []


def _tem(lista, acao):
    mod = acao.split('.')[0]
    return '*' in lista or acao in lista or f'{mod}.*' in lista


def _pode_editar(eu, alvo_id):
    """(pode, motivo, limite) — limite = conjunto de permissões que o editor pode liberar (None = todas)."""
    if alvo_id == 1:
        return False, 'O perfil Administrador (TI) não pode ser alterado', None
    alvo = Perfil.PERFIS.get(alvo_id)
    if not alvo:
        return False, 'Perfil não encontrado', None
    if Permissao.tem_acesso(eu, 'admin.criar'):
        return True, '', None
    meu = Perfil.obter(eu['perfil_id']) or {}
    if meu.get('admin_pasta') and alvo.get('pasta') == meu.get('pasta') and not alvo.get('admin_pasta'):
        return True, '', set(efetivas(meu))
    return False, 'Você só altera os níveis auxiliar e consulta da sua pasta', None


def registrar_perfis(app):
    @app.route('/api/admin/perfis/matriz', methods=['GET'])
    @requer_permissao('admin.consultar')
    def perfis_matriz():
        eu = usuario_atual()
        perfis = []
        for pid, base in Perfil.PERFIS.items():
            atual = Perfil.obter(pid)
            pode, motivo, limite = _pode_editar(eu, pid)
            perfis.append({'id': pid, 'nome': base['nome'], 'pasta': base.get('pasta'), 'admin_pasta': bool(base.get('admin_pasta')),
                           'personalizado': bool(atual.get('personalizado')), 'permissoes': efetivas(atual),
                           'padrao': efetivas(base), 'editavel': pode, 'motivo': motivo,
                           'liberaveis': sorted(limite) if limite is not None else sorted(TODAS)})
        return jsonify({'catalogo': [{'modulo': m, 'nome': r, 'acoes': [{'acao': a, 'rotulo': ROTULO_ACAO[a]} for a in acoes]}
                                     for m, r, acoes in CATALOGO], 'perfis': perfis}), 200

    @app.route('/api/admin/perfis/<int:pid>/permissoes', methods=['PUT'])
    @requer_permissao('admin.consultar')
    def perfis_salvar(pid):
        eu = usuario_atual()
        pode, motivo, limite = _pode_editar(eu, pid)
        if not pode:
            return jsonify({'erro': motivo}), 403
        pedidas = set((request.get_json(silent=True) or {}).get('permissoes') or [])
        if not pedidas <= TODAS:
            return jsonify({'erro': 'Permissão desconhecida'}), 400
        base = Perfil.PERFIS[pid]
        atuais = set(efetivas(Perfil.obter(pid)))
        if limite is not None and (pedidas - atuais) - limite:
            return jsonify({'erro': 'Você não pode liberar acessos que você mesmo não tem'}), 403
        # o que não está no catálogo (ex.: admin.pasta do chefe) continua como no padrão
        extras = [p for p in base['permissoes'] if p.split('.')[0] not in {m for m, _r, _a in CATALOGO} or p == 'admin.pasta']
        final = sorted(pedidas) + extras
        conn = get_db()
        try:
            conn.execute('''INSERT INTO perfis_custom (perfil_id, permissoes, atualizado_por) VALUES (?, ?, ?)
                            ON CONFLICT (perfil_id) DO UPDATE SET permissoes = excluded.permissoes,
                            atualizado_por = excluded.atualizado_por, atualizado_em = CURRENT_TIMESTAMP''',
                         (pid, json.dumps(final), eu['nome']))
            liberou, tirou = sorted(pedidas - atuais), sorted(atuais - pedidas)
            registrar('admin', f'Alterou os acessos do perfil "{base["nome"]}"',
                      f'liberou: {", ".join(liberou) or "-"} | retirou: {", ".join(tirou) or "-"}', conn)
            conn.commit()
        finally:
            conn.close()
        Perfil.recarregar()
        return jsonify({'msg': 'Acessos atualizados (valem a partir de agora)'}), 200

    @app.route('/api/admin/perfis/<int:pid>/permissoes', methods=['DELETE'])
    @requer_permissao('admin.consultar')
    def perfis_restaurar(pid):
        pode, motivo, _ = _pode_editar(usuario_atual(), pid)
        if not pode:
            return jsonify({'erro': motivo}), 403
        conn = get_db()
        try:
            conn.execute('DELETE FROM perfis_custom WHERE perfil_id = ?', (pid,))
            registrar('admin', f'Restaurou os acessos padrão do perfil "{Perfil.PERFIS[pid]["nome"]}"', '', conn)
            conn.commit()
        finally:
            conn.close()
        Perfil.recarregar()
        return jsonify({'msg': 'Acessos padrão restaurados'}), 200
