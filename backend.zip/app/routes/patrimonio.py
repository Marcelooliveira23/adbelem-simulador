from app.crud import registrar_crud
from app.validacao import texto, opcao, numero, data_iso, inteiro

CATEGORIAS = ('imovel', 'movel', 'eletronico', 'instrumento', 'veiculo', 'outro')
STATUS = ('bom', 'manutencao', 'emprestado', 'descartado')

CAMPOS = {
    'nome': lambda d: texto(d, 'nome', obrigatorio=True, max_len=150),
    'tombo': lambda d: texto(d, 'tombo', max_len=30),
    'categoria': lambda d: opcao(d, 'categoria', CATEGORIAS),
    'local': lambda d: texto(d, 'local', obrigatorio=True, max_len=150),
    'valor': lambda d: numero(d, 'valor', minimo=0),
    'status': lambda d: opcao(d, 'status', STATUS, padrao='bom'),
    'responsavel': lambda d: texto(d, 'responsavel', max_len=150),
    'data_aquisicao': lambda d: data_iso(d, 'data_aquisicao'),
    'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
    'observacoes': lambda d: texto(d, 'observacoes', max_len=2000),
    # ficha técnica, garantia, seguro e vida útil (depreciação)
    'marca': lambda d: texto(d, 'marca', max_len=60),
    'modelo': lambda d: texto(d, 'modelo', max_len=80),
    'numero_serie': lambda d: texto(d, 'numero_serie', max_len=60),
    'nota_fiscal': lambda d: texto(d, 'nota_fiscal', max_len=40),
    'fornecedor_id': lambda d: inteiro(d, 'fornecedor_id'),
    'garantia_ate': lambda d: data_iso(d, 'garantia_ate'),
    'seguradora': lambda d: texto(d, 'seguradora', max_len=80),
    'apolice': lambda d: texto(d, 'apolice', max_len=40),
    'seguro_ate': lambda d: data_iso(d, 'seguro_ate'),
    'vida_util_anos': lambda d: inteiro(d, 'vida_util_anos', minimo=0),
    'espaco_id': lambda d: inteiro(d, 'espaco_id'),
}


def registrar_patrimonio(app):
    registrar_crud(app, rota='patrimonio', tabela='patrimonio', modulo='patrimonio', campos=CAMPOS,
                   chave_lista='patrimonios', ordem='t.nome COLLATE NOCASE', escopo=True, aprovacao=True,
                   filtros=('congregacao_id', 'status', 'categoria', 'aprovacao'), rotulo='bem')
