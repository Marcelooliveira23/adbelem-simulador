from app.crud import registrar_crud
from app.validacao import texto, opcao, data_iso, inteiro, cpf

STATUS_MEMBRO = ('ativo', 'inativo', 'visitante')
FUNCOES = ('Membro', 'Cooperador(a)', 'Obreiro', 'Diácono', 'Diaconisa', 'Presbítero', 'Evangelista',
           'Missionário(a)', 'Pastor')

CAMPOS = {
    'nome': lambda d: texto(d, 'nome', obrigatorio=True, max_len=150),
    'email': lambda d: texto(d, 'email', max_len=150),
    'telefone': lambda d: texto(d, 'telefone', max_len=30),
    'data_nascimento': lambda d: data_iso(d, 'data_nascimento'),
    'data_batismo': lambda d: data_iso(d, 'data_batismo'),
    'endereco': lambda d: texto(d, 'endereco', max_len=250),
    'status': lambda d: opcao(d, 'status', STATUS_MEMBRO, padrao='ativo'),
    'funcao': lambda d: opcao(d, 'funcao', FUNCOES, padrao='Membro'),
    'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
    'observacoes': lambda d: texto(d, 'observacoes', max_len=2000),
    # Dados pessoais
    'sexo': lambda d: opcao(d, 'sexo', ('', 'M', 'F'), ''),
    'estado_civil': lambda d: opcao(d, 'estado_civil', ('', 'solteiro', 'casado', 'divorciado', 'viuvo', 'uniao_estavel'), ''),
    'conjuge': lambda d: texto(d, 'conjuge', max_len=150),
    'data_casamento': lambda d: data_iso(d, 'data_casamento'),
    'nome_pai': lambda d: texto(d, 'nome_pai', max_len=150),
    'nome_mae': lambda d: texto(d, 'nome_mae', max_len=150),
    'naturalidade': lambda d: texto(d, 'naturalidade', max_len=100),
    'nacionalidade': lambda d: texto(d, 'nacionalidade', max_len=60),
    'cpf': lambda d: cpf(d),
    'rg': lambda d: texto(d, 'rg', max_len=30),
    'profissao': lambda d: texto(d, 'profissao', max_len=100),
    'escolaridade': lambda d: texto(d, 'escolaridade', max_len=60),
    'celular': lambda d: texto(d, 'celular', max_len=30),
    'cep': lambda d: texto(d, 'cep', max_len=10),
    'bairro': lambda d: texto(d, 'bairro', max_len=100),
    'cidade': lambda d: texto(d, 'cidade', max_len=100),
    'estado': lambda d: texto(d, 'estado', max_len=2).upper(),
    # Dados eclesiásticos
    'data_conversao': lambda d: data_iso(d, 'data_conversao'),
    'batismo_espirito': lambda d: opcao(d, 'batismo_espirito', ('', 'sim', 'nao'), ''),
    'igreja_origem': lambda d: texto(d, 'igreja_origem', max_len=150),
    'forma_admissao': lambda d: opcao(d, 'forma_admissao', ('', 'batismo', 'transferencia', 'aclamacao', 'reconciliacao'), ''),
    'data_admissao': lambda d: data_iso(d, 'data_admissao'),
    'data_consagracao': lambda d: data_iso(d, 'data_consagracao'),
    'ministerios': lambda d: texto(d, 'ministerios', max_len=300),
    'motivo_saida': lambda d: opcao(d, 'motivo_saida', ('', 'transferido', 'mudanca', 'falecimento', 'desligamento', 'a_pedido'), ''),
    'data_saida': lambda d: data_iso(d, 'data_saida'),
    'consentimento_lgpd': lambda d: 1 if str(d.get('consentimento_lgpd', '0')) in ('1', 'true', 'True') else 0,
}


def registrar_membros(app):
    registrar_crud(app, rota='membros', tabela='membros', modulo='membros', campos=CAMPOS,
                   ordem='t.nome COLLATE NOCASE', escopo=True, aprovacao=True,
                   filtros=('congregacao_id', 'status', 'funcao', 'aprovacao', 'sexo', 'estado_civil'), rotulo='membro')
