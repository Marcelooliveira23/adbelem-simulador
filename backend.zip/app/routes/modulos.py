"""Rotas de Secretaria (congregações, contratos, documentos) e Administração (usuários, log, pendências)."""
import secrets
from datetime import date, timedelta

from flask import request, jsonify
from flask_jwt_extended import jwt_required

from app.auditoria import registrar
from app.auth_utils import requer_permissao, usuario_atual, escopo_congregacao, criar_token
from app.crud import registrar_crud
from app.routes.gestao import contagens_pendencias
from app.routes.gestao2 import contagens_v12
from app.seguranca import validar_senha
from app.database import get_db, rows_to_dicts
from app.models import Perfil, Usuario, Permissao
from app.validacao import ErroValidacao, texto, opcao, numero, data_iso, inteiro


def _erro(e, codigo=400):
    return jsonify({'erro': str(e)}), codigo


def _hora(d, campo='hora'):
    v = texto(d, campo, max_len=5)
    if v and (len(v) != 5 or v[2] != ':'):
        raise ErroValidacao(f"O campo '{campo}' deve estar no formato HH:MM")
    return v


def registrar_modulos(app):
    # =====================================================================
    # Unidades (lista leve para os campos "Congregação" das telas)
    # =====================================================================
    @app.route('/api/unidades', methods=['GET'])
    @jwt_required()
    def listar_unidades():
        conn = get_db()
        try:
            rows = conn.execute('SELECT id, nome FROM congregacoes WHERE ativo = 1 ORDER BY nome COLLATE NOCASE').fetchall()
            return jsonify({'unidades': rows_to_dicts(rows), 'escopo': escopo_congregacao()}), 200
        finally:
            conn.close()

    # =====================================================================
    # 4 · Congregações
    # =====================================================================
    registrar_crud(app, rota='congregacoes', tabela='congregacoes', modulo='congregacoes', rotulo='congregação',
                   ordem='t.nome COLLATE NOCASE', campos={
                       'nome': lambda d: texto(d, 'nome', True, 150),
                       'dirigente': lambda d: texto(d, 'dirigente', max_len=150),
                       'periodicidade_acerto': lambda d: opcao(d, 'periodicidade_acerto', ('semanal', 'mensal'), 'mensal'),
                       'endereco': lambda d: texto(d, 'endereco', max_len=250),
                       'bairro': lambda d: texto(d, 'bairro', max_len=100),
                       'cidade': lambda d: texto(d, 'cidade', max_len=100),
                       'estado': lambda d: texto(d, 'estado', max_len=2).upper(),
                       'cep': lambda d: texto(d, 'cep', max_len=10),
                       'telefone': lambda d: texto(d, 'telefone', max_len=30),
                       'data_fundacao': lambda d: data_iso(d, 'data_fundacao'),
                       'latitude': lambda d: numero(d, 'latitude') or None,
                       'longitude': lambda d: numero(d, 'longitude') or None,
                       'ativo': lambda d: 0 if str(d.get('ativo', '1')) in ('0', 'false', 'False') else 1,
                       'observacoes': lambda d: texto(d, 'observacoes', max_len=2000),
                   })

    @app.route('/api/congregacoes/<int:id>/painel', methods=['GET'])
    @requer_permissao('congregacoes.consultar')
    def painel_congregacao(id):
        cong = escopo_congregacao()
        if cong is not None and cong != id:
            return _erro('Você só pode ver a sua congregação', 403)
        conn = get_db()
        try:
            c = conn.execute('SELECT * FROM congregacoes WHERE id = ?', (id,)).fetchone()
            if not c:
                return _erro('Congregação não encontrada', 404)
            v = lambda sql: conn.execute(sql, (id,)).fetchone()[0] or 0  # noqa: E731
            ok = "COALESCE(aprovacao, 'aprovado') = 'aprovado'"
            return jsonify({
                'congregacao': dict(c),
                'membros': v(f'SELECT COUNT(*) FROM membros WHERE congregacao_id = ? AND {ok}'),
                'obreiros': v(f"SELECT COUNT(*) FROM membros WHERE congregacao_id = ? AND {ok} AND COALESCE(funcao,'Membro') NOT IN ('Membro')"),
                'receitas': round(v(f"SELECT SUM(valor) FROM financeiro WHERE congregacao_id = ? AND {ok} AND tipo='receita'"), 2),
                'despesas': round(v(f"SELECT SUM(valor) FROM financeiro WHERE congregacao_id = ? AND {ok} AND tipo='despesa'"), 2),
                'bens': v(f'SELECT COUNT(*) FROM patrimonio WHERE congregacao_id = ? AND {ok}'),
                'valor_bens': round(v(f"SELECT SUM(valor) FROM patrimonio WHERE congregacao_id = ? AND {ok} AND status != 'descartado'"), 2),
                'pendentes': v("SELECT (SELECT COUNT(*) FROM membros WHERE congregacao_id = ?1 AND aprovacao = 'pendente') + "
                               "(SELECT COUNT(*) FROM financeiro WHERE congregacao_id = ?1 AND aprovacao = 'pendente') + "
                               "(SELECT COUNT(*) FROM patrimonio WHERE congregacao_id = ?1 AND aprovacao = 'pendente')"),
            }), 200
        finally:
            conn.close()

    @app.route('/api/congregacoes/<int:id>/fechamento', methods=['POST'])
    @requer_permissao('congregacoes.consultar')
    def fechamento_congregacao(id):
        """Dirigente envia o fechamento do mês; a Tesouraria aprova ou devolve."""
        user = usuario_atual()
        acao = (request.get_json(silent=True) or {}).get('acao')
        cong = escopo_congregacao(user)
        if acao == 'enviar':
            if cong is not None and cong != id:
                return _erro('Você só pode enviar o fechamento da sua congregação', 403)
            novo = 'enviado'
        elif acao in ('aprovar', 'devolver'):
            if not Permissao.tem_acesso(user, 'tesouraria.aprovar'):
                return _erro('Somente a Tesouraria da sede aprova o fechamento', 403)
            novo = 'aprovado' if acao == 'aprovar' else 'devolvido'
        elif acao == 'reabrir':
            if not Permissao.tem_acesso(user, 'tesouraria.aprovar'):
                return _erro('Somente a Tesouraria da sede reabre o fechamento', 403)
            novo = 'aberto'
        else:
            return _erro("Ação inválida. Use: enviar, aprovar, devolver ou reabrir")
        conn = get_db()
        try:
            cur = conn.execute('UPDATE congregacoes SET fechamento = ? WHERE id = ?', (novo, id))
            if cur.rowcount == 0:
                return _erro('Congregação não encontrada', 404)
            registrar('congregacoes', f'Fechamento da congregação #{id}: {novo}', '', conn)
            conn.commit()
            return jsonify({'msg': f'Fechamento {novo}', 'fechamento': novo}), 200
        finally:
            conn.close()

    # =====================================================================
    # 5 · Secretaria: contratos e documentos
    # =====================================================================
    registrar_crud(app, rota='contratos', tabela='contratos', modulo='secretaria', rotulo='contrato',
                   ordem='t.vencimento IS NULL, t.vencimento', escopo=True, campos={
                       'descricao': lambda d: texto(d, 'descricao', True, 200),
                       'tipo': lambda d: opcao(d, 'tipo', ('contrato', 'aluguel', 'seguro', 'servico', 'outro'), 'contrato'),
                       'parte': lambda d: texto(d, 'parte', max_len=150),
                       'valor': lambda d: numero(d, 'valor', minimo=0),
                       'inicio': lambda d: data_iso(d, 'inicio'),
                       'vencimento': lambda d: data_iso(d, 'vencimento'),
                       'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
                       'observacoes': lambda d: texto(d, 'observacoes', max_len=2000),
                   })

    TIPOS_DOC = ('Carta de recomendação', 'Carta de mudança', 'Carta de transferência', 'Carta de visita',
                 'Declaração de membro', 'Carta de doação')

    @app.route('/api/documentos', methods=['GET'])
    @requer_permissao('secretaria.consultar')
    def listar_documentos():
        conn = get_db()
        try:
            rows = conn.execute('SELECT * FROM documentos ORDER BY id DESC LIMIT 500').fetchall()
            return jsonify({'documentos': rows_to_dicts(rows), 'tipos': TIPOS_DOC}), 200
        finally:
            conn.close()

    @app.route('/api/documentos', methods=['POST'])
    @requer_permissao('secretaria.criar')
    def emitir_documento():
        d = request.get_json(silent=True) or {}
        try:
            tipo = opcao(d, 'tipo', TIPOS_DOC)
            membro_id = inteiro(d, 'membro_id', obrigatorio=True)
            destino = texto(d, 'destino', max_len=200)
            obs = texto(d, 'observacoes', max_len=1000)
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            m = conn.execute('SELECT nome FROM membros WHERE id = ?', (membro_id,)).fetchone()
            if not m:
                return _erro('Membro não encontrado', 404)
            ano = date.today().year
            numero_doc = conn.execute('SELECT COALESCE(MAX(numero), 0) + 1 FROM documentos WHERE ano = ?', (ano,)).fetchone()[0]
            codigo = secrets.token_hex(4).upper()
            cur = conn.execute('''INSERT INTO documentos (numero, ano, tipo, membro_id, membro_nome, destino, observacoes,
                                  codigo, emitido_por) VALUES (?,?,?,?,?,?,?,?,?)''',
                               (numero_doc, ano, tipo, membro_id, m['nome'], destino, obs, codigo, usuario_atual()['nome']))
            registrar('secretaria', f'Emitiu {tipo} nº {numero_doc:04d}/{ano}', m['nome'], conn)
            conn.commit()
            return jsonify({'msg': 'Documento emitido', 'id': cur.lastrowid}), 201
        finally:
            conn.close()

    @app.route('/api/documentos/<int:id>', methods=['GET'])
    @requer_permissao('secretaria.consultar')
    def obter_documento(id):
        conn = get_db()
        try:
            doc = conn.execute('SELECT * FROM documentos WHERE id = ?', (id,)).fetchone()
            if not doc:
                return _erro('Documento não encontrado', 404)
            membro = conn.execute('''SELECT m.*, (SELECT nome FROM congregacoes c WHERE c.id = m.congregacao_id) AS congregacao_nome
                                     FROM membros m WHERE m.id = ?''', (doc['membro_id'],)).fetchone()
            return jsonify({'documento': dict(doc), 'membro': dict(membro) if membro else None}), 200
        finally:
            conn.close()

    @app.route('/api/verificar/<codigo>', methods=['GET'])
    def verificar_documento(codigo):
        """Público: confere se um documento impresso é autêntico."""
        conn = get_db()
        try:
            doc = conn.execute('SELECT numero, ano, tipo, membro_nome, criado_em FROM documentos WHERE codigo = ?',
                               (codigo.strip().upper(),)).fetchone()
            if not doc:
                return jsonify({'valido': False}), 404
            return jsonify({'valido': True, **dict(doc)}), 200
        finally:
            conn.close()

    # =====================================================================
    # 14 · Administração: usuários e log
    # =====================================================================
    def _ler_usuario(d, novo):
        u = {
            'nome': texto(d, 'nome', True, 150),
            'email': texto(d, 'email', True, 150).lower(),
            'perfil_id': inteiro(d, 'perfil_id', obrigatorio=True),
            'congregacao_id': inteiro(d, 'congregacao_id'),
            'ativo': 0 if str(d.get('ativo', '1')) in ('0', 'false', 'False') else 1,
        }
        if '@' not in u['email']:
            raise ErroValidacao('E-mail inválido')
        perfil = Perfil.obter(u['perfil_id'])
        if not perfil:
            raise ErroValidacao('Perfil inválido')
        if perfil.get('escopo') == 'congregacao' and not u['congregacao_id']:
            raise ErroValidacao('Este perfil precisa de uma congregação')
        senha = d.get('senha') or ''
        if novo or senha:
            validar_senha(senha, u['email'], u['nome'])
            u['senha_hash'] = Usuario.criar_hash_senha(senha)
            # senha definida por outra pessoa é provisória: o usuário troca no primeiro acesso
            u['trocar_senha'] = 0 if str(d.get('exigir_troca', '1')) in ('0', 'false', 'False') else 1
            u['senha_alterada_em'] = date.today().isoformat()
        return u

    @app.route('/api/admin/perfis', methods=['GET'])
    @jwt_required()
    def listar_perfis_admin():
        pasta = Perfil.pasta_que_administra(usuario_atual())
        return jsonify({'pasta_administrada': pasta, 'perfis': [
            {'id': k, 'nome': v['nome'], 'descricao': v['descricao'], 'pasta': v.get('pasta'), 'permissoes': v['permissoes'],
             'admin_pasta': bool(v.get('admin_pasta')), 'gerenciavel': pasta == '*' or (pasta is not None and v.get('pasta') == pasta)}
            for k, v in Perfil.listar().items()]}), 200

    def _pode_gerenciar(perfil_id):
        """True se o usuário logado pode atribuir/alterar este perfil (TI: todos; chefe: só os da pasta)."""
        pasta = Perfil.pasta_que_administra(usuario_atual())
        alvo = Perfil.obter(perfil_id) or {}
        return pasta == '*' or (pasta is not None and alvo.get('pasta') == pasta)

    @app.route('/api/admin/usuarios', methods=['GET'])
    @requer_permissao('admin.consultar')
    def listar_usuarios_admin():
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('''SELECT u.id, u.nome, u.email, u.perfil_id, u.congregacao_id, u.ativo, u.criado_em, u.totp_ativo, u.bloqueado_ate,
                                                 u.ultimo_login, u.trocar_senha,
                                                 (SELECT nome FROM congregacoes c WHERE c.id = u.congregacao_id) AS congregacao_nome,
                                                 (SELECT MAX(data) FROM auditoria a WHERE a.usuario_id = u.id) AS ultima_acao
                                                 FROM usuarios u ORDER BY u.ativo DESC, u.nome''').fetchall())
            pasta = Perfil.pasta_que_administra(usuario_atual())
            if pasta not in ('*', None):    # chefe de pasta: só vê os usuários da própria pasta
                rows = [r for r in rows if (Perfil.obter(r['perfil_id']) or {}).get('pasta') == pasta]
            for r in rows:
                p = Perfil.obter(r['perfil_id']) or {}
                r['perfil'], r['pasta'] = p.get('nome', '?'), p.get('pasta')
                r['gerenciavel'] = _pode_gerenciar(r['perfil_id'])
            return jsonify({'usuarios': rows}), 200
        finally:
            conn.close()

    @app.route('/api/admin/usuarios', methods=['POST'])
    @requer_permissao('admin.consultar')
    def criar_usuario_admin():
        if Perfil.pasta_que_administra(usuario_atual()) is None:
            return _erro('Somente o Administrador de TI ou o chefe da pasta dá acessos', 403)
        try:
            u = _ler_usuario(request.get_json(silent=True) or {}, novo=True)
        except ErroValidacao as e:
            return _erro(e)
        if not _pode_gerenciar(u['perfil_id']):
            return _erro('Você só pode dar acessos da sua própria pasta', 403)
        conn = get_db()
        try:
            if conn.execute('SELECT 1 FROM usuarios WHERE lower(email) = ?', (u['email'],)).fetchone():
                return _erro('Já existe um usuário com este e-mail', 409)
            cols = list(u)
            cur = conn.execute(f'INSERT INTO usuarios ({", ".join(cols)}) VALUES ({", ".join("?" for _ in cols)})',
                               [u[c] for c in cols])
            registrar('admin', f'Criou usuário #{cur.lastrowid}', f"{u['email']} ({Perfil.obter(u['perfil_id'])['nome']})", conn)
            conn.commit()
            return jsonify({'msg': 'Usuário criado', 'id': cur.lastrowid}), 201
        finally:
            conn.close()

    @app.route('/api/admin/usuarios/<int:id>', methods=['PUT'])
    @requer_permissao('admin.consultar')
    def editar_usuario_admin(id):
        if Perfil.pasta_que_administra(usuario_atual()) is None:
            return _erro('Somente o Administrador de TI ou o chefe da pasta altera acessos', 403)
        try:
            u = _ler_usuario(request.get_json(silent=True) or {}, novo=False)
        except ErroValidacao as e:
            return _erro(e)
        conn_v = get_db()
        try:
            atual = conn_v.execute('SELECT perfil_id FROM usuarios WHERE id = ?', (id,)).fetchone()
        finally:
            conn_v.close()
        if not atual:
            return _erro('Usuário não encontrado', 404)
        if not (_pode_gerenciar(atual['perfil_id']) and _pode_gerenciar(u['perfil_id'])):
            return _erro('Você só pode alterar acessos da sua própria pasta', 403)
        if id == usuario_atual()['id'] and (not u['ativo'] or u['perfil_id'] != usuario_atual()['perfil_id']):
            return _erro('Você não pode desativar nem trocar o perfil do próprio usuário')
        conn = get_db()
        try:
            if conn.execute('SELECT 1 FROM usuarios WHERE lower(email) = ? AND id != ?', (u['email'], id)).fetchone():
                return _erro('Já existe um usuário com este e-mail', 409)
            cols = list(u)
            # senha, perfil ou situação mudou: encerra as sessões abertas desse usuário
            revoga = ', token_versao = COALESCE(token_versao, 0) + 1' if (
                'senha_hash' in u or not u['ativo'] or atual['perfil_id'] != u['perfil_id']) else ''
            cur = conn.execute(f'UPDATE usuarios SET {", ".join(f"{c} = ?" for c in cols)}, '
                               f'atualizado_em = CURRENT_TIMESTAMP{revoga} WHERE id = ?', [u[c] for c in cols] + [id])
            if cur.rowcount == 0:
                return _erro('Usuário não encontrado', 404)
            registrar('admin', f'Editou usuário #{id}', u['email'] + (' (senha redefinida)' if 'senha_hash' in u else ''), conn)
            conn.commit()
            return jsonify({'msg': 'Usuário atualizado'}), 200
        finally:
            conn.close()

    @app.route('/api/admin/auditoria', methods=['GET'])
    @requer_permissao('admin.auditoria')
    def listar_auditoria():
        limite = min(int(request.args.get('limite') or 300), 2000)
        conn = get_db()
        try:
            rows = conn.execute('SELECT * FROM auditoria ORDER BY id DESC LIMIT ?', (limite,)).fetchall()
            return jsonify({'log': rows_to_dicts(rows)}), 200
        finally:
            conn.close()

    @app.route('/api/auth/senha', methods=['POST'])
    @jwt_required()
    def trocar_senha():
        d = request.get_json(silent=True) or {}
        atual, nova = d.get('atual') or '', d.get('nova') or ''
        eu = usuario_atual()
        try:
            validar_senha(nova, eu['email'], eu['nome'])
        except ErroValidacao as e:
            return _erro(e)
        if nova == atual:
            return _erro('A nova senha deve ser diferente da atual')
        uid = eu['id']
        conn = get_db()
        try:
            row = conn.execute('SELECT senha_hash FROM usuarios WHERE id = ?', (uid,)).fetchone()
            if not row or not Usuario.verificar_senha(atual, row['senha_hash']):
                return _erro('Senha atual incorreta', 403)
            conn.execute('UPDATE usuarios SET senha_hash = ?, trocar_senha = 0, senha_alterada_em = ?, '
                         'token_versao = COALESCE(token_versao, 0) + 1 WHERE id = ?',
                         (Usuario.criar_hash_senha(nova), date.today().isoformat(), uid))
            registrar('admin', 'Trocou a própria senha', '', conn)
            conn.commit()
            novo = conn.execute('SELECT * FROM usuarios WHERE id = ?', (uid,)).fetchone()
            # as outras sessões são encerradas; esta continua com um token novo
            return jsonify({'msg': 'Senha alterada. As outras sessões abertas foram encerradas.',
                            'access_token': criar_token(novo)}), 200
        finally:
            conn.close()

    # Pendências de "de acordo" para quem aprova (usadas no Painel)
    @app.route('/api/pendencias', methods=['GET'])
    @jwt_required()
    def pendencias():
        user = usuario_atual()
        conn = get_db()
        try:
            out = {}
            for mod, tabela in (('tesouraria', 'financeiro'), ('membros', 'membros'), ('patrimonio', 'patrimonio')):
                if Permissao.tem_acesso(user, f'{mod}.aprovar'):
                    out[mod] = conn.execute(f"SELECT COUNT(*) FROM {tabela} WHERE aprovacao = 'pendente'").fetchone()[0]
            if Permissao.tem_acesso(user, 'tesouraria.aprovar'):
                out['fechamentos'] = conn.execute("SELECT COUNT(*) FROM congregacoes WHERE fechamento = 'enviado'").fetchone()[0]
            if Permissao.tem_acesso(user, 'secretaria.consultar'):
                limite = (date.today() + timedelta(days=30)).isoformat()
                out['contratos_vencendo'] = conn.execute(
                    'SELECT COUNT(*) FROM contratos WHERE vencimento IS NOT NULL AND vencimento <= ?', (limite,)).fetchone()[0]
            if Permissao.tem_acesso(user, 'tesouraria.consultar'):
                from app.routes.acertos import ultimo_periodo_fechado
                pend = 0
                for c in conn.execute('''SELECT COALESCE(periodicidade_acerto, 'mensal') AS p,
                                                (SELECT MAX(periodo_fim) FROM acertos a WHERE a.congregacao_id = c.id) AS ult
                                         FROM congregacoes c WHERE ativo = 1'''):
                    if not c['ult'] or c['ult'] < ultimo_periodo_fechado(c['p']).isoformat():
                        pend += 1
                out['acertos_pendentes'] = pend
                out['acertos_a_receber'] = conn.execute("SELECT COUNT(*) FROM acertos WHERE status = 'enviado'").fetchone()[0]
                out['pix_a_classificar'] = conn.execute('SELECT COUNT(*) FROM banco_movimentos WHERE classificado = 0').fetchone()[0]
            if Permissao.tem_acesso(user, 'compras.aprovar'):
                out['compras_a_aprovar'] = conn.execute("SELECT COUNT(*) FROM pedidos_compra WHERE status = 'aguardando_aprovacao'").fetchone()[0]
            if Permissao.tem_acesso(user, 'compras.criar'):
                out['compras_a_entregar'] = conn.execute("SELECT COUNT(*) FROM pedidos_compra WHERE status = 'aprovado'").fetchone()[0]
            if Permissao.tem_acesso(user, 'patrimonio.consultar'):
                out['estoque_baixo'] = conn.execute('''SELECT COUNT(*) FROM materiais m WHERE ativo = 1 AND estoque_minimo > 0 AND
                    COALESCE((SELECT SUM(CASE WHEN tipo = 'saida' THEN -quantidade ELSE quantidade END) FROM materiais_mov v
                              WHERE v.material_id = m.id), 0) < estoque_minimo''').fetchone()[0]
            cong = escopo_congregacao(user)
            if cong is not None:
                out['devolvidos'] = conn.execute(
                    "SELECT (SELECT COUNT(*) FROM financeiro WHERE congregacao_id=?1 AND aprovacao='devolvido') + "
                    "(SELECT COUNT(*) FROM membros WHERE congregacao_id=?1 AND aprovacao='devolvido') + "
                    "(SELECT COUNT(*) FROM patrimonio WHERE congregacao_id=?1 AND aprovacao='devolvido')", (cong,)).fetchone()[0]
            out.update(contagens_pendencias(conn, lambda p: Permissao.tem_acesso(user, p)))
            out.update(contagens_v12(conn, lambda p: Permissao.tem_acesso(user, p)))
            return jsonify(out), 200
        finally:
            conn.close()

