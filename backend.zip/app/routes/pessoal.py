"""Tesouraria · Pessoal: funcionários, temporários, autônomos e prestadores de serviço.

- Cadastro com cargo, tipo de vínculo, remuneração e dados de pagamento; pode apontar para o cadastro de membro
  (a Secretaria vê a indicação "Funcionário" ao lado do nome, sem ver valores).
- Pagamentos (salário, serviço extra, diária, adiantamento, 13º, férias) viram despesas ligadas à pessoa.
- Folha do mês: gera as despesas a pagar de quem recebe mensalmente, sem duplicar.
"""
import calendar
import re
from datetime import date

from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao, requer_login, usuario_atual
from app.crud import registrar_crud
from app.database import get_db, rows_to_dicts
from app.models import Permissao
from app.periodos import periodo_fechado, msg_fechado
from app.validacao import ErroValidacao, texto, opcao, numero, data_iso, inteiro, cpf, brl

TIPOS = ('clt', 'temporario', 'autonomo', 'prestador', 'estagiario', 'pastoral', 'obreiro')
# pastoral: pastor (prebenda / sustento pastoral, sem vínculo CLT); obreiro: obreiro ou dirigente de congregação (ajuda de custo)
PERIODICIDADES = ('mensal', 'quinzenal', 'semanal', 'diaria', 'por_servico')
TIPOS_PAGAMENTO = {      # tipo -> (rótulo, conta do plano para vínculo empregatício, conta para autônomos)
    'salario': ('Salário', 'salario', 'servicos_terceiros'),
    'servico_extra': ('Serviço extra', 'servicos_terceiros', 'servicos_terceiros'),
    'diaria': ('Diária', 'servicos_terceiros', 'servicos_terceiros'),
    'adiantamento': ('Adiantamento', 'salario', 'servicos_terceiros'),
    'decimo_terceiro': ('13º salário', 'salario', 'salario'),
    'ferias': ('Férias', 'salario', 'salario'),
    'encargos': ('Encargos (INSS/FGTS)', 'encargos', 'encargos'),
    'prebenda': ('Prebenda / sustento pastoral', 'prebenda', 'prebenda'),
    'ajuda_custo': ('Ajuda de custo', 'ajuda_custo', 'ajuda_custo'),
    'auxilio': ('Auxílio (moradia/transporte/alimentação)', 'auxilios', 'auxilios'),
}
# pagamento do período de cada vínculo na folha do mês
PAGAMENTO_DA_FOLHA = {'pastoral': 'prebenda', 'obreiro': 'ajuda_custo'}
COM_VINCULO = ('clt', 'temporario', 'estagiario')


def _ativo(d):
    return 0 if str(d.get('ativo', '1')) in ('0', 'false', 'False') else 1


def _cpf_opcional(d):
    try:
        return cpf(d) or None
    except ErroValidacao:
        raise ErroValidacao('CPF do funcionário inválido')


CAMPOS = {
    'nome': lambda d: texto(d, 'nome', obrigatorio=True, max_len=150),
    'cargo': lambda d: texto(d, 'cargo', max_len=80),
    'tipo': lambda d: opcao(d, 'tipo', TIPOS, padrao='clt'),
    'membro_id': lambda d: inteiro(d, 'membro_id'),
    'cpf': _cpf_opcional,
    'telefone': lambda d: texto(d, 'telefone', max_len=30),
    'email': lambda d: texto(d, 'email', max_len=120),
    'data_admissao': lambda d: data_iso(d, 'data_admissao'),
    'data_desligamento': lambda d: data_iso(d, 'data_desligamento'),
    'remuneracao': lambda d: numero(d, 'remuneracao', minimo=0) or 0,
    'periodicidade': lambda d: opcao(d, 'periodicidade', PERIODICIDADES, padrao='mensal'),
    'dia_pagamento': lambda d: inteiro(d, 'dia_pagamento', minimo=1),
    'forma_pagamento': lambda d: texto(d, 'forma_pagamento', max_len=30),
    'pix': lambda d: texto(d, 'pix', max_len=120),
    'banco': lambda d: texto(d, 'banco', max_len=120),
    'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
    'ativo': _ativo,
    'observacoes': lambda d: texto(d, 'observacoes', max_len=1000),
}


def _inserir_pagamento(conn, f, tipo, valor, data_pg, descricao, status, vencimento=None, conta_id=None,
                       forma=None, competencia=None, documento=None):
    rot, conta_vinc, conta_aut = TIPOS_PAGAMENTO[tipo]
    categoria = conta_vinc if f['tipo'] in COM_VINCULO else conta_aut
    cur = conn.execute('''INSERT INTO financeiro (tipo, descricao, valor, data, vencimento, categoria, status, forma, congregacao_id,
                            funcionario_id, conta_id, competencia, documento, usuario_id, aprovacao)
                          VALUES ('despesa', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'aprovado')''',
                       (descricao or f"{rot} – {f['nome']}", valor, data_pg, vencimento or data_pg, categoria, status,
                        forma or f['forma_pagamento'] or 'pix', f['congregacao_id'], f['id'], conta_id, competencia, documento,
                        usuario_atual()['id']))
    return cur.lastrowid


def registrar_pessoal(app):
    registrar_crud(app, rota='funcionarios', tabela='funcionarios', modulo='tesouraria', rotulo='funcionário',
                   chave_lista='funcionarios', escopo=True, ordem='t.ativo DESC, t.nome COLLATE NOCASE',
                   filtros=('tipo', 'ativo', 'congregacao_id'), campos=CAMPOS)

    @app.route('/api/funcionarios/vinculos', methods=['GET'])
    @requer_login
    def funcionarios_vinculos():
        """Quem do rol de membros é funcionário (sem valores): usado pela Secretaria para marcar o cadastro."""
        eu = usuario_atual()
        if not (Permissao.tem_acesso(eu, 'membros.consultar') or Permissao.tem_acesso(eu, 'tesouraria.consultar')):
            return jsonify({'erro': 'Sem permissão'}), 403
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('''SELECT membro_id, cargo, tipo FROM funcionarios
                                                 WHERE ativo = 1 AND membro_id IS NOT NULL'''))
            return jsonify({'vinculos': rows}), 200
        finally:
            conn.close()

    @app.route('/api/funcionarios/<int:fid>/pagamentos', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def funcionario_pagamentos(fid):
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('''SELECT id, data, vencimento, descricao, valor, status, categoria, forma
                                                 FROM financeiro WHERE funcionario_id = ? ORDER BY data DESC, id DESC''', (fid,)))
            ano = str(date.today().year)
            return jsonify({'pagamentos': rows, 'total_ano': round(sum(r['valor'] for r in rows if r['data'][:4] == ano), 2)}), 200
        finally:
            conn.close()

    @app.route('/api/funcionarios/<int:fid>/pagamento', methods=['POST'])
    @requer_permissao('tesouraria.criar')
    def funcionario_pagar(fid):
        d = request.get_json(silent=True) or {}
        try:
            tipo = opcao(d, 'tipo', tuple(TIPOS_PAGAMENTO), padrao='salario')
            valor = numero(d, 'valor', obrigatorio=True, positivo=True)
            data_pg = data_iso(d, 'data') or date.today().isoformat()
            status = opcao(d, 'status', ('pago', 'pendente'), padrao='pago')
            desc = texto(d, 'descricao', max_len=200)
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        conn = get_db()
        try:
            f = conn.execute('SELECT * FROM funcionarios WHERE id = ?', (fid,)).fetchone()
            if not f:
                return jsonify({'erro': 'Funcionário não encontrado'}), 404
            if periodo_fechado(conn, data_pg):
                return jsonify({'erro': msg_fechado(data_pg)}), 409
            lid = _inserir_pagamento(conn, f, tipo, valor, data_pg, desc, status, data_iso(d, 'vencimento'),
                                     inteiro(d, 'conta_id'), texto(d, 'forma', max_len=20))
            registrar('tesouraria', f'Pagamento #{lid} a funcionário #{fid}', f"{TIPOS_PAGAMENTO[tipo][0]} {f['nome']} {brl(valor)}", conn)
            conn.commit()
            return jsonify({'msg': f"{TIPOS_PAGAMENTO[tipo][0]} lançado ({'pago' if status == 'pago' else 'a pagar'})", 'id': lid}), 201
        finally:
            conn.close()

    @app.route('/api/funcionarios/folha', methods=['POST'])
    @requer_permissao('tesouraria.criar')
    def gerar_folha():
        """Despesas a pagar do mês para quem recebe mensalmente (uma por pessoa, sem duplicar)."""
        comp = (request.get_json(silent=True) or {}).get('competencia') or ''
        if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])', comp):
            return jsonify({'erro': 'Informe o mês no formato AAAA-MM'}), 400
        ano, mes = int(comp[:4]), int(comp[5:])
        ultimo = calendar.monthrange(ano, mes)[1]
        conn = get_db()
        try:
            if periodo_fechado(conn, f'{comp}-01'):
                return jsonify({'erro': msg_fechado(f'{comp}-01')}), 409
            criados, existentes = 0, 0
            for f in conn.execute("""SELECT * FROM funcionarios WHERE ativo = 1 AND periodicidade = 'mensal' AND remuneracao > 0
                                     AND (data_desligamento IS NULL OR data_desligamento >= ?)""", (f'{comp}-01',)).fetchall():
                doc = f'FOLHA-{comp}'
                if conn.execute('SELECT 1 FROM financeiro WHERE funcionario_id = ? AND documento = ?', (f['id'], doc)).fetchone():
                    existentes += 1
                    continue
                venc = f"{comp}-{min(f['dia_pagamento'] or 5, ultimo):02d}"
                tipo_pg = PAGAMENTO_DA_FOLHA.get(f['tipo'], 'salario')
                rotulo = {'prebenda': 'Prebenda', 'ajuda_custo': 'Ajuda de custo'}.get(
                    tipo_pg, 'Salário' if f['tipo'] in COM_VINCULO else 'Serviço mensal')
                _inserir_pagamento(conn, f, tipo_pg, f['remuneracao'], venc, f"{rotulo} {mes:02d}/{ano} – {f['nome']}",
                                   'pendente', venc, competencia=comp, documento=doc)
                criados += 1
            registrar('tesouraria', f'Gerou a folha de {mes:02d}/{ano}', f'{criados} pagamento(s)', conn)
            conn.commit()
            msg = f'{criados} pagamento(s) da folha de {mes:02d}/{ano} criados em Contas a pagar'
            return jsonify({'msg': msg + (f' ({existentes} já existiam)' if existentes else ''), 'criados': criados}), 201
        finally:
            conn.close()
