"""Configurações do sistema (modo de teste) e backup do banco."""
import os
import sqlite3
import tempfile
from datetime import datetime

from flask import request, jsonify, send_file, after_this_request

from app.auditoria import registrar
from app.auth_utils import requer_permissao
from app.database import get_db, obter_config, DB_PATH


def modo_teste():
    return obter_config('modo_teste', '1') == '1'


def registrar_sistema(app):

    @app.route('/api/config', methods=['GET'])
    def config_publica():
        """Público: a tela de login usa para decidir se mostra os perfis de teste."""
        return jsonify({'modo_teste': modo_teste(), 'igreja': 'AD Ministério do Belém - São José dos Campos'}), 200

    @app.route('/api/admin/config', methods=['PUT'])
    @requer_permissao('admin.editar')
    def salvar_config():
        d = request.get_json(silent=True) or {}
        if 'modo_teste' not in d:
            return jsonify({'erro': "Informe 'modo_teste'"}), 400
        valor = '1' if d['modo_teste'] in (True, 1, '1', 'true') else '0'
        conn = get_db()
        try:
            conn.execute('INSERT OR REPLACE INTO configuracoes (chave, valor) VALUES (?, ?)', ('modo_teste', valor))
            registrar('admin', f"Modo de teste {'ligado' if valor == '1' else 'desligado'}", '', conn)
            conn.commit()
        finally:
            conn.close()
        return jsonify({'msg': 'Configuração salva', 'modo_teste': valor == '1'}), 200

    @app.route('/api/admin/backup', methods=['GET'])
    @requer_permissao('admin.editar')
    def baixar_backup():
        """Cópia consistente do banco SQLite (feita com a API de backup, segura com o sistema em uso)."""
        fd, caminho = tempfile.mkstemp(suffix='.db')
        os.close(fd)
        origem = sqlite3.connect(DB_PATH)
        destino = sqlite3.connect(caminho)
        try:
            origem.backup(destino)
        finally:
            destino.close()
            origem.close()
        registrar('admin', 'Baixou backup do banco', '')

        @after_this_request
        def _limpar(resposta):
            try:
                os.remove(caminho)
            except OSError:
                pass   # no Windows o arquivo ainda pode estar aberto; o sistema limpa a pasta temporária depois
            return resposta

        nome = f"intranet-ad-belem-backup-{datetime.now():%Y%m%d-%H%M}.db"
        return send_file(caminho, as_attachment=True, download_name=nome, mimetype='application/octet-stream')
