"""Tesouraria > Congregações: acertos de contas, recebimentos, débitos e pendências; classificação de PIX.

Acerto (prestação de contas da congregação no período):
    arrecadado (dízimos + ofertas + ofertas alçadas + missões + outras)
  - despesas locais autorizadas
  + débitos da congregação com a sede (ex.: revistas da EBD)
  = valor a repassar à sede

Ao RECEBER o acerto, a Tesouraria lança na contabilidade da sede, com a congregação marcada:
receitas por categoria (bruto), despesa das despesas locais e o ressarcimento dos débitos.
Se o dinheiro chegou por PIX/depósito já registrado pelo banco, ele é vinculado e não é lançado em dobro.
"""
from datetime import date, timedelta

from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao, usuario_atual
from app.database import get_db, rows_to_dicts
from app.validacao import ErroValidacao, texto, numero, data_iso, inteiro, opcao, brl

FORMAS = ('dinheiro', 'pix', 'deposito', 'transferencia')
CAT_RECEITA = ('dizimo', 'oferta', 'oferta_alcada', 'campanha', 'evento', 'outro')


def _erro(msg, codigo=400):
    return jsonify({'erro': str(msg)}), codigo


def ultimo_periodo_fechado(periodicidade, hoje=None):
    """Data final do último período que já deveria ter acerto (domingo anterior ou fim do mês anterior)."""
    hoje = hoje or date.today()
    if periodicidade == 'semanal':
        return hoje - timedelta(days=(hoje.weekday() + 1) % 7 or 7)   # domingo anterior
    return hoje.replace(day=1) - timedelta(days=1)                    # último dia do mês anterior


def registrar_acertos(app):

    @app.route('/api/acertos', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def listar_acertos():
        params, where = [], ''
        if request.args.get('congregacao_id'):
            where, params = ' WHERE a.congregacao_id = ?', [request.args.get('congregacao_id')]
        conn = get_db()
        try:
            rows = conn.execute(f'''SELECT a.*, c.nome AS congregacao_nome FROM acertos a
                                    JOIN congregacoes c ON c.id = a.congregacao_id{where}
                                    ORDER BY a.periodo_fim DESC, a.id DESC LIMIT 500''', params).fetchall()
            return jsonify({'acertos': rows_to_dicts(rows)}), 200
        finally:
            conn.close()

    @app.route('/api/acertos/pendentes', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def acertos_pendentes():
        """Congregações sem acerto do último período (semanal ou mensal) e débitos em aberto."""
        hoje = date.today()
        conn = get_db()
        try:
            cong = conn.execute('''SELECT c.id, c.nome, c.dirigente, COALESCE(c.periodicidade_acerto, 'mensal') AS periodicidade,
                                          (SELECT MAX(periodo_fim) FROM acertos a WHERE a.congregacao_id = c.id) AS ultimo_fim,
                                          (SELECT COALESCE(SUM(valor), 0) FROM congregacao_debitos d
                                            WHERE d.congregacao_id = c.id AND d.status = 'aberto') AS debitos_abertos,
                                          (SELECT COUNT(*) FROM acertos a WHERE a.congregacao_id = c.id AND a.status = 'enviado') AS a_receber
                                   FROM congregacoes c WHERE c.ativo = 1 ORDER BY c.nome''').fetchall()
            lista = []
            for c in rows_to_dicts(cong):
                limite = ultimo_periodo_fechado(c['periodicidade'], hoje)
                c['periodo_esperado_ate'] = limite.isoformat()
                c['pendente'] = not c['ultimo_fim'] or c['ultimo_fim'] < limite.isoformat()
                c['dias_atraso'] = (hoje - limite).days if c['pendente'] else 0
                lista.append(c)
            return jsonify({'congregacoes': lista,
                            'pendentes': sum(1 for c in lista if c['pendente'])}), 200
        finally:
            conn.close()

    @app.route('/api/acertos', methods=['POST'])
    @requer_permissao('tesouraria.criar')
    def criar_acerto():
        d = request.get_json(silent=True) or {}
        try:
            a = {
                'congregacao_id': inteiro(d, 'congregacao_id', obrigatorio=True),
                'periodo_inicio': data_iso(d, 'periodo_inicio', True),
                'periodo_fim': data_iso(d, 'periodo_fim', True),
                'dizimos': numero(d, 'dizimos', minimo=0), 'ofertas': numero(d, 'ofertas', minimo=0),
                'ofertas_alcadas': numero(d, 'ofertas_alcadas', minimo=0), 'missoes': numero(d, 'missoes', minimo=0),
                'outras': numero(d, 'outras', minimo=0), 'despesas_locais': numero(d, 'despesas_locais', minimo=0),
                'observacoes': texto(d, 'observacoes', max_len=1000),
            }
            if a['periodo_fim'] < a['periodo_inicio']:
                raise ErroValidacao('O fim do período deve ser depois do início')
        except ErroValidacao as e:
            return _erro(e)
        ids_debitos = [int(x) for x in (d.get('debitos') or [])]
        conn = get_db()
        try:
            if not conn.execute('SELECT 1 FROM congregacoes WHERE id = ?', (a['congregacao_id'],)).fetchone():
                return _erro('Congregação não encontrada', 404)
            debitos = conn.execute(f'''SELECT id, valor FROM congregacao_debitos WHERE congregacao_id = ? AND status = 'aberto'
                                       AND id IN ({','.join('?' * len(ids_debitos)) or 'NULL'})''',
                                   [a['congregacao_id'], *ids_debitos]).fetchall()
            a['debitos'] = round(sum(x['valor'] for x in debitos), 2)
            arrecadado = a['dizimos'] + a['ofertas'] + a['ofertas_alcadas'] + a['missoes'] + a['outras']
            a['valor_repasse'] = round(arrecadado - a['despesas_locais'] + a['debitos'], 2)
            if a['valor_repasse'] < 0:
                return _erro('As despesas locais são maiores que o arrecadado: confira os valores')
            a['criado_por'] = usuario_atual()['nome']
            cols = list(a)
            cur = conn.execute(f'INSERT INTO acertos ({", ".join(cols)}) VALUES ({", ".join("?" * len(cols))})', [a[c] for c in cols])
            for x in debitos:
                conn.execute('UPDATE congregacao_debitos SET acerto_id = ? WHERE id = ?', (cur.lastrowid, x['id']))
            registrar('tesouraria', f'Registrou acerto #{cur.lastrowid}', f"cong. #{a['congregacao_id']} {brl(a['valor_repasse'])}", conn)
            conn.commit()
            return jsonify({'msg': f"Acerto registrado: a repassar {brl(a['valor_repasse'])}", 'id': cur.lastrowid,
                            'valor_repasse': a['valor_repasse']}), 201
        finally:
            conn.close()

    @app.route('/api/acertos/<int:id>/receber', methods=['POST'])
    @requer_permissao('tesouraria.aprovar')
    def receber_acerto(id):
        d = request.get_json(silent=True) or {}
        try:
            mov_id = inteiro(d, 'banco_movimento_id')
            # com PIX/depósito vinculado, o valor e a forma vêm do próprio movimento bancário
            valor = numero(d, 'valor_recebido', obrigatorio=not mov_id, minimo=0)
            forma = opcao(d, 'forma', FORMAS, 'dinheiro')
            dia = data_iso(d, 'data') or date.today().isoformat()
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            a = conn.execute('SELECT a.*, c.nome AS cong FROM acertos a JOIN congregacoes c ON c.id = a.congregacao_id WHERE a.id = ?',
                             (id,)).fetchone()
            if not a:
                return _erro('Acerto não encontrado', 404)
            if a['status'] != 'enviado':
                return _erro('Este acerto já foi recebido', 409)
            if mov_id:   # o dinheiro veio por PIX/depósito já registrado: troca o lançamento automático pelo do acerto
                mov = conn.execute('SELECT * FROM banco_movimentos WHERE id = ?', (mov_id,)).fetchone()
                if not mov or mov['acerto_id']:
                    return _erro('Movimento bancário não encontrado ou já vinculado', 400)
                if mov['financeiro_id']:
                    conn.execute('DELETE FROM financeiro WHERE id = ?', (mov['financeiro_id'],))
                    # o movimento do extrato continua conciliado: o dinheiro está explicado pelo acerto
                    conn.execute("UPDATE extrato SET financeiro_id = NULL, descricao = descricao || ' (acerto)' WHERE financeiro_id = ?",
                                 (mov['financeiro_id'],))
                conn.execute("UPDATE banco_movimentos SET acerto_id = ?, financeiro_id = NULL, classificado = 1, categoria = 'repasse' WHERE id = ?",
                             (id, mov_id))
                valor, forma = mov['valor'], 'pix' if mov['tipo'] == 'pix' else 'deposito'
            periodo = f"{date.fromisoformat(a['periodo_inicio']):%d/%m}–{date.fromisoformat(a['periodo_fim']):%d/%m/%Y}"
            uid = usuario_atual()['id']
            forma_fin = 'pix' if forma == 'pix' else 'dinheiro' if forma == 'dinheiro' else 'transferencia'

            def lancar(tipo, categoria, valor_l, rotulo, status):
                if valor_l > 0:
                    conn.execute('''INSERT INTO financeiro (tipo, descricao, valor, data, categoria, status, forma, congregacao_id,
                                    usuario_id, aprovacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'aprovado')''',
                                 (tipo, f"Acerto {a['cong']} {periodo}: {rotulo}", round(valor_l, 2), dia, categoria, status,
                                  forma_fin, a['congregacao_id'], uid))
            lancar('receita', 'dizimo', a['dizimos'], 'dízimos', 'confirmada')
            lancar('receita', 'oferta', a['ofertas'], 'ofertas', 'confirmada')
            lancar('receita', 'oferta_alcada', a['ofertas_alcadas'], 'ofertas alçadas', 'confirmada')
            lancar('receita', 'campanha', a['missoes'], 'missões', 'confirmada')
            lancar('receita', 'outro', a['outras'], 'outras entradas', 'confirmada')
            lancar('receita', 'outro', a['debitos'], 'ressarcimento de débitos (revistas/materiais)', 'confirmada')
            lancar('despesa', 'outro', a['despesas_locais'], 'despesas locais autorizadas', 'pago')
            conn.execute("UPDATE congregacao_debitos SET status = 'quitado' WHERE acerto_id = ?", (id,))
            dif = round(valor - a['valor_repasse'], 2)
            status = 'recebido' if abs(dif) < 0.01 else 'divergente'
            conn.execute('''UPDATE acertos SET valor_recebido = ?, forma = ?, data_recebimento = ?, banco_movimento_id = ?,
                            status = ?, recebido_por = ? WHERE id = ?''',
                         (valor, forma, dia, mov_id, status, usuario_atual()['nome'], id))
            registrar('tesouraria', f'Recebeu acerto #{id} ({a["cong"]})', f'{brl(valor)} {status}', conn)
            conn.commit()
            msg = f"Acerto recebido: {brl(valor)}." if status == 'recebido' else \
                f"Recebido com diferença de {brl(dif)} (esperado {brl(a['valor_repasse'])}). O acerto ficou marcado como divergente."
            return jsonify({'msg': msg, 'status': status, 'diferenca': dif}), 200
        finally:
            conn.close()

    @app.route('/api/acertos/<int:id>', methods=['DELETE'])
    @requer_permissao('tesouraria.criar')
    def excluir_acerto(id):
        conn = get_db()
        try:
            a = conn.execute('SELECT status FROM acertos WHERE id = ?', (id,)).fetchone()
            if not a:
                return _erro('Acerto não encontrado', 404)
            if a['status'] != 'enviado':
                return _erro('Acerto já recebido não pode ser excluído', 409)
            conn.execute('UPDATE congregacao_debitos SET acerto_id = NULL WHERE acerto_id = ?', (id,))
            conn.execute('DELETE FROM acertos WHERE id = ?', (id,))
            registrar('tesouraria', f'Excluiu acerto #{id}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Acerto excluído'}), 200
        finally:
            conn.close()

    # ---------------- Débitos da congregação com a sede ----------------
    @app.route('/api/congregacoes/debitos', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def listar_debitos():
        params, where = [], ''
        if request.args.get('congregacao_id'):
            where, params = ' AND d.congregacao_id = ?', [request.args.get('congregacao_id')]
        if request.args.get('status'):
            where += ' AND d.status = ?'
            params.append(request.args.get('status'))
        conn = get_db()
        try:
            rows = conn.execute(f'''SELECT d.*, c.nome AS congregacao_nome FROM congregacao_debitos d
                                    JOIN congregacoes c ON c.id = d.congregacao_id WHERE 1=1{where}
                                    ORDER BY d.status, d.criado_em DESC''', params).fetchall()
            return jsonify({'debitos': rows_to_dicts(rows)}), 200
        finally:
            conn.close()

    @app.route('/api/congregacoes/debitos', methods=['POST'])
    @requer_permissao('tesouraria.criar')
    def criar_debito():
        d = request.get_json(silent=True) or {}
        try:
            cong = inteiro(d, 'congregacao_id', obrigatorio=True)
            desc = texto(d, 'descricao', True, 200)
            valor = numero(d, 'valor', obrigatorio=True, positivo=True)
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            cur = conn.execute('INSERT INTO congregacao_debitos (congregacao_id, descricao, valor) VALUES (?,?,?)', (cong, desc, valor))
            registrar('tesouraria', f'Lançou débito #{cur.lastrowid} para congregação #{cong}', f'{desc} {brl(valor)}', conn)
            conn.commit()
            return jsonify({'msg': 'Débito lançado para a congregação', 'id': cur.lastrowid}), 201
        finally:
            conn.close()

    # ---------------- PIX a classificar ----------------
    @app.route('/api/banco/movimentos/<int:id>/classificar', methods=['PATCH'])
    @requer_permissao('tesouraria.criar')
    def classificar_movimento(id):
        d = request.get_json(silent=True) or {}
        try:
            categoria = opcao(d, 'categoria', CAT_RECEITA)
            membro_id = inteiro(d, 'membro_id')
            cong_id = inteiro(d, 'congregacao_id')
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            mov = conn.execute('SELECT * FROM banco_movimentos WHERE id = ?', (id,)).fetchone()
            if not mov:
                return _erro('Movimento não encontrado', 404)
            if mov['acerto_id']:
                return _erro('Este valor já foi vinculado a um acerto de congregação', 409)
            conn.execute('UPDATE financeiro SET categoria = ?, membro_id = ?, congregacao_id = ? WHERE id = ?',
                         (categoria, membro_id, cong_id, mov['financeiro_id']))
            conn.execute('UPDATE banco_movimentos SET categoria = ?, membro_id = ?, classificado = 1 WHERE id = ?',
                         (categoria, membro_id, id))
            registrar('tesouraria', f'Classificou movimento bancário #{id}', categoria, conn)
            conn.commit()
            return jsonify({'msg': 'Recebimento classificado'}), 200
        finally:
            conn.close()
