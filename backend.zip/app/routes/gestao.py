"""Cadastros e controles de gestão (versão 1.1).

Tesouraria : fornecedores, plano de contas, contas recorrentes, contas a pagar,
             demonstrativo mensal e fechamento do mês (bloqueia alterações).
Secretaria : visitantes (acompanhamento e "tornar membro"), departamentos e ministérios.
Patrimônio : movimentação de bens (transferência, manutenção, empréstimo, retorno, baixa)
             e inventário com conferência item a item.
"""
import calendar
import re
import unicodedata
from datetime import date, timedelta

from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao, usuario_atual
from app.crud import registrar_crud
from app.database import get_db, rows_to_dicts
from app.periodos import periodo_fechado, msg_fechado, competencia_de
from app.validacao import ErroValidacao, texto, opcao, numero, data_iso, inteiro, brl

FORMAS = ('dinheiro', 'pix', 'transferencia', 'cartao', 'boleto', 'debito_automatico')
SITUACOES_VISITANTE = ('novo', 'contatado', 'acompanhamento', 'integrado', 'membro', 'sem_interesse')
TIPOS_DEPTO = ('departamento', 'ministerio', 'conjunto', 'comissao')
TIPOS_MOV_BEM = ('transferencia', 'manutencao', 'retorno', 'emprestimo', 'baixa')
SITUACOES_INVENTARIO = ('pendente', 'encontrado', 'nao_encontrado', 'danificado')


def _erro(msg, codigo=400):
    return jsonify({'erro': msg}), codigo


def _competencia(valor):
    if not valor or not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])', valor):
        raise ErroValidacao('Informe o mês no formato AAAA-MM')
    return valor


def _slug(nome):
    s = unicodedata.normalize('NFKD', nome).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+', '_', s).strip('_')[:40] or 'conta'


def _ativo(d):
    return 0 if str(d.get('ativo', '1')) in ('0', 'false', 'False') else 1


def demonstrativo(conn, comp):
    """Receitas e despesas do mês por conta do plano, com saldo anterior e final (só o que tem "de acordo")."""
    ini = f'{comp}-01'
    fim = f'{comp}-{calendar.monthrange(int(comp[:4]), int(comp[5:]))[1]:02d}'
    ok = "COALESCE(f.aprovacao, 'aprovado') = 'aprovado'"
    ant = conn.execute(f'''SELECT COALESCE(SUM(CASE WHEN tipo = 'receita' THEN valor ELSE -valor END), 0)
                           FROM financeiro f WHERE {ok} AND data < ?''', (ini,)).fetchone()[0]
    contas = rows_to_dicts(conn.execute(f'''
        SELECT f.tipo, f.categoria, COALESCE(p.codigo, '') AS codigo, COALESCE(p.nome, f.categoria) AS conta,
               COALESCE(p.grupo, '') AS grupo, COUNT(*) AS lancamentos, ROUND(SUM(f.valor), 2) AS total
        FROM financeiro f LEFT JOIN plano_contas p ON p.tipo = f.tipo AND p.chave = f.categoria
        WHERE {ok} AND f.data BETWEEN ? AND ?
        GROUP BY f.tipo, f.categoria ORDER BY f.tipo DESC, codigo''', (ini, fim)))
    unidades = rows_to_dicts(conn.execute(f'''
        SELECT COALESCE((SELECT nome FROM congregacoes c WHERE c.id = f.congregacao_id), 'Sede') AS unidade,
               ROUND(SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END), 2) AS receitas,
               ROUND(SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END), 2) AS despesas
        FROM financeiro f WHERE {ok} AND f.data BETWEEN ? AND ? GROUP BY f.congregacao_id ORDER BY unidade''', (ini, fim)))
    rec = round(sum(c['total'] for c in contas if c['tipo'] == 'receita'), 2)
    desp = round(sum(c['total'] for c in contas if c['tipo'] == 'despesa'), 2)
    a_pagar = conn.execute(f'''SELECT COALESCE(SUM(valor), 0) FROM financeiro f WHERE {ok} AND tipo = 'despesa'
                               AND status = 'pendente' AND data BETWEEN ? AND ?''', (ini, fim)).fetchone()[0]
    pend = conn.execute('''SELECT COUNT(*) FROM financeiro WHERE aprovacao = 'pendente' AND data BETWEEN ? AND ?''',
                        (ini, fim)).fetchone()[0]
    fech = conn.execute('SELECT * FROM periodos_fechados WHERE competencia = ?', (comp,)).fetchone()
    return {'competencia': comp, 'inicio': ini, 'fim': fim, 'saldo_anterior': round(ant, 2), 'receitas': rec,
            'despesas': desp, 'resultado': round(rec - desp, 2), 'saldo_final': round(ant + rec - desp, 2),
            'despesas_a_pagar': round(a_pagar, 2), 'aguardando_de_acordo': pend, 'contas': contas,
            'unidades': unidades, 'fechamento': dict(fech) if fech else None}


def registrar_gestao(app):
    # ======================= TESOURARIA =======================
    registrar_crud(app, rota='fornecedores', tabela='fornecedores', modulo='tesouraria', rotulo='fornecedor',
                   ordem='t.ativo DESC, t.nome COLLATE NOCASE', filtros=('ramo', 'ativo'), campos={
                       'nome': lambda d: texto(d, 'nome', obrigatorio=True, max_len=150),
                       'documento': lambda d: texto(d, 'documento', max_len=20),
                       'ramo': lambda d: texto(d, 'ramo', max_len=60),
                       'contato': lambda d: texto(d, 'contato', max_len=100),
                       'telefone': lambda d: texto(d, 'telefone', max_len=30),
                       'email': lambda d: texto(d, 'email', max_len=120),
                       'pix': lambda d: texto(d, 'pix', max_len=120),
                       'banco': lambda d: texto(d, 'banco', max_len=120),
                       'endereco': lambda d: texto(d, 'endereco', max_len=250),
                       'observacoes': lambda d: texto(d, 'observacoes', max_len=1000),
                       'ativo': _ativo,
                   })

    # ---- Plano de contas: todos consultam; só o chefe da Tesouraria altera (sem excluir, para não perder histórico)
    @app.route('/api/plano-contas', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def plano_listar():
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('''
                SELECT p.*, (SELECT COUNT(*) FROM financeiro f WHERE f.tipo = p.tipo AND f.categoria = p.chave) AS usos
                FROM plano_contas p ORDER BY p.codigo'''))
            return jsonify({'contas': rows}), 200
        finally:
            conn.close()

    def _ler_conta(d):
        return {'codigo': texto(d, 'codigo', obrigatorio=True, max_len=20),
                'nome': texto(d, 'nome', obrigatorio=True, max_len=100),
                'grupo': texto(d, 'grupo', max_len=60), 'ativo': _ativo(d)}

    @app.route('/api/plano-contas', methods=['POST'])
    @requer_permissao('tesouraria.deletar')
    def plano_criar():
        d = request.get_json(silent=True) or {}
        try:
            reg = _ler_conta(d)
            reg['tipo'] = opcao(d, 'tipo', ('receita', 'despesa'))
            if not reg['tipo']:
                raise ErroValidacao('Informe se a conta é de receita ou de despesa')
        except ErroValidacao as e:
            return _erro(str(e))
        reg['chave'] = _slug(reg['nome'])
        conn = get_db()
        try:
            if conn.execute('SELECT 1 FROM plano_contas WHERE tipo = ? AND chave = ?', (reg['tipo'], reg['chave'])).fetchone():
                return _erro('Já existe uma conta com esse nome')
            if conn.execute('SELECT 1 FROM plano_contas WHERE codigo = ?', (reg['codigo'],)).fetchone():
                return _erro(f"O código {reg['codigo']} já está em uso")
            cur = conn.execute('INSERT INTO plano_contas (codigo, chave, nome, tipo, grupo, ativo) VALUES (?, ?, ?, ?, ?, ?)',
                               (reg['codigo'], reg['chave'], reg['nome'], reg['tipo'], reg['grupo'], reg['ativo']))
            registrar('tesouraria', f'Criou conta {reg["codigo"]} no plano de contas', reg['nome'], conn)
            conn.commit()
            return jsonify({'msg': 'Conta criada', 'id': cur.lastrowid}), 201
        finally:
            conn.close()

    @app.route('/api/plano-contas/<int:id>', methods=['PUT'])
    @requer_permissao('tesouraria.deletar')
    def plano_editar(id):
        try:
            reg = _ler_conta(request.get_json(silent=True) or {})
        except ErroValidacao as e:
            return _erro(str(e))
        conn = get_db()
        try:
            if conn.execute('SELECT 1 FROM plano_contas WHERE codigo = ? AND id != ?', (reg['codigo'], id)).fetchone():
                return _erro(f"O código {reg['codigo']} já está em uso")
            cur = conn.execute('UPDATE plano_contas SET codigo = ?, nome = ?, grupo = ?, ativo = ? WHERE id = ?',
                               (reg['codigo'], reg['nome'], reg['grupo'], reg['ativo'], id))
            if not cur.rowcount:
                return _erro('Conta não encontrada', 404)
            registrar('tesouraria', f'Alterou a conta {reg["codigo"]} do plano de contas', reg['nome'], conn)
            conn.commit()
            return jsonify({'msg': 'Conta atualizada'}), 200
        finally:
            conn.close()

    # ---- Contas recorrentes (água, luz, aluguel, salários...) e contas a pagar
    registrar_crud(app, rota='tesouraria/recorrentes', tabela='contas_recorrentes', modulo='tesouraria',
                   chave_lista='recorrentes', rotulo='conta recorrente', escopo=True,
                   ordem='t.ativo DESC, t.dia_vencimento', campos={
                       'descricao': lambda d: texto(d, 'descricao', obrigatorio=True, max_len=150),
                       'fornecedor_id': lambda d: inteiro(d, 'fornecedor_id'),
                       'categoria': lambda d: texto(d, 'categoria', obrigatorio=True, max_len=40),
                       'valor': lambda d: numero(d, 'valor', obrigatorio=True, positivo=True),
                       'dia_vencimento': lambda d: inteiro(d, 'dia_vencimento', obrigatorio=True, minimo=1),
                       'forma': lambda d: opcao(d, 'forma', FORMAS, padrao='boleto'),
                       'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
                       'observacoes': lambda d: texto(d, 'observacoes', max_len=500),
                       'ativo': _ativo,
                   })

    @app.route('/api/tesouraria/recorrentes/gerar', methods=['POST'])
    @requer_permissao('tesouraria.criar')
    def recorrentes_gerar():
        """Cria, para o mês, as despesas pendentes das contas recorrentes ativas (sem duplicar)."""
        try:
            comp = _competencia((request.get_json(silent=True) or {}).get('competencia'))
        except ErroValidacao as e:
            return _erro(str(e))
        ano, mes = int(comp[:4]), int(comp[5:])
        ultimo = calendar.monthrange(ano, mes)[1]
        user = usuario_atual()
        conn = get_db()
        try:
            if periodo_fechado(conn, f'{comp}-01'):
                return _erro(msg_fechado(f'{comp}-01'), 409)
            criadas, ja_existiam = [], 0
            for r in conn.execute('SELECT * FROM contas_recorrentes WHERE ativo = 1').fetchall():
                if conn.execute('SELECT 1 FROM financeiro WHERE recorrente_id = ? AND competencia = ?', (r['id'], comp)).fetchone():
                    ja_existiam += 1
                    continue
                venc = f'{comp}-{min(r["dia_vencimento"], ultimo):02d}'
                conn.execute('''INSERT INTO financeiro (tipo, descricao, valor, data, vencimento, categoria, status, forma,
                                  congregacao_id, fornecedor_id, recorrente_id, competencia, usuario_id, aprovacao)
                                VALUES ('despesa', ?, ?, ?, ?, ?, 'pendente', ?, ?, ?, ?, ?, ?, 'aprovado')''',
                             (f'{r["descricao"]} ({mes:02d}/{ano})', r['valor'], venc, venc, r['categoria'], r['forma'],
                              r['congregacao_id'], r['fornecedor_id'], r['id'], comp, user['id']))
                criadas.append(r['descricao'])
            registrar('tesouraria', f'Gerou contas recorrentes de {mes:02d}/{ano}', f'{len(criadas)} conta(s)', conn)
            conn.commit()
            msg = f'{len(criadas)} conta(s) a pagar criada(s) para {mes:02d}/{ano}'
            if ja_existiam:
                msg += f' ({ja_existiam} já existiam)'
            return jsonify({'msg': msg, 'criadas': len(criadas), 'ja_existiam': ja_existiam}), 201
        finally:
            conn.close()

    @app.route('/api/tesouraria/contas-a-pagar', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def contas_a_pagar():
        hoje = date.today()
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('''
                SELECT f.id, f.descricao, f.valor, f.data, COALESCE(f.vencimento, f.data) AS vencimento, f.categoria,
                       f.forma, f.documento, f.congregacao_id, f.recorrente_id,
                       (SELECT nome FROM fornecedores o WHERE o.id = f.fornecedor_id) AS fornecedor_nome,
                       (SELECT nome FROM congregacoes c WHERE c.id = f.congregacao_id) AS congregacao_nome
                FROM financeiro f
                WHERE f.tipo = 'despesa' AND f.status = 'pendente' AND COALESCE(f.aprovacao, 'aprovado') = 'aprovado'
                ORDER BY COALESCE(f.vencimento, f.data), f.id'''))
            for r in rows:
                r['dias'] = (date.fromisoformat(r['vencimento']) - hoje).days
            soma = lambda f: round(sum(r['valor'] for r in rows if f(r)), 2)  # noqa: E731
            return jsonify({'contas': rows, 'total': soma(lambda r: True), 'vencidas': soma(lambda r: r['dias'] < 0),
                            'proximos_7_dias': soma(lambda r: 0 <= r['dias'] <= 7),
                            'qtd_vencidas': sum(1 for r in rows if r['dias'] < 0)}), 200
        finally:
            conn.close()

    # ---- Demonstrativo mensal e fechamento do mês
    @app.route('/api/tesouraria/demonstrativo', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def ver_demonstrativo():
        try:
            comp = _competencia(request.args.get('competencia') or date.today().strftime('%Y-%m'))
        except ErroValidacao as e:
            return _erro(str(e))
        conn = get_db()
        try:
            return jsonify(demonstrativo(conn, comp)), 200
        finally:
            conn.close()

    @app.route('/api/tesouraria/fechamentos', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def listar_fechamentos():
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('SELECT * FROM periodos_fechados ORDER BY competencia DESC'))
            return jsonify({'fechamentos': rows}), 200
        finally:
            conn.close()

    @app.route('/api/tesouraria/fechamentos', methods=['POST'])
    @requer_permissao('tesouraria.aprovar')
    def fechar_mes():
        d = request.get_json(silent=True) or {}
        try:
            comp = _competencia(d.get('competencia'))
            obs = texto(d, 'observacao', max_len=500)
        except ErroValidacao as e:
            return _erro(str(e))
        if comp >= date.today().strftime('%Y-%m'):
            return _erro('Só é possível fechar um mês que já terminou')
        conn = get_db()
        try:
            if periodo_fechado(conn, f'{comp}-01'):
                return _erro('Este mês já está fechado')
            dem = demonstrativo(conn, comp)
            if dem['aguardando_de_acordo']:
                return _erro(f"Há {dem['aguardando_de_acordo']} lançamento(s) do mês aguardando \"de acordo\". "
                             'Resolva antes de fechar.')
            conn.execute('''INSERT INTO periodos_fechados (competencia, receitas, despesas, saldo, observacao, fechado_por)
                            VALUES (?, ?, ?, ?, ?, ?)''',
                         (comp, dem['receitas'], dem['despesas'], dem['saldo_final'], obs, usuario_atual()['nome']))
            registrar('tesouraria', f'Fechou o mês {comp[5:]}/{comp[:4]}',
                      f"receitas {brl(dem['receitas'])}, despesas {brl(dem['despesas'])}, saldo {brl(dem['saldo_final'])}", conn)
            conn.commit()
            return jsonify({'msg': f'Mês {comp[5:]}/{comp[:4]} fechado. Lançamentos desse mês ficam bloqueados.'}), 201
        finally:
            conn.close()

    @app.route('/api/tesouraria/fechamentos/<comp>', methods=['DELETE'])
    @requer_permissao('tesouraria.deletar')
    def reabrir_mes(comp):
        motivo = texto(request.get_json(silent=True) or {}, 'motivo', max_len=500)
        if not motivo:
            return _erro('Informe o motivo da reabertura (fica registrado no log)')
        conn = get_db()
        try:
            if not conn.execute('DELETE FROM periodos_fechados WHERE competencia = ?', (comp,)).rowcount:
                return _erro('Mês não está fechado', 404)
            registrar('tesouraria', f'Reabriu o mês {comp[5:]}/{comp[:4]}', motivo, conn)
            conn.commit()
            return jsonify({'msg': 'Mês reaberto'}), 200
        finally:
            conn.close()

    # ======================= SECRETARIA =======================
    registrar_crud(app, rota='visitantes', tabela='visitantes', modulo='secretaria', rotulo='visitante', escopo=True,
                   ordem='t.data_visita DESC, t.id DESC', filtros=('situacao', 'congregacao_id'), campos={
                       'nome': lambda d: texto(d, 'nome', obrigatorio=True, max_len=150),
                       'telefone': lambda d: texto(d, 'telefone', max_len=30),
                       'email': lambda d: texto(d, 'email', max_len=120),
                       'bairro': lambda d: texto(d, 'bairro', max_len=80),
                       'data_visita': lambda d: data_iso(d, 'data_visita') or date.today().isoformat(),
                       'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
                       'convidado_por': lambda d: texto(d, 'convidado_por', max_len=120),
                       'como_conheceu': lambda d: texto(d, 'como_conheceu', max_len=60),
                       'igreja_atual': lambda d: texto(d, 'igreja_atual', max_len=120),
                       'pedido_oracao': lambda d: texto(d, 'pedido_oracao', max_len=1000),
                       'situacao': lambda d: opcao(d, 'situacao', SITUACOES_VISITANTE, padrao='novo'),
                       'responsavel': lambda d: texto(d, 'responsavel', max_len=120),
                       'ultimo_contato': lambda d: data_iso(d, 'ultimo_contato'),
                       'observacoes': lambda d: texto(d, 'observacoes', max_len=2000),
                   })

    @app.route('/api/visitantes/<int:id>/tornar-membro', methods=['POST'])
    @requer_permissao('membros.criar')
    def visitante_para_membro(id):
        conn = get_db()
        try:
            v = conn.execute('SELECT * FROM visitantes WHERE id = ?', (id,)).fetchone()
            if not v:
                return _erro('Visitante não encontrado', 404)
            if v['membro_id']:
                return _erro('Este visitante já foi cadastrado como membro')
            cur = conn.execute('''INSERT INTO membros (nome, telefone, celular, email, bairro, congregacao_id, status,
                                    funcao, data_cadastro, observacoes, igreja_origem)
                                  VALUES (?, ?, ?, ?, ?, ?, 'ativo', 'Membro', ?, ?, ?)''',
                               (v['nome'], v['telefone'], v['telefone'], v['email'], v['bairro'], v['congregacao_id'],
                                date.today().isoformat(), f"Veio como visitante em {v['data_visita'] or '-'}", v['igreja_atual']))
            conn.execute("UPDATE visitantes SET membro_id = ?, situacao = 'membro' WHERE id = ?", (cur.lastrowid, id))
            registrar('membros', f'Cadastrou membro #{cur.lastrowid} a partir do visitante #{id}', v['nome'], conn)
            conn.commit()
            return jsonify({'msg': 'Membro cadastrado. Complete os dados no Rol de membros.', 'membro_id': cur.lastrowid}), 201
        finally:
            conn.close()

    registrar_crud(app, rota='departamentos', tabela='departamentos', modulo='secretaria', rotulo='departamento',
                   escopo=True, ordem='t.ativo DESC, t.nome COLLATE NOCASE', filtros=('tipo', 'congregacao_id'), campos={
                       'nome': lambda d: texto(d, 'nome', obrigatorio=True, max_len=120),
                       'tipo': lambda d: opcao(d, 'tipo', TIPOS_DEPTO, padrao='departamento'),
                       'lider': lambda d: texto(d, 'lider', max_len=120),
                       'vice_lider': lambda d: texto(d, 'vice_lider', max_len=120),
                       'secretario': lambda d: texto(d, 'secretario', max_len=120),
                       'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
                       'reunioes': lambda d: texto(d, 'reunioes', max_len=150),
                       'participantes': lambda d: inteiro(d, 'participantes', minimo=0),
                       'descricao': lambda d: texto(d, 'descricao', max_len=1000),
                       'ativo': _ativo,
                   })

    # ======================= PATRIMÔNIO =======================
    SELECT_MOV = '''SELECT m.*, p.nome AS bem, p.tombo,
                           (SELECT nome FROM congregacoes c WHERE c.id = m.destino_congregacao_id) AS destino_nome,
                           (SELECT nome FROM usuarios u WHERE u.id = m.usuario_id) AS registrado_por
                    FROM patrimonio_mov m JOIN patrimonio p ON p.id = m.patrimonio_id'''

    @app.route('/api/patrimonio/movimentos', methods=['GET'])
    @requer_permissao('patrimonio.consultar')
    def movimentos_bens():
        params, where = [], ''
        if request.args.get('patrimonio_id'):
            where, params = ' WHERE m.patrimonio_id = ?', [request.args['patrimonio_id']]
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute(f'{SELECT_MOV}{where} ORDER BY m.data DESC, m.id DESC LIMIT 500', params))
            return jsonify({'movimentos': rows}), 200
        finally:
            conn.close()

    @app.route('/api/patrimonio/<int:pid>/movimentos', methods=['POST'])
    @requer_permissao('patrimonio.editar')
    def movimentar_bem(pid):
        d = request.get_json(silent=True) or {}
        try:
            tipo = opcao(d, 'tipo', TIPOS_MOV_BEM)
            if not tipo:
                raise ErroValidacao('Escolha o tipo de movimentação')
            reg = {'tipo': tipo, 'data': data_iso(d, 'data') or date.today().isoformat(),
                   'destino_congregacao_id': inteiro(d, 'destino_congregacao_id'),
                   'destino_local': texto(d, 'destino_local', max_len=150),
                   'responsavel': texto(d, 'responsavel', max_len=120), 'prestador': texto(d, 'prestador', max_len=150),
                   'valor': numero(d, 'valor', minimo=0) or 0, 'motivo': texto(d, 'motivo', max_len=1000)}
            if tipo == 'baixa' and not reg['motivo']:
                raise ErroValidacao('Informe o motivo da baixa (furto, perda, descarte, doação...)')
            if tipo == 'emprestimo' and not reg['responsavel']:
                raise ErroValidacao('Informe com quem o bem ficou')
        except ErroValidacao as e:
            return _erro(str(e))
        conn = get_db()
        try:
            bem = conn.execute('SELECT * FROM patrimonio WHERE id = ?', (pid,)).fetchone()
            if not bem:
                return _erro('Bem não encontrado', 404)
            if bem['status'] == 'descartado':
                return _erro('Este bem já foi baixado')
            origem = conn.execute('SELECT nome FROM congregacoes WHERE id = ?', (bem['congregacao_id'],)).fetchone() \
                if bem['congregacao_id'] else None
            reg['origem'] = f"{origem['nome'] if origem else 'Sede'} · {bem['local'] or '-'}"
            if tipo == 'transferencia':
                conn.execute('UPDATE patrimonio SET congregacao_id = ?, local = COALESCE(?, local), '
                             'responsavel = COALESCE(?, responsavel) WHERE id = ?',
                             (reg['destino_congregacao_id'], reg['destino_local'], reg['responsavel'], pid))
            else:
                novo = {'manutencao': 'manutencao', 'retorno': 'bom', 'emprestimo': 'emprestado', 'baixa': 'descartado'}[tipo]
                conn.execute('UPDATE patrimonio SET status = ? WHERE id = ?', (novo, pid))
            reg['patrimonio_id'], reg['usuario_id'] = pid, usuario_atual()['id']
            cols = list(reg)
            conn.execute(f'INSERT INTO patrimonio_mov ({", ".join(cols)}) VALUES ({", ".join("?" for _ in cols)})',
                         [reg[c] for c in cols])
            registrar('patrimonio', f'{tipo.capitalize()} do bem #{pid}', f"{bem['nome']} {reg['motivo'] or ''}".strip(), conn)
            conn.commit()
            return jsonify({'msg': 'Movimentação registrada'}), 201
        finally:
            conn.close()

    # ---- Inventário: lista todos os bens ativos para conferência física
    @app.route('/api/patrimonio/inventarios', methods=['GET'])
    @requer_permissao('patrimonio.consultar')
    def inventarios_listar():
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('''
                SELECT i.*, (SELECT COUNT(*) FROM inventario_itens x WHERE x.inventario_id = i.id) AS itens,
                       (SELECT COUNT(*) FROM inventario_itens x WHERE x.inventario_id = i.id AND x.situacao != 'pendente') AS conferidos,
                       (SELECT COUNT(*) FROM inventario_itens x WHERE x.inventario_id = i.id AND x.situacao = 'nao_encontrado') AS nao_encontrados
                FROM inventarios i ORDER BY i.id DESC'''))
            return jsonify({'inventarios': rows}), 200
        finally:
            conn.close()

    @app.route('/api/patrimonio/inventarios', methods=['POST'])
    @requer_permissao('patrimonio.criar')
    def inventario_criar():
        d = request.get_json(silent=True) or {}
        try:
            titulo = texto(d, 'titulo', max_len=150) or f'Inventário {date.today().year}'
            unidade = str(d.get('unidade') or 'todas')
            if unidade not in ('todas', 'sede') and not unidade.isdigit():
                raise ErroValidacao('Unidade inválida')
        except ErroValidacao as e:
            return _erro(str(e))
        filtro, params = '', []
        if unidade == 'sede':
            filtro = ' AND congregacao_id IS NULL'
        elif unidade != 'todas':
            filtro, params = ' AND congregacao_id = ?', [int(unidade)]
        conn = get_db()
        try:
            bens = [r[0] for r in conn.execute(f'''SELECT id FROM patrimonio WHERE status != 'descartado'
                       AND COALESCE(aprovacao, 'aprovado') = 'aprovado'{filtro}''', params)]
            if not bens:
                return _erro('Nenhum bem ativo para inventariar nessa unidade')
            cur = conn.execute('INSERT INTO inventarios (titulo, congregacao_id, criado_por, observacoes) VALUES (?, ?, ?, ?)',
                               (titulo, int(unidade) if unidade.isdigit() else (0 if unidade == 'sede' else None),
                                usuario_atual()['nome'], texto(d, 'observacoes', max_len=500)))
            conn.executemany('INSERT INTO inventario_itens (inventario_id, patrimonio_id) VALUES (?, ?)',
                             [(cur.lastrowid, b) for b in bens])
            registrar('patrimonio', f'Abriu inventário #{cur.lastrowid}', f'{titulo}: {len(bens)} bem(ns)', conn)
            conn.commit()
            return jsonify({'msg': f'Inventário aberto com {len(bens)} bem(ns) para conferir', 'id': cur.lastrowid}), 201
        finally:
            conn.close()

    @app.route('/api/patrimonio/inventarios/<int:iid>', methods=['GET'])
    @requer_permissao('patrimonio.consultar')
    def inventario_obter(iid):
        conn = get_db()
        try:
            inv = conn.execute('SELECT * FROM inventarios WHERE id = ?', (iid,)).fetchone()
            if not inv:
                return _erro('Inventário não encontrado', 404)
            itens = rows_to_dicts(conn.execute('''
                SELECT x.*, p.nome AS bem, p.tombo, p.local, p.categoria, p.valor, p.congregacao_id,
                       COALESCE((SELECT nome FROM congregacoes c WHERE c.id = p.congregacao_id), 'Sede') AS unidade
                FROM inventario_itens x JOIN patrimonio p ON p.id = x.patrimonio_id
                WHERE x.inventario_id = ? ORDER BY unidade, p.local, p.nome''', (iid,)))
            return jsonify({'inventario': dict(inv), 'itens': itens}), 200
        finally:
            conn.close()

    @app.route('/api/patrimonio/inventarios/<int:iid>/itens/<int:item>', methods=['PATCH'])
    @requer_permissao('patrimonio.editar')
    def inventario_conferir(iid, item):
        d = request.get_json(silent=True) or {}
        try:
            sit = opcao(d, 'situacao', SITUACOES_INVENTARIO)
            obs = texto(d, 'observacao', max_len=500)
        except ErroValidacao as e:
            return _erro(str(e))
        conn = get_db()
        try:
            inv = conn.execute('SELECT status FROM inventarios WHERE id = ?', (iid,)).fetchone()
            if not inv:
                return _erro('Inventário não encontrado', 404)
            if inv['status'] != 'aberto':
                return _erro('Inventário já concluído')
            cur = conn.execute('''UPDATE inventario_itens SET situacao = ?, observacao = ?, conferido_por = ?,
                                    conferido_em = CURRENT_TIMESTAMP WHERE id = ? AND inventario_id = ?''',
                               (sit, obs, usuario_atual()['nome'], item, iid))
            if not cur.rowcount:
                return _erro('Item não encontrado', 404)
            conn.commit()
            return jsonify({'msg': 'Conferido'}), 200
        finally:
            conn.close()

    @app.route('/api/patrimonio/inventarios/<int:iid>/concluir', methods=['POST'])
    @requer_permissao('patrimonio.editar')
    def inventario_concluir(iid):
        conn = get_db()
        try:
            pend = conn.execute("SELECT COUNT(*) FROM inventario_itens WHERE inventario_id = ? AND situacao = 'pendente'",
                                (iid,)).fetchone()[0]
            if pend:
                return _erro(f'Ainda há {pend} bem(ns) sem conferir')
            cur = conn.execute("UPDATE inventarios SET status = 'concluido', concluido_em = CURRENT_TIMESTAMP "
                               "WHERE id = ? AND status = 'aberto'", (iid,))
            if not cur.rowcount:
                return _erro('Inventário não encontrado ou já concluído', 404)
            registrar('patrimonio', f'Concluiu inventário #{iid}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Inventário concluído'}), 200
        finally:
            conn.close()

    @app.route('/api/patrimonio/inventarios/<int:iid>', methods=['DELETE'])
    @requer_permissao('patrimonio.deletar')
    def inventario_excluir(iid):
        conn = get_db()
        try:
            if not conn.execute("DELETE FROM inventarios WHERE id = ? AND status = 'aberto'", (iid,)).rowcount:
                return _erro('Só é possível excluir um inventário em aberto', 400)
            conn.execute('DELETE FROM inventario_itens WHERE inventario_id = ?', (iid,))
            registrar('patrimonio', f'Excluiu inventário #{iid}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Inventário excluído'}), 200
        finally:
            conn.close()


def contagens_pendencias(conn, pode):
    """Itens do painel de pendências (chamado por /api/pendencias). `pode(perm)` -> bool."""
    out = {}
    hoje = date.today()
    if pode('tesouraria.consultar'):
        out['contas_vencidas'] = conn.execute('''SELECT COUNT(*) FROM financeiro WHERE tipo = 'despesa' AND status = 'pendente'
            AND COALESCE(aprovacao, 'aprovado') = 'aprovado' AND COALESCE(vencimento, data) < ?''', (hoje.isoformat(),)).fetchone()[0]
        out['contas_vencendo'] = conn.execute('''SELECT COUNT(*) FROM financeiro WHERE tipo = 'despesa' AND status = 'pendente'
            AND COALESCE(aprovacao, 'aprovado') = 'aprovado' AND COALESCE(vencimento, data) BETWEEN ? AND ?''',
            (hoje.isoformat(), (hoje + timedelta(days=7)).isoformat())).fetchone()[0]
        mes_passado = (hoje.replace(day=1) - timedelta(days=1)).strftime('%Y-%m')
        tem_lanc = conn.execute('SELECT 1 FROM financeiro WHERE substr(data, 1, 7) = ? LIMIT 1', (mes_passado,)).fetchone()
        fechado = conn.execute('SELECT 1 FROM periodos_fechados WHERE competencia = ?', (mes_passado,)).fetchone()
        if pode('tesouraria.aprovar') and tem_lanc and not fechado:
            out['mes_a_fechar'] = mes_passado
    if pode('secretaria.consultar'):
        out['visitantes_sem_contato'] = conn.execute(
            "SELECT COUNT(*) FROM visitantes WHERE situacao = 'novo'").fetchone()[0]
    if pode('patrimonio.consultar'):
        out['inventarios_abertos'] = conn.execute("SELECT COUNT(*) FROM inventarios WHERE status = 'aberto'").fetchone()[0]
        out['bens_emprestados'] = conn.execute("SELECT COUNT(*) FROM patrimonio WHERE status = 'emprestado'").fetchone()[0]
    return out
