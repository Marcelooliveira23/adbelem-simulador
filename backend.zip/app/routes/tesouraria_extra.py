"""Tesouraria: caixa diário com dupla conferência, campanhas (fundos com meta), conciliação bancária.
Membros: foto (usada na carteirinha)."""
from datetime import date, timedelta

from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao, usuario_atual, escopo_congregacao
from app.crud import registrar_crud
from app.database import get_db, rows_to_dicts
from app.validacao import ErroValidacao, texto, numero, data_iso, inteiro, opcao, brl

OK = "COALESCE(aprovacao, 'aprovado') = 'aprovado'"


def _erro(msg, codigo=400):
    return jsonify({'erro': str(msg)}), codigo


def saldo_campanha(conn, campanha_id):
    """Arrecadado (receitas aprovadas) menos gasto (despesas aprovadas) do fundo."""
    r = conn.execute(f'''SELECT COALESCE(SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END), 0) AS arrecadado,
                                COALESCE(SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END), 0) AS gasto
                         FROM financeiro WHERE campanha_id = ? AND {OK}''', (campanha_id,)).fetchone()
    return round(r['arrecadado'], 2), round(r['gasto'], 2)


def registrar_tesouraria_extra(app):
    # =====================================================================
    # Caixa diário (por culto), conferido por duas pessoas
    # =====================================================================
    def _ler_caixa(d):
        c = {
            'data': data_iso(d, 'data', True),
            'culto': texto(d, 'culto', True, 120),
            'congregacao_id': inteiro(d, 'congregacao_id'),
            'dizimos': numero(d, 'dizimos', minimo=0),
            'ofertas': numero(d, 'ofertas', minimo=0),
            'alcadas': numero(d, 'alcadas', minimo=0),
            'outras': numero(d, 'outras', minimo=0),
            'pix': numero(d, 'pix', minimo=0),
            'observacoes': texto(d, 'observacoes', max_len=1000),
        }
        if c['pix'] > c['dizimos'] + c['ofertas'] + c['alcadas'] + c['outras']:
            raise ErroValidacao('O valor recebido por PIX não pode ser maior que o total do culto')
        return c

    def _caixa_do_usuario(conn, id):
        params = [id]
        where = ''
        cong = escopo_congregacao()
        if cong is not None:
            where = ' AND congregacao_id = ?'
            params.append(cong)
        return conn.execute(f'SELECT * FROM caixa_dias WHERE id = ?{where}', params).fetchone()

    @app.route('/api/tesouraria/caixa', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def listar_caixa():
        params, where = [], ''
        cong = escopo_congregacao()
        if cong is not None:
            where, params = ' WHERE c.congregacao_id = ?', [cong]
        conn = get_db()
        try:
            rows = conn.execute(f'''SELECT c.*, (SELECT nome FROM congregacoes g WHERE g.id = c.congregacao_id) AS congregacao_nome
                                    FROM caixa_dias c{where} ORDER BY c.data DESC, c.id DESC LIMIT 400''', params).fetchall()
            return jsonify({'caixa': rows_to_dicts(rows)}), 200
        finally:
            conn.close()

    @app.route('/api/tesouraria/caixa', methods=['POST'])
    @requer_permissao('tesouraria.criar')
    def criar_caixa():
        try:
            c = _ler_caixa(request.get_json(silent=True) or {})
        except ErroValidacao as e:
            return _erro(e)
        cong = escopo_congregacao()
        if cong is not None:
            c['congregacao_id'] = cong
        c['criado_por'] = usuario_atual()['nome']
        conn = get_db()
        try:
            cols = list(c)
            cur = conn.execute(f'INSERT INTO caixa_dias ({", ".join(cols)}) VALUES ({", ".join("?" for _ in cols)})',
                               [c[k] for k in cols])
            registrar('tesouraria', f'Abriu caixa do culto #{cur.lastrowid}', f"{c['culto']} {c['data']}", conn)
            conn.commit()
            return jsonify({'msg': 'Caixa registrado. Falta a conferência por duas pessoas.', 'id': cur.lastrowid}), 201
        finally:
            conn.close()

    @app.route('/api/tesouraria/caixa/<int:id>', methods=['PUT'])
    @requer_permissao('tesouraria.criar')
    def editar_caixa(id):
        try:
            c = _ler_caixa(request.get_json(silent=True) or {})
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            atual = _caixa_do_usuario(conn, id)
            if not atual:
                return _erro('Caixa não encontrado', 404)
            if atual['status'] != 'aberto':
                return _erro('Caixa já conferido não pode ser alterado', 409)
            if escopo_congregacao() is not None:
                c['congregacao_id'] = atual['congregacao_id']
            conn.execute(f'UPDATE caixa_dias SET {", ".join(f"{k} = ?" for k in c)} WHERE id = ?', list(c.values()) + [id])
            registrar('tesouraria', f'Editou caixa #{id}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Caixa atualizado'}), 200
        finally:
            conn.close()

    @app.route('/api/tesouraria/caixa/<int:id>', methods=['DELETE'])
    @requer_permissao('tesouraria.criar')
    def excluir_caixa(id):
        conn = get_db()
        try:
            atual = _caixa_do_usuario(conn, id)
            if not atual:
                return _erro('Caixa não encontrado', 404)
            if atual['status'] != 'aberto':
                return _erro('Caixa conferido não pode ser excluído (os lançamentos já foram gerados)', 409)
            conn.execute('DELETE FROM caixa_dias WHERE id = ?', (id,))
            registrar('tesouraria', f'Excluiu caixa #{id}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Caixa excluído'}), 200
        finally:
            conn.close()

    @app.route('/api/tesouraria/caixa/<int:id>/conferir', methods=['POST'])
    @requer_permissao('tesouraria.criar')
    def conferir_caixa(id):
        """Duas pessoas diferentes conferem; o sistema gera os lançamentos de receita do culto."""
        d = request.get_json(silent=True) or {}
        try:
            c1 = texto(d, 'conferente1', True, 100)
            c2 = texto(d, 'conferente2', True, 100)
        except ErroValidacao as e:
            return _erro(e)
        if c1.strip().lower() == c2.strip().lower():
            return _erro('A conferência precisa de duas pessoas diferentes')
        conn = get_db()
        try:
            cx = _caixa_do_usuario(conn, id)
            if not cx:
                return _erro('Caixa não encontrado', 404)
            if cx['status'] != 'aberto':
                return _erro('Este caixa já foi conferido', 409)
            total = cx['dizimos'] + cx['ofertas'] + (cx['alcadas'] or 0) + cx['outras']
            if total <= 0:
                return _erro('Informe ao menos um valor antes de conferir')
            aprovacao = 'pendente' if escopo_congregacao() is not None else 'aprovado'
            uid = usuario_atual()['id']
            pix_txt = f" (PIX: {brl(cx['pix'])})" if cx['pix'] else ''
            for categoria, valor, rotulo in (('dizimo', cx['dizimos'], 'Dízimos'), ('oferta', cx['ofertas'], 'Ofertas'),
                                             ('oferta_alcada', cx['alcadas'] or 0, 'Ofertas alçadas'),
                                             ('outro', cx['outras'], 'Outras contribuições')):
                if valor > 0:
                    conn.execute('''INSERT INTO financeiro (tipo, descricao, valor, data, categoria, status, forma,
                                    congregacao_id, usuario_id, aprovacao, caixa_id)
                                    VALUES ('receita', ?, ?, ?, ?, 'confirmada', 'dinheiro', ?, ?, ?, ?)''',
                                 (f"{rotulo} · {cx['culto']}{pix_txt}", round(valor, 2), cx['data'], categoria,
                                  cx['congregacao_id'], uid, aprovacao, id))
            conn.execute("UPDATE caixa_dias SET status = 'conferido', conferente1 = ?, conferente2 = ?, "
                         "conferido_em = datetime('now') WHERE id = ?", (c1, c2, id))
            registrar('tesouraria', f'Conferiu caixa #{id}', f'{c1} e {c2} · {brl(total)}', conn)
            conn.commit()
            extra = ' Os lançamentos aguardam o "de acordo" da sede.' if aprovacao == 'pendente' else ''
            return jsonify({'msg': f'Caixa conferido por {c1} e {c2}. Lançamentos gerados na Tesouraria.{extra}'}), 200
        finally:
            conn.close()

    # =====================================================================
    # Campanhas: fundos com meta (o dado para uma finalidade só é gasto nela)
    # =====================================================================
    registrar_crud(app, rota='tesouraria/campanhas', tabela='campanhas', modulo='tesouraria', chave_lista='campanhas',
                   rotulo='campanha', ordem='t.ativo DESC, t.fim IS NULL, t.fim', campos={
                       'nome': lambda d: texto(d, 'nome', True, 120),
                       'tipo': lambda d: opcao(d, 'tipo', ('construcao', 'missoes', 'acao_social', 'especial', 'outro'), 'especial'),
                       'meta': lambda d: numero(d, 'meta', minimo=0),
                       'inicio': lambda d: data_iso(d, 'inicio'),
                       'fim': lambda d: data_iso(d, 'fim'),
                       'restrito': lambda d: 0 if str(d.get('restrito', '1')) in ('0', 'false') else 1,
                       'ativo': lambda d: 0 if str(d.get('ativo', '1')) in ('0', 'false') else 1,
                       'descricao': lambda d: texto(d, 'descricao', max_len=1000),
                   })

    @app.route('/api/tesouraria/campanhas/resumo', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def resumo_campanhas():
        conn = get_db()
        try:
            camps = rows_to_dicts(conn.execute('SELECT * FROM campanhas ORDER BY ativo DESC, nome'))
            for c in camps:
                c['arrecadado'], c['gasto'] = saldo_campanha(conn, c['id'])
                c['saldo'] = round(c['arrecadado'] - c['gasto'], 2)
                c['percentual'] = round(100 * c['arrecadado'] / c['meta']) if c['meta'] else None
            return jsonify({'campanhas': camps}), 200
        finally:
            conn.close()

    # =====================================================================
    # Conciliação bancária: importar extrato e vincular aos lançamentos
    # =====================================================================
    @app.route('/api/tesouraria/extrato/importar', methods=['POST'])
    @requer_permissao('tesouraria.editar')
    def importar_extrato():
        linhas = (request.get_json(silent=True) or {}).get('linhas') or []
        if not isinstance(linhas, list) or not linhas:
            return _erro('Nenhuma linha recebida')
        novas, repetidas, erros = 0, 0, []
        conn = get_db()
        try:
            for i, ln in enumerate(linhas[:2000], start=1):
                try:
                    dia = data_iso(ln, 'data', True)
                    valor = numero(ln, 'valor', obrigatorio=True)
                    if valor == 0:
                        raise ErroValidacao('valor zero')
                    desc = texto(ln, 'descricao', max_len=250)
                except ErroValidacao as e:
                    erros.append(f'linha {i}: {e}')
                    continue
                cur = conn.execute('INSERT OR IGNORE INTO extrato (data, descricao, valor) VALUES (?,?,?)', (dia, desc, valor))
                if cur.rowcount:
                    novas += 1
                else:
                    repetidas += 1
            registrar('tesouraria', 'Importou extrato bancário', f'{novas} novas, {repetidas} repetidas', conn)
            conn.commit()
        finally:
            conn.close()
        return jsonify({'msg': f'{novas} movimento(s) importado(s); {repetidas} já existiam.', 'novas': novas,
                        'repetidas': repetidas, 'erros': erros[:20]}), 200

    @app.route('/api/tesouraria/extrato', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def listar_extrato():
        conn = get_db()
        try:
            movs = rows_to_dicts(conn.execute('''SELECT e.*, f.descricao AS lancamento_descricao, f.data AS lancamento_data
                                                 FROM extrato e LEFT JOIN financeiro f ON f.id = e.financeiro_id
                                                 ORDER BY e.status = 'pendente' DESC, e.data DESC LIMIT 1000'''))
            vinculados = {m['financeiro_id'] for m in movs if m['financeiro_id']}
            for m in movs:
                m['sugestoes'] = []
                if m['status'] != 'pendente':
                    continue
                tipo = 'receita' if m['valor'] > 0 else 'despesa'
                d0 = date.fromisoformat(m['data'])
                cands = conn.execute(f'''SELECT id, data, descricao, valor FROM financeiro
                                         WHERE tipo = ? AND ABS(valor - ?) < 0.005 AND data BETWEEN ? AND ? AND {OK}
                                         ORDER BY ABS(julianday(data) - julianday(?)) LIMIT 5''',
                                      (tipo, abs(m['valor']), (d0 - timedelta(days=5)).isoformat(),
                                       (d0 + timedelta(days=5)).isoformat(), m['data'])).fetchall()
                m['sugestoes'] = [dict(c) for c in cands if c['id'] not in vinculados]
            resumo = {
                'pendentes': sum(1 for m in movs if m['status'] == 'pendente'),
                'conciliados': sum(1 for m in movs if m['status'] == 'conciliado'),
                'saldo_extrato': round(sum(m['valor'] for m in movs if m['status'] != 'ignorado'), 2),
            }
            return jsonify({'extrato': movs, 'resumo': resumo}), 200
        finally:
            conn.close()

    @app.route('/api/tesouraria/extrato/<int:id>', methods=['PATCH'])
    @requer_permissao('tesouraria.editar')
    def conciliar(id):
        d = request.get_json(silent=True) or {}
        acao = d.get('acao')
        conn = get_db()
        try:
            mov = conn.execute('SELECT * FROM extrato WHERE id = ?', (id,)).fetchone()
            if not mov:
                return _erro('Movimento não encontrado', 404)
            if acao == 'vincular':
                fid = inteiro(d, 'financeiro_id', obrigatorio=True)
                if not conn.execute('SELECT 1 FROM financeiro WHERE id = ?', (fid,)).fetchone():
                    return _erro('Lançamento não encontrado', 404)
                conn.execute("UPDATE extrato SET financeiro_id = ?, status = 'conciliado' WHERE id = ?", (fid, id))
                msg = 'Movimento conciliado'
            elif acao == 'criar':
                tipo = 'receita' if mov['valor'] > 0 else 'despesa'
                cats = ('dizimo', 'oferta', 'oferta_alcada', 'campanha', 'evento', 'outro') if tipo == 'receita' else \
                    ('manutencao', 'salario', 'agua_luz', 'aluguel', 'material_ebd', 'material', 'acao_social', 'missoes', 'evento', 'outro')
                categoria = opcao(d, 'categoria', cats, 'outro')
                cur = conn.execute('''INSERT INTO financeiro (tipo, descricao, valor, data, categoria, status, forma,
                                      usuario_id, aprovacao) VALUES (?, ?, ?, ?, ?, ?, 'transferencia', ?, 'aprovado')''',
                                   (tipo, texto(d, 'descricao', max_len=250) or mov['descricao'] or 'Movimento bancário',
                                    abs(mov['valor']), mov['data'], categoria,
                                    'confirmada' if tipo == 'receita' else 'pago', usuario_atual()['id']))
                conn.execute("UPDATE extrato SET financeiro_id = ?, status = 'conciliado' WHERE id = ?", (cur.lastrowid, id))
                msg = 'Lançamento criado e conciliado'
            elif acao == 'ignorar':
                conn.execute("UPDATE extrato SET status = 'ignorado' WHERE id = ?", (id,))
                msg = 'Movimento ignorado'
            elif acao == 'desfazer':
                conn.execute("UPDATE extrato SET status = 'pendente', financeiro_id = NULL WHERE id = ?", (id,))
                msg = 'Conciliação desfeita'
            else:
                return _erro('Ação inválida. Use: vincular, criar, ignorar ou desfazer')
            registrar('tesouraria', f'Extrato #{id}: {msg}', '', conn)
            conn.commit()
            return jsonify({'msg': msg}), 200
        except ErroValidacao as e:
            return _erro(e)
        finally:
            conn.close()

    # =====================================================================
    # Foto do membro (carteirinha)
    # =====================================================================
    @app.route('/api/membros/<int:id>/foto', methods=['GET'])
    @requer_permissao('membros.consultar')
    def obter_foto(id):
        conn = get_db()
        try:
            row = conn.execute('SELECT foto FROM membros_fotos WHERE membro_id = ?', (id,)).fetchone()
            return jsonify({'foto': row['foto'] if row else None}), 200
        finally:
            conn.close()

    @app.route('/api/membros/<int:id>/foto', methods=['PUT'])
    @requer_permissao('membros.criar')
    def salvar_foto(id):
        foto = (request.get_json(silent=True) or {}).get('foto') or ''
        if not foto.startswith(('data:image/jpeg;base64,', 'data:image/png;base64,', 'data:image/webp;base64,')):
            return _erro('Envie uma imagem JPG, PNG ou WEBP')
        if len(foto) > 400_000:
            return _erro('Imagem muito grande (máximo de cerca de 300 KB)')
        conn = get_db()
        try:
            params = [id]
            where = ''
            cong = escopo_congregacao()
            if cong is not None:
                where, params = ' AND congregacao_id = ?', [id, cong]
            if not conn.execute(f'SELECT 1 FROM membros WHERE id = ?{where}', params).fetchone():
                return _erro('Membro não encontrado', 404)
            conn.execute('INSERT OR REPLACE INTO membros_fotos (membro_id, foto) VALUES (?, ?)', (id, foto))
            registrar('membros', f'Atualizou foto do membro #{id}', '', conn)
            conn.commit()
            return jsonify({'msg': 'Foto salva'}), 200
        finally:
            conn.close()
