"""Financeiro > Banco do Brasil: contas, PIX/depósitos recebidos, simulador, webhook e sincronização.

Todo movimento recebido (simulado, por webhook ou pela consulta periódica) passa por
`registrar_movimento`, que:
  1. ignora repetidos (o identificador do banco é único: endToEndId do PIX);
  2. classifica: mensagem do pagador ("dízimo", "oferta", "missões"...) ou a categoria padrão da conta;
  3. identifica o dizimista quando o nome do pagador coincide com um membro cadastrado;
  4. lança a RECEITA do dia na Tesouraria (forma PIX/transferência), já aprovada e conciliada.
"""
import secrets
import threading
import unicodedata
from datetime import datetime, timedelta, timezone

from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao
from app.crud import registrar_crud
from app.database import get_db, rows_to_dicts, obter_config
from app.integracoes.banco_brasil import ClientePixBB, ErroBanco, normalizar_pix, mascarar_documento
from app.validacao import ErroValidacao, texto, numero, inteiro, opcao, brl

CATEGORIAS = ('dizimo', 'oferta', 'oferta_alcada', 'campanha', 'evento', 'outro')
MODOS = ('simulacao', 'homologacao', 'producao')
CHAVES_CONFIG = ('bb_modo', 'bb_client_id', 'bb_client_secret', 'bb_chave_app', 'bb_oauth_url', 'bb_api_url',
                 'bb_param_chave_app', 'bb_cert_path', 'bb_key_path', 'bb_intervalo_min')
SECRETAS = ('bb_client_secret',)
_trava_sinc = threading.Lock()


def _sem_acento(t):
    return ''.join(c for c in unicodedata.normalize('NFD', t or '') if unicodedata.category(c) != 'Mn').lower()


def palavra_chave(mensagem):
    """Categoria indicada pela mensagem do PIX, ou None se ela não diz nada."""
    m = _sem_acento(mensagem)
    if 'dizimo' in m:
        return 'dizimo'
    if 'alcada' in m:
        return 'oferta_alcada'
    if 'oferta' in m:
        return 'oferta'
    if any(p in m for p in ('missao', 'missoes', 'campanha', 'reforma', 'construcao')):
        return 'campanha'
    return None


def classificar(mensagem, padrao):
    return palavra_chave(mensagem) or (padrao if padrao in CATEGORIAS else 'oferta_alcada')


def registrar_movimento(conn, conta, mov, origem):
    """Registra um movimento bancário e lança a receita. Retorna o id do movimento ou None se já existia."""
    if conn.execute('SELECT 1 FROM banco_movimentos WHERE identificador = ?', (mov['identificador'],)).fetchone():
        return None
    categoria = classificar(mov.get('mensagem'), conta['categoria_padrao'])
    membro = None
    if mov.get('pagador_nome'):
        membro = conn.execute("SELECT id FROM membros WHERE lower(nome) = lower(?) AND COALESCE(aprovacao,'aprovado')='aprovado'",
                              (mov['pagador_nome'],)).fetchone()
    horario = mov.get('horario') or datetime.now(timezone.utc).isoformat()
    dia = horario[:10]
    rotulo = 'PIX' if mov['tipo'] == 'pix' else 'Depósito'
    quem = f" de {mov['pagador_nome']}" if mov.get('pagador_nome') else ''
    # Sem pagador reconhecido e sem mensagem que classifique: entra na categoria padrão da conta,
    # mas fica marcado "a classificar" para a Tesouraria revisar
    reconhecido = bool(membro) or palavra_chave(mov.get('mensagem')) is not None
    descricao = f"{rotulo}{quem} · {conta['apelido']}" + (f" · \"{mov['mensagem'][:60]}\"" if mov.get('mensagem') else '')
    cur = conn.execute('''INSERT INTO financeiro (tipo, descricao, valor, data, categoria, status, forma, congregacao_id,
                          membro_id, campanha_id, aprovacao) VALUES ('receita', ?, ?, ?, ?, 'confirmada', ?, ?, ?, ?, 'aprovado')''',
                       (descricao, mov['valor'], dia, categoria, 'pix' if mov['tipo'] == 'pix' else 'transferencia',
                        conta['congregacao_id'], membro['id'] if membro else None,
                        conta['campanha_id'] if categoria == 'campanha' else None))
    fin_id = cur.lastrowid
    # Movimento vindo do banco já nasce conciliado
    conn.execute("INSERT OR IGNORE INTO extrato (data, descricao, valor, financeiro_id, status) VALUES (?, ?, ?, ?, 'conciliado')",
                 (dia, f"{rotulo} {mov['identificador'][-12:]}", mov['valor'], fin_id))
    cur = conn.execute('''INSERT INTO banco_movimentos (conta_id, origem, tipo, identificador, txid, valor, horario, pagador_nome,
                          pagador_documento, mensagem, categoria, membro_id, financeiro_id, classificado)
                          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                       (conta['id'], origem, mov['tipo'], mov['identificador'], mov.get('txid'), mov['valor'], horario,
                        mov.get('pagador_nome'), mov.get('pagador_documento'), mov.get('mensagem'), categoria,
                        membro['id'] if membro else None, fin_id, 1 if reconhecido else 0))
    return cur.lastrowid


def processar_payload_pix(conn, conta, payload, origem):
    """Payload no padrão do webhook Pix do BACEN: {"pix": [ {endToEndId, valor, horario, pagador, infoPagador}, ... ]}."""
    novos = 0
    for item in (payload or {}).get('pix', []):
        if registrar_movimento(conn, conta, normalizar_pix(item), origem):
            novos += 1
    return novos


def _cliente():
    cfg = {k: obter_config(k) for k in CHAVES_CONFIG}
    modo = cfg['bb_modo'] or 'simulacao'
    if modo == 'simulacao':
        return None, modo
    faltando = [k for k in ('bb_client_id', 'bb_client_secret', 'bb_chave_app') if not cfg[k]]
    if faltando:
        raise ErroBanco('Configuração incompleta: ' + ', '.join(faltando))
    return ClientePixBB(modo, cfg['bb_client_id'], cfg['bb_client_secret'], cfg['bb_chave_app'],
                        cfg['bb_oauth_url'] or None, cfg['bb_api_url'] or None, cfg['bb_param_chave_app'] or None,
                        cfg['bb_cert_path'] or None, cfg['bb_key_path'] or None), modo


def sincronizar_bb(horas=24):
    """Consulta o BB e registra os PIX novos das contas ativas. Usado pelo botão e pela rotina automática."""
    if not _trava_sinc.acquire(blocking=False):
        return {'msg': 'Sincronização já em andamento', 'novos': 0}
    try:
        cliente, modo = _cliente()
        if cliente is None:
            return {'msg': 'Modo simulação: não há banco real configurado. Use "Simular PIX".', 'novos': 0}
        fim = datetime.now(timezone.utc)
        inicio = fim - timedelta(hours=horas)
        itens = cliente.pix_recebidos(inicio, fim)
        conn = get_db()
        try:
            contas = {(c['chave_pix'] or '').strip(): c for c in conn.execute('SELECT * FROM contas_bancarias WHERE ativo = 1')}
            novos = 0
            for it in itens:
                conta = contas.get((it.get('chave') or '').strip()) or (next(iter(contas.values())) if len(contas) == 1 else None)
                if conta and registrar_movimento(conn, conta, normalizar_pix(it), 'api'):
                    novos += 1
            conn.execute("UPDATE contas_bancarias SET ultima_sincronizacao = datetime('now') WHERE ativo = 1")
            registrar('tesouraria', f'Sincronizou com o BB ({modo})', f'{novos} novo(s) de {len(itens)}', conn)
            conn.commit()
        finally:
            conn.close()
        return {'msg': f'{novos} PIX novo(s) registrado(s) ({len(itens)} consultado(s)).', 'novos': novos}
    finally:
        _trava_sinc.release()


def iniciar_rotina_automatica(parar_evento):
    """Thread que sincroniza a cada N minutos (bb_intervalo_min) quando o modo não é simulação."""
    def laco():
        while not parar_evento.is_set():
            minutos = int(obter_config('bb_intervalo_min') or 5)
            if (obter_config('bb_modo') or 'simulacao') != 'simulacao':
                try:
                    sincronizar_bb(horas=6)
                except Exception as e:   # noqa: BLE001 - registra e tenta de novo no próximo ciclo
                    print(f'[banco] falha na sincronização: {e}')
            parar_evento.wait(max(1, minutos) * 60)
    t = threading.Thread(target=laco, name='sincronizacao-bb', daemon=True)
    t.start()
    return t


def registrar_banco(app):
    registrar_crud(app, rota='banco/contas', tabela='contas_bancarias', modulo='tesouraria', chave_lista='contas',
                   rotulo='conta bancária', ordem='t.apelido', campos={
                       'apelido': lambda d: texto(d, 'apelido', True, 60),
                       'banco': lambda d: texto(d, 'banco', max_len=3) or '001',
                       'agencia': lambda d: texto(d, 'agencia', max_len=10),
                       'conta': lambda d: texto(d, 'conta', max_len=20),
                       'chave_pix': lambda d: texto(d, 'chave_pix', max_len=100),
                       'categoria_padrao': lambda d: opcao(d, 'categoria_padrao', CATEGORIAS, 'oferta'),
                       'campanha_id': lambda d: inteiro(d, 'campanha_id'),
                       'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
                       'ativo': lambda d: 0 if str(d.get('ativo', '1')) in ('0', 'false') else 1,
                   }, depois_salvar=lambda conn, id, dados: conn.execute(
                       'UPDATE contas_bancarias SET token_webhook = COALESCE(token_webhook, ?) WHERE id = ?',
                       (secrets.token_urlsafe(24), id)))

    @app.route('/api/banco/movimentos', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def movimentos_banco():
        dias = min(int(request.args.get('dias') or 30), 400)
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('''
                SELECT m.*, c.apelido AS conta_apelido, (SELECT nome FROM membros x WHERE x.id = m.membro_id) AS membro_nome
                FROM banco_movimentos m JOIN contas_bancarias c ON c.id = m.conta_id
                WHERE date(m.horario) >= date('now', ?) ORDER BY m.horario DESC, m.id DESC''', (f'-{dias} days',)))
            hoje = datetime.now().date().isoformat()
            do_dia = [r for r in rows if (r['horario'] or '')[:10] == hoje]
            return jsonify({'movimentos': rows, 'hoje': {
                'quantidade': len(do_dia), 'total': round(sum(r['valor'] for r in do_dia), 2),
                'por_conta': {a: round(sum(r['valor'] for r in do_dia if r['conta_apelido'] == a), 2)
                              for a in {r['conta_apelido'] for r in do_dia}}}}), 200
        finally:
            conn.close()

    @app.route('/api/banco/status', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def status_banco():
        cfg = {k: obter_config(k) for k in CHAVES_CONFIG}
        for k in SECRETAS:
            cfg[k] = '••••••••' if cfg[k] else ''
        cfg['bb_modo'] = cfg['bb_modo'] or 'simulacao'
        conn = get_db()
        try:
            ult = conn.execute('SELECT MAX(ultima_sincronizacao) FROM contas_bancarias').fetchone()[0]
        finally:
            conn.close()
        return jsonify({'config': cfg, 'ultima_sincronizacao': ult}), 200

    @app.route('/api/banco/config', methods=['PUT'])
    @requer_permissao('tesouraria.banco')
    def salvar_config_banco():
        d = request.get_json(silent=True) or {}
        try:
            opcao(d, 'bb_modo', MODOS, 'simulacao')
            if d.get('bb_intervalo_min') not in (None, ''):
                inteiro(d, 'bb_intervalo_min', minimo=1)
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        conn = get_db()
        try:
            for k in CHAVES_CONFIG:
                if k not in d or (k in SECRETAS and d[k] in ('', '••••••••')):
                    continue   # segredo em branco = mantém o atual
                conn.execute('INSERT OR REPLACE INTO configuracoes (chave, valor) VALUES (?, ?)', (k, str(d[k]).strip()))
            registrar('tesouraria', 'Alterou a configuração do Banco do Brasil', f"modo: {d.get('bb_modo')}", conn)
            conn.commit()
        finally:
            conn.close()
        return jsonify({'msg': 'Configuração salva'}), 200

    @app.route('/api/banco/simular', methods=['POST'])
    @requer_permissao('tesouraria.banco')
    def simular_movimento():
        """API de teste: gera um PIX ou depósito no padrão do banco e processa pelo mesmo caminho dos reais."""
        d = request.get_json(silent=True) or {}
        try:
            conta_id = inteiro(d, 'conta_id', obrigatorio=True)
            tipo = opcao(d, 'tipo', ('pix', 'deposito'), 'pix')
            valor = numero(d, 'valor', obrigatorio=True, positivo=True)
            nome = texto(d, 'pagador_nome', max_len=120)
            msg = texto(d, 'mensagem', max_len=140)
        except ErroValidacao as e:
            return jsonify({'erro': str(e)}), 400
        conn = get_db()
        try:
            conta = conn.execute('SELECT * FROM contas_bancarias WHERE id = ? AND ativo = 1', (conta_id,)).fetchone()
            if not conta:
                return jsonify({'erro': 'Conta não encontrada ou inativa'}), 404
            agora = datetime.now().astimezone().isoformat(timespec='seconds')
            if tipo == 'pix':
                payload = {'pix': [{'endToEndId': 'E00000000' + datetime.now().strftime('%Y%m%d%H%M%S') + secrets.token_hex(4).upper(),
                                    'txid': None, 'valor': f'{valor:.2f}', 'chave': conta['chave_pix'], 'horario': agora,
                                    'pagador': {'nome': nome, 'cpf': d.get('pagador_cpf') or ''}, 'infoPagador': msg}]}
                novos = processar_payload_pix(conn, conta, payload, 'simulacao')
            else:
                mov = {'tipo': 'deposito', 'identificador': 'DEP' + secrets.token_hex(8).upper(), 'valor': valor,
                       'horario': agora, 'pagador_nome': nome, 'pagador_documento': mascarar_documento(d.get('pagador_cpf')),
                       'mensagem': msg}
                novos = 1 if registrar_movimento(conn, conta, mov, 'simulacao') else 0
            registrar('tesouraria', f'Simulou {tipo} na {conta["apelido"]}', brl(valor), conn)
            conn.commit()
            return jsonify({'msg': f'{"PIX" if tipo == "pix" else "Depósito"} simulado de {brl(valor)} registrado como entrada do dia.',
                            'novos': novos}), 201
        finally:
            conn.close()

    @app.route('/api/banco/webhook/<token>', methods=['POST'])
    def webhook_pix(token):
        """Recebe avisos de PIX (padrão BACEN). O token secreto na URL identifica a conta.
        Em produção, o BB exige HTTPS com certificado (mTLS) neste endereço."""
        conn = get_db()
        try:
            conta = conn.execute('SELECT * FROM contas_bancarias WHERE token_webhook = ? AND ativo = 1', (token,)).fetchone()
            if not conta:
                return jsonify({'erro': 'Não autorizado'}), 401
            try:
                payload = request.get_json(force=True, silent=False)
            except Exception:  # noqa: BLE001
                return jsonify({'erro': 'JSON inválido'}), 400
            try:
                novos = processar_payload_pix(conn, conta, payload, 'webhook')
            except (KeyError, ValueError, TypeError) as e:
                return jsonify({'erro': f'Formato inesperado: {e}'}), 400
            registrar('tesouraria', f'Webhook PIX na {conta["apelido"]}', f'{novos} novo(s)', conn)
            conn.commit()
            return jsonify({'recebidos': novos}), 200
        finally:
            conn.close()

    @app.route('/api/banco/sincronizar', methods=['POST'])
    @requer_permissao('tesouraria.banco')
    def sincronizar():
        try:
            return jsonify(sincronizar_bb()), 200
        except ErroBanco as e:
            return jsonify({'erro': str(e)}), 502

