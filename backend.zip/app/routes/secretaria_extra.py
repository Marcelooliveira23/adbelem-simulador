"""Secretaria: modelos de cartas editáveis, arquivo digital (scanners e fotos) e central de alertas."""
import os
import secrets
from datetime import date, timedelta

from flask import request, jsonify, send_file
from flask_jwt_extended import jwt_required

from app.auditoria import registrar
from app.auth_utils import requer_permissao, usuario_atual
from app.config import DATA_DIR
from app.database import get_db, rows_to_dicts
from app.models import Permissao
from app.validacao import ErroValidacao, texto, data_iso, inteiro, opcao

PASTA_ARQUIVOS = os.path.join(DATA_DIR, 'arquivos')
os.makedirs(PASTA_ARQUIVOS, exist_ok=True)
EXTENSOES = {'pdf', 'jpg', 'jpeg', 'png', 'webp', 'gif', 'heic', 'doc', 'docx', 'xls', 'xlsx', 'odt', 'txt'}
TAMANHO_MAX = 15 * 1024 * 1024
CATEGORIAS_ARQ = ('ata', 'estatuto', 'contrato', 'escritura', 'certidao', 'alvara', 'avcb', 'seguro', 'nota_fiscal',
                  'documento_membro', 'carta_recebida', 'oficio', 'outro')
TIPOS_MODELO = ('Carta de recomendação', 'Carta de mudança', 'Carta de transferência', 'Carta de visita',
                'Declaração de membro', 'Carta de doação')


def _erro(msg, codigo=400):
    return jsonify({'erro': str(msg)}), codigo


def registrar_secretaria_extra(app):
    app.config['MAX_CONTENT_LENGTH'] = TAMANHO_MAX + 1024 * 1024

    # ---------------- Modelos de cartas (a Secretaria revisa os textos) ----------------
    @app.route('/api/documentos/modelos', methods=['GET'])
    @requer_permissao('secretaria.consultar')
    def listar_modelos():
        conn = get_db()
        try:
            rows = conn.execute('SELECT * FROM modelos_documento').fetchall()
            return jsonify({'modelos': {r['tipo']: dict(r) for r in rows}, 'tipos': TIPOS_MODELO}), 200
        finally:
            conn.close()

    @app.route('/api/documentos/modelos', methods=['PUT'])
    @requer_permissao('secretaria.deletar')       # chefe da Secretaria (auxiliar não altera modelos)
    def salvar_modelo():
        d = request.get_json(silent=True) or {}
        try:
            tipo = opcao(d, 'tipo', TIPOS_MODELO)
            corpo = texto(d, 'texto', max_len=5000)
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            if corpo:
                conn.execute('''INSERT OR REPLACE INTO modelos_documento (tipo, texto, atualizado_por, atualizado_em)
                                VALUES (?, ?, ?, datetime('now'))''', (tipo, corpo, usuario_atual()['nome']))
            else:   # texto vazio: volta ao modelo padrão do sistema
                conn.execute('DELETE FROM modelos_documento WHERE tipo = ?', (tipo,))
            registrar('secretaria', f'Alterou o modelo "{tipo}"', '', conn)
            conn.commit()
            return jsonify({'msg': 'Modelo salvo' if corpo else 'Modelo padrão restaurado'}), 200
        finally:
            conn.close()

    # ---------------- Arquivo digital ----------------
    def _ler_meta(d):
        return {
            'titulo': texto(d, 'titulo', True, 200),
            'categoria': opcao(d, 'categoria', CATEGORIAS_ARQ, 'outro'),
            'descricao': texto(d, 'descricao', max_len=1000),
            'membro_id': inteiro(d, 'membro_id'),
            'contrato_id': inteiro(d, 'contrato_id'),
            'congregacao_id': inteiro(d, 'congregacao_id'),
            'vencimento': data_iso(d, 'vencimento'),
        }

    @app.route('/api/arquivos', methods=['GET'])
    @requer_permissao('secretaria.consultar')
    def listar_arquivos():
        where, params = [], []
        for campo in ('categoria', 'membro_id', 'contrato_id', 'congregacao_id'):
            if request.args.get(campo):
                where.append(f'a.{campo} = ?')
                params.append(request.args.get(campo))
        if request.args.get('busca'):
            where.append('(a.titulo LIKE ? OR a.descricao LIKE ? OR a.nome_original LIKE ?)')
            params += [f"%{request.args['busca']}%"] * 3
        conn = get_db()
        try:
            rows = conn.execute(f'''SELECT a.id, a.titulo, a.categoria, a.descricao, a.membro_id, a.contrato_id, a.congregacao_id,
                                           a.vencimento, a.nome_original, a.mime, a.tamanho, a.enviado_por, a.criado_em,
                                           (SELECT nome FROM membros m WHERE m.id = a.membro_id) AS membro_nome,
                                           (SELECT descricao FROM contratos c WHERE c.id = a.contrato_id) AS contrato_descricao,
                                           (SELECT nome FROM congregacoes g WHERE g.id = a.congregacao_id) AS congregacao_nome
                                    FROM arquivos a {'WHERE ' + ' AND '.join(where) if where else ''}
                                    ORDER BY a.criado_em DESC LIMIT 1000''', params).fetchall()
            return jsonify({'arquivos': rows_to_dicts(rows), 'categorias': CATEGORIAS_ARQ}), 200
        finally:
            conn.close()

    @app.route('/api/arquivos', methods=['POST'])
    @requer_permissao('secretaria.criar')
    def enviar_arquivo():
        arq = request.files.get('arquivo')
        if not arq or not arq.filename:
            return _erro('Escolha o arquivo (PDF, foto ou documento)')
        ext = arq.filename.rsplit('.', 1)[-1].lower() if '.' in arq.filename else ''
        if ext not in EXTENSOES:
            return _erro(f'Tipo de arquivo não aceito (.{ext}). Use: ' + ', '.join(sorted(EXTENSOES)))
        try:
            meta = _ler_meta(request.form)
        except ErroValidacao as e:
            return _erro(e)
        nome_salvo = f'{date.today():%Y%m}_{secrets.token_hex(8)}.{ext}'
        caminho = os.path.join(PASTA_ARQUIVOS, nome_salvo)
        arq.save(caminho)
        tamanho = os.path.getsize(caminho)
        if tamanho > TAMANHO_MAX:
            os.remove(caminho)
            return _erro('Arquivo maior que 15 MB')
        conn = get_db()
        try:
            cur = conn.execute('''INSERT INTO arquivos (titulo, categoria, descricao, membro_id, contrato_id, congregacao_id, vencimento,
                                  nome_arquivo, nome_original, mime, tamanho, enviado_por) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
                               (*meta.values(), nome_salvo, arq.filename[:200], arq.mimetype, tamanho, usuario_atual()['nome']))
            registrar('secretaria', f'Arquivou "{meta["titulo"]}"', arq.filename, conn)
            conn.commit()
            return jsonify({'msg': 'Arquivo guardado', 'id': cur.lastrowid}), 201
        finally:
            conn.close()

    @app.route('/api/arquivos/<int:id>', methods=['PUT'])
    @requer_permissao('secretaria.editar')
    def editar_arquivo(id):
        try:
            meta = _ler_meta(request.get_json(silent=True) or {})
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            cur = conn.execute(f'UPDATE arquivos SET {", ".join(f"{k} = ?" for k in meta)} WHERE id = ?', [*meta.values(), id])
            if cur.rowcount == 0:
                return _erro('Arquivo não encontrado', 404)
            registrar('secretaria', f'Editou dados do arquivo #{id}', meta['titulo'], conn)
            conn.commit()
            return jsonify({'msg': 'Dados do arquivo atualizados'}), 200
        finally:
            conn.close()

    @app.route('/api/arquivos/<int:id>/conteudo', methods=['GET'])
    @requer_permissao('secretaria.consultar')
    def baixar_arquivo(id):
        conn = get_db()
        try:
            a = conn.execute('SELECT * FROM arquivos WHERE id = ?', (id,)).fetchone()
        finally:
            conn.close()
        if not a or not os.path.exists(os.path.join(PASTA_ARQUIVOS, a['nome_arquivo'])):
            return _erro('Arquivo não encontrado', 404)
        return send_file(os.path.join(PASTA_ARQUIVOS, a['nome_arquivo']), mimetype=a['mime'] or 'application/octet-stream',
                         download_name=a['nome_original'], as_attachment=request.args.get('baixar') == '1')

    @app.route('/api/arquivos/<int:id>', methods=['DELETE'])
    @requer_permissao('secretaria.deletar')
    def excluir_arquivo(id):
        conn = get_db()
        try:
            a = conn.execute('SELECT * FROM arquivos WHERE id = ?', (id,)).fetchone()
            if not a:
                return _erro('Arquivo não encontrado', 404)
            conn.execute('DELETE FROM arquivos WHERE id = ?', (id,))
            registrar('secretaria', f'Excluiu o arquivo "{a["titulo"]}"', a['nome_original'], conn)
            conn.commit()
        finally:
            conn.close()
        try:
            os.remove(os.path.join(PASTA_ARQUIVOS, a['nome_arquivo']))
        except OSError:
            pass
        return jsonify({'msg': 'Arquivo excluído'}), 200

    # ---------------- Central de alertas ----------------
    @app.route('/api/alertas', methods=['GET'])
    @jwt_required()
    def alertas():
        """Vencimentos (contratos, documentos com validade) e aniversários, conforme o perfil."""
        user = usuario_atual()
        hoje = date.today()
        lim = (hoje + timedelta(days=90)).isoformat()
        itens = []
        conn = get_db()
        try:
            if Permissao.tem_acesso(user, 'secretaria.consultar'):
                for c in conn.execute('SELECT id, descricao, vencimento, valor FROM contratos WHERE vencimento IS NOT NULL AND vencimento <= ?', (lim,)):
                    dias = (date.fromisoformat(c['vencimento']) - hoje).days
                    itens.append({'tipo': 'contrato', 'titulo': c['descricao'], 'data': c['vencimento'], 'dias': dias,
                                  'nivel': 'critico' if dias < 0 else 'alto' if dias <= 30 else 'medio' if dias <= 60 else 'baixo',
                                  'link': 'secretaria.html'})
                for a in conn.execute('SELECT id, titulo, categoria, vencimento FROM arquivos WHERE vencimento IS NOT NULL AND vencimento <= ?', (lim,)):
                    dias = (date.fromisoformat(a['vencimento']) - hoje).days
                    itens.append({'tipo': 'documento', 'titulo': a['titulo'], 'categoria': a['categoria'], 'data': a['vencimento'],
                                  'dias': dias, 'nivel': 'critico' if dias < 0 else 'alto' if dias <= 30 else 'medio' if dias <= 60 else 'baixo',
                                  'link': 'secretaria.html'})
            if Permissao.tem_acesso(user, 'membros.consultar'):
                for m in conn.execute('''SELECT nome, data_nascimento, data_casamento, funcao FROM membros
                                         WHERE status = 'ativo' AND COALESCE(aprovacao, 'aprovado') = 'aprovado'
                                           AND (data_nascimento IS NOT NULL OR data_casamento IS NOT NULL)'''):
                    for campo, rotulo in (('data_nascimento', 'Aniversário'), ('data_casamento', 'Aniversário de casamento')):
                        if not m[campo]:
                            continue
                        d = date.fromisoformat(m[campo])
                        try:
                            prox = d.replace(year=hoje.year)
                        except ValueError:          # 29/02
                            prox = date(hoje.year, 3, 1)
                        if prox < hoje:
                            prox = prox.replace(year=hoje.year + 1) if not (prox.month == 2 and prox.day == 29) else date(hoje.year + 1, 3, 1)
                        dias = (prox - hoje).days
                        if dias <= 7:
                            itens.append({'tipo': 'aniversario', 'titulo': f"{rotulo}: {m['nome']}" + (f" ({m['funcao']})" if m['funcao'] and m['funcao'] != 'Membro' else ''),
                                          'data': prox.isoformat(), 'dias': dias, 'nivel': 'info', 'link': 'membros.html'})
        finally:
            conn.close()
        ordem = {'critico': 0, 'alto': 1, 'medio': 2, 'info': 3, 'baixo': 4}
        itens.sort(key=lambda x: (ordem[x['nivel']], x['dias']))
        return jsonify({'alertas': itens}), 200
