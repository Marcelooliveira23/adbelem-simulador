"""Versão 1.2 — funções inspiradas nos sistemas do mercado (Planning Center, ChurchTrac, Breeze, Aplos, Sige).

Tesouraria : contas financeiras (caixa e bancos) com saldo, transferências entre contas, orçamento anual
             (previsto x realizado) e exportação contábil para o contador.
Secretaria : agenda de eventos com reserva de espaços e aviso de conflito, escalas de serviço (voluntários),
             livro de registros eclesiásticos, atas de reuniões, Escola Dominical (classes e chamada)
             e frequência dos cultos.
Patrimônio : espaços/ambientes e manutenção preventiva programada.
"""
import csv
import io
from datetime import date

from flask import request, jsonify

from app.auditoria import registrar
from app.auth_utils import requer_permissao, usuario_atual
from app.crud import registrar_crud
from app.database import get_db, rows_to_dicts
from app.periodos import periodo_fechado, msg_fechado, categorias_validas
from app.validacao import ErroValidacao, texto, opcao, numero, data_iso, inteiro, brl


def _erro(msg, codigo=400):
    return jsonify({'erro': str(msg)}), codigo


def _ativo(d):
    return 0 if str(d.get('ativo', '1')) in ('0', 'false', 'False') else 1


def _hora(d, campo):
    v = texto(d, campo, max_len=5)
    if v and not (len(v) == 5 and v[2] == ':' and v.replace(':', '').isdigit()):
        raise ErroValidacao(f'Hora inválida em "{campo}" (use HH:MM)')
    return v


def _soma_meses(iso, meses):
    a, m, d = int(iso[:4]), int(iso[5:7]) - 1 + meses, int(iso[8:10])
    a, m = a + m // 12, m % 12 + 1
    import calendar
    return f'{a:04d}-{m:02d}-{min(d, calendar.monthrange(a, m)[1]):02d}'


def saldos_contas(conn):
    contas = rows_to_dicts(conn.execute('SELECT * FROM contas_financeiras ORDER BY ativo DESC, tipo, nome'))
    ok = "COALESCE(aprovacao, 'aprovado') = 'aprovado'"
    for c in contas:
        rec = conn.execute(f"SELECT COALESCE(SUM(valor), 0) FROM financeiro WHERE conta_id = ? AND tipo = 'receita' AND {ok}",
                           (c['id'],)).fetchone()[0]
        desp = conn.execute(f"SELECT COALESCE(SUM(valor), 0) FROM financeiro WHERE conta_id = ? AND tipo = 'despesa' "
                            f"AND status = 'pago' AND {ok}", (c['id'],)).fetchone()[0]
        ent = conn.execute('SELECT COALESCE(SUM(valor), 0) FROM transferencias WHERE destino_id = ?', (c['id'],)).fetchone()[0]
        sai = conn.execute('SELECT COALESCE(SUM(valor), 0) FROM transferencias WHERE origem_id = ?', (c['id'],)).fetchone()[0]
        c.update(entradas=round(rec, 2), saidas=round(desp, 2), transf_entrada=round(ent, 2), transf_saida=round(sai, 2),
                 saldo=round((c['saldo_inicial'] or 0) + rec - desp + ent - sai, 2))
    sem = conn.execute(f"""SELECT COUNT(*) FROM financeiro WHERE conta_id IS NULL AND {ok}""").fetchone()[0]
    return contas, sem


def registrar_gestao2(app):
    # ============================== TESOURARIA ==============================
    registrar_crud(app, rota='tesouraria/contas', tabela='contas_financeiras', modulo='tesouraria', chave_lista='contas',
                   rotulo='conta financeira', ordem='t.ativo DESC, t.nome', campos={
                       'nome': lambda d: texto(d, 'nome', obrigatorio=True, max_len=80),
                       'tipo': lambda d: opcao(d, 'tipo', ('caixa', 'banco', 'aplicacao'), padrao='banco'),
                       'banco': lambda d: texto(d, 'banco', max_len=60), 'agencia': lambda d: texto(d, 'agencia', max_len=20),
                       'numero': lambda d: texto(d, 'numero', max_len=30),
                       'saldo_inicial': lambda d: numero(d, 'saldo_inicial') or 0,
                       'data_saldo_inicial': lambda d: data_iso(d, 'data_saldo_inicial'),
                       'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
                       'observacoes': lambda d: texto(d, 'observacoes', max_len=500), 'ativo': _ativo,
                   })

    @app.route('/api/tesouraria/saldos', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def ver_saldos():
        conn = get_db()
        try:
            contas, sem = saldos_contas(conn)
            transf = rows_to_dicts(conn.execute('''
                SELECT t.*, o.nome AS origem, d.nome AS destino, (SELECT nome FROM usuarios u WHERE u.id = t.usuario_id) AS registrado_por
                FROM transferencias t JOIN contas_financeiras o ON o.id = t.origem_id JOIN contas_financeiras d ON d.id = t.destino_id
                ORDER BY t.data DESC, t.id DESC LIMIT 100'''))
            return jsonify({'contas': contas, 'total': round(sum(c['saldo'] for c in contas if c['ativo']), 2),
                            'lancamentos_sem_conta': sem, 'transferencias': transf}), 200
        finally:
            conn.close()

    @app.route('/api/tesouraria/transferencias', methods=['POST'])
    @requer_permissao('tesouraria.criar')
    def transferir():
        d = request.get_json(silent=True) or {}
        try:
            reg = {'data': data_iso(d, 'data') or date.today().isoformat(),
                   'origem_id': inteiro(d, 'origem_id', obrigatorio=True), 'destino_id': inteiro(d, 'destino_id', obrigatorio=True),
                   'valor': numero(d, 'valor', obrigatorio=True, positivo=True), 'descricao': texto(d, 'descricao', max_len=200)}
            if reg['origem_id'] == reg['destino_id']:
                raise ErroValidacao('Escolha contas diferentes')
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            if periodo_fechado(conn, reg['data']):
                return _erro(msg_fechado(reg['data']), 409)
            contas, _ = saldos_contas(conn)
            por_id = {c['id']: c for c in contas}
            if reg['origem_id'] not in por_id or reg['destino_id'] not in por_id:
                return _erro('Conta não encontrada', 404)
            if reg['valor'] > por_id[reg['origem_id']]['saldo'] + 0.001:
                return _erro(f"Saldo insuficiente em {por_id[reg['origem_id']]['nome']}: {brl(por_id[reg['origem_id']]['saldo'])}")
            reg['usuario_id'] = usuario_atual()['id']
            conn.execute('INSERT INTO transferencias (data, origem_id, destino_id, valor, descricao, usuario_id) VALUES (?,?,?,?,?,?)',
                         (reg['data'], reg['origem_id'], reg['destino_id'], reg['valor'], reg['descricao'], reg['usuario_id']))
            registrar('tesouraria', 'Transferência entre contas',
                      f"{por_id[reg['origem_id']]['nome']} → {por_id[reg['destino_id']]['nome']} {brl(reg['valor'])}", conn)
            conn.commit()
            return jsonify({'msg': 'Transferência registrada'}), 201
        finally:
            conn.close()

    @app.route('/api/tesouraria/transferencias/<int:id>', methods=['DELETE'])
    @requer_permissao('tesouraria.deletar')
    def desfazer_transferencia(id):
        conn = get_db()
        try:
            t = conn.execute('SELECT * FROM transferencias WHERE id = ?', (id,)).fetchone()
            if not t:
                return _erro('Transferência não encontrada', 404)
            if periodo_fechado(conn, t['data']):
                return _erro(msg_fechado(t['data']), 409)
            conn.execute('DELETE FROM transferencias WHERE id = ?', (id,))
            registrar('tesouraria', f'Desfez transferência #{id}', brl(t['valor']), conn)
            conn.commit()
            return jsonify({'msg': 'Transferência desfeita'}), 200
        finally:
            conn.close()

    # ---- Orçamento anual: previsto x realizado por conta do plano
    @app.route('/api/tesouraria/orcamento', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def ver_orcamento():
        try:
            ano = inteiro(request.args, 'ano') or date.today().year
        except ErroValidacao as e:
            return _erro(e)
        hoje = date.today()
        meses = 12 if ano < hoje.year else (hoje.month if ano == hoje.year else 0)
        conn = get_db()
        try:
            linhas = rows_to_dicts(conn.execute('''
                SELECT p.tipo, p.chave AS categoria, p.codigo, p.nome, p.grupo, COALESCE(o.valor_anual, 0) AS previsto,
                       COALESCE((SELECT SUM(f.valor) FROM financeiro f WHERE f.tipo = p.tipo AND f.categoria = p.chave
                                 AND COALESCE(f.aprovacao, 'aprovado') = 'aprovado' AND substr(f.data, 1, 4) = ?), 0) AS realizado
                FROM plano_contas p LEFT JOIN orcamento o ON o.ano = ? AND o.tipo = p.tipo AND o.categoria = p.chave
                WHERE p.ativo = 1 OR o.id IS NOT NULL ORDER BY p.codigo''', (str(ano), ano)))
            for l in linhas:
                l['realizado'] = round(l['realizado'], 2)
                l['previsto_ate_hoje'] = round(l['previsto'] * meses / 12, 2)
                l['percentual'] = round(100 * l['realizado'] / l['previsto'], 1) if l['previsto'] else None
            tot = lambda t, k: round(sum(l[k] for l in linhas if l['tipo'] == t), 2)  # noqa: E731
            return jsonify({'ano': ano, 'meses_decorridos': meses, 'linhas': linhas, 'totais': {
                t: {k: tot(t, k) for k in ('previsto', 'previsto_ate_hoje', 'realizado')} for t in ('receita', 'despesa')}}), 200
        finally:
            conn.close()

    @app.route('/api/tesouraria/orcamento', methods=['PUT'])
    @requer_permissao('tesouraria.aprovar')
    def salvar_orcamento():
        d = request.get_json(silent=True) or {}
        try:
            ano = inteiro(d, 'ano', obrigatorio=True, minimo=2000)
            itens = d.get('itens') or []
            dados = [(ano, opcao(i, 'tipo', ('receita', 'despesa')), texto(i, 'categoria', True, 40), numero(i, 'valor_anual', minimo=0) or 0)
                     for i in itens]
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            conn.executemany('''INSERT INTO orcamento (ano, tipo, categoria, valor_anual) VALUES (?, ?, ?, ?)
                                ON CONFLICT (ano, tipo, categoria) DO UPDATE SET valor_anual = excluded.valor_anual''', dados)
            registrar('tesouraria', f'Atualizou o orçamento de {ano}', f'{len(dados)} conta(s)', conn)
            conn.commit()
            return jsonify({'msg': f'Orçamento de {ano} salvo'}), 200
        finally:
            conn.close()

    @app.route('/api/tesouraria/orcamento/copiar', methods=['POST'])
    @requer_permissao('tesouraria.aprovar')
    def copiar_orcamento():
        """Cria o orçamento do ano a partir do realizado (ou previsto) do ano anterior, com reajuste."""
        d = request.get_json(silent=True) or {}
        try:
            ano = inteiro(d, 'ano', obrigatorio=True, minimo=2000)
            reaj = 1 + (numero(d, 'reajuste') or 0) / 100
            base = opcao(d, 'base', ('realizado', 'previsto'), padrao='realizado')
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            if base == 'previsto':
                rows = conn.execute('SELECT tipo, categoria, valor_anual AS v FROM orcamento WHERE ano = ?', (ano - 1,)).fetchall()
            else:
                rows = conn.execute('''SELECT tipo, categoria, SUM(valor) AS v FROM financeiro
                                       WHERE COALESCE(aprovacao, 'aprovado') = 'aprovado' AND substr(data, 1, 4) = ?
                                       GROUP BY tipo, categoria''', (str(ano - 1),)).fetchall()
            conn.executemany('''INSERT INTO orcamento (ano, tipo, categoria, valor_anual) VALUES (?, ?, ?, ?)
                                ON CONFLICT (ano, tipo, categoria) DO UPDATE SET valor_anual = excluded.valor_anual''',
                             [(ano, r['tipo'], r['categoria'], round((r['v'] or 0) * reaj, 2)) for r in rows])
            registrar('tesouraria', f'Gerou orçamento de {ano} a partir de {ano - 1}', f'{base}, reajuste {d.get("reajuste") or 0}%', conn)
            conn.commit()
            return jsonify({'msg': f'{len(rows)} conta(s) copiadas de {ano - 1}'}), 200
        finally:
            conn.close()

    # ---- Exportação contábil (planilha para o contador)
    @app.route('/api/tesouraria/exportar', methods=['GET'])
    @requer_permissao('tesouraria.consultar')
    def exportar_contabil():
        try:
            ini = data_iso(request.args, 'inicio', obrigatorio=True)
            fim = data_iso(request.args, 'fim', obrigatorio=True)
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            rows = conn.execute('''
                SELECT f.id, f.data, f.documento, COALESCE(p.codigo, '') AS codigo, COALESCE(p.nome, f.categoria) AS conta,
                       f.descricao, COALESCE((SELECT nome FROM congregacoes c WHERE c.id = f.congregacao_id), 'Sede') AS unidade,
                       (SELECT nome FROM fornecedores o WHERE o.id = f.fornecedor_id) AS fornecedor,
                       (SELECT nome FROM contas_financeiras k WHERE k.id = f.conta_id) AS conta_financeira,
                       f.forma, f.tipo, f.valor, f.status
                FROM financeiro f LEFT JOIN plano_contas p ON p.tipo = f.tipo AND p.chave = f.categoria
                WHERE COALESCE(f.aprovacao, 'aprovado') = 'aprovado' AND f.data BETWEEN ? AND ?
                ORDER BY f.data, f.id''', (ini, fim)).fetchall()
            buf = io.StringIO()
            w = csv.writer(buf, delimiter=';', lineterminator='\r\n')
            w.writerow(['Lançamento', 'Data', 'Documento', 'Código contábil', 'Conta', 'Histórico', 'Unidade', 'Fornecedor',
                        'Conta financeira', 'Forma', 'Entrada', 'Saída', 'Situação'])
            fmt = lambda v: f'{v:.2f}'.replace('.', ',')  # noqa: E731
            for r in rows:
                w.writerow([r['id'], r['data'], r['documento'] or '', r['codigo'], r['conta'], r['descricao'], r['unidade'],
                            r['fornecedor'] or '', r['conta_financeira'] or '', r['forma'] or '',
                            fmt(r['valor']) if r['tipo'] == 'receita' else '', fmt(r['valor']) if r['tipo'] == 'despesa' else '',
                            'pago' if r['tipo'] == 'despesa' and r['status'] == 'pago' else ('a pagar' if r['tipo'] == 'despesa' else 'recebido')])
            registrar('tesouraria', 'Exportou lançamentos para o contador', f'{ini} a {fim}: {len(rows)} linha(s)', conn)
            conn.commit()
            return app.response_class('﻿' + buf.getvalue(), mimetype='text/csv; charset=utf-8', headers={
                'Content-Disposition': f'attachment; filename=lancamentos-{ini}-a-{fim}.csv'})
        finally:
            conn.close()

    # ============================== SECRETARIA ==============================
    TIPOS_EVENTO = ('culto', 'santa_ceia', 'batismo', 'casamento', 'reuniao', 'ensaio', 'congresso', 'evento', 'ebd', 'outro')
    registrar_crud(app, rota='eventos', tabela='eventos', modulo='secretaria', rotulo='evento', escopo=True,
                   ordem='t.data, t.hora_inicio', filtros=('tipo', 'congregacao_id', 'espaco_id'), campos={
                       'titulo': lambda d: texto(d, 'titulo', obrigatorio=True, max_len=150),
                       'tipo': lambda d: opcao(d, 'tipo', TIPOS_EVENTO, padrao='evento'),
                       'data': lambda d: data_iso(d, 'data', obrigatorio=True),
                       'hora_inicio': lambda d: _hora(d, 'hora_inicio'), 'hora_fim': lambda d: _hora(d, 'hora_fim'),
                       'congregacao_id': lambda d: inteiro(d, 'congregacao_id'), 'espaco_id': lambda d: inteiro(d, 'espaco_id'),
                       'departamento_id': lambda d: inteiro(d, 'departamento_id'),
                       'responsavel': lambda d: texto(d, 'responsavel', max_len=120), 'publico': lambda d: texto(d, 'publico', max_len=80),
                       'descricao': lambda d: texto(d, 'descricao', max_len=2000),
                       'status': lambda d: opcao(d, 'status', ('confirmado', 'a_confirmar', 'cancelado'), padrao='confirmado'),
                   })

    @app.route('/api/eventos/conflitos', methods=['GET'])
    @requer_permissao('secretaria.consultar')
    def conflitos_espaco():
        """Outros eventos no mesmo espaço e dia com horário sobreposto (reserva de salas)."""
        a = request.args
        if not a.get('espaco_id') or not a.get('data'):
            return jsonify({'conflitos': []}), 200
        ini, fim = a.get('hora_inicio') or '00:00', a.get('hora_fim') or a.get('hora_inicio') or '23:59'
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('''
                SELECT id, titulo, hora_inicio, hora_fim, responsavel FROM eventos
                WHERE espaco_id = ? AND data = ? AND id != ? AND status != 'cancelado'
                  AND COALESCE(hora_inicio, '00:00') < ? AND COALESCE(hora_fim, hora_inicio, '23:59') > ?''',
                (a['espaco_id'], a['data'], a.get('ignorar') or 0, fim if fim > ini else '23:59', ini)))
            return jsonify({'conflitos': rows}), 200
        finally:
            conn.close()

    registrar_crud(app, rota='escalas', tabela='escalas', modulo='secretaria', rotulo='escala', escopo=True,
                   ordem='t.data, t.funcao', filtros=('funcao', 'congregacao_id', 'evento_id'), campos={
                       'data': lambda d: data_iso(d, 'data', obrigatorio=True), 'evento_id': lambda d: inteiro(d, 'evento_id'),
                       'funcao': lambda d: texto(d, 'funcao', obrigatorio=True, max_len=60),
                       'pessoa': lambda d: texto(d, 'pessoa', obrigatorio=True, max_len=120),
                       'membro_id': lambda d: inteiro(d, 'membro_id'), 'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
                       'confirmado': lambda d: 1 if str(d.get('confirmado', '0')) in ('1', 'true', 'True') else 0,
                       'observacao': lambda d: texto(d, 'observacao', max_len=300),
                   })

    registrar_crud(app, rota='registros', tabela='registros_eclesiasticos', modulo='secretaria', rotulo='registro',
                   chave_lista='registros', escopo=True, ordem='t.data DESC', filtros=('tipo', 'congregacao_id'), campos={
                       'tipo': lambda d: opcao(d, 'tipo', ('batismo', 'casamento', 'apresentacao', 'consagracao',
                                                           'profissao_fe', 'bencao'), padrao='batismo'),
                       'data': lambda d: data_iso(d, 'data', obrigatorio=True),
                       'nome': lambda d: texto(d, 'nome', obrigatorio=True, max_len=150), 'membro_id': lambda d: inteiro(d, 'membro_id'),
                       'segundo_nome': lambda d: texto(d, 'segundo_nome', max_len=150), 'pais': lambda d: texto(d, 'pais', max_len=200),
                       'oficiante': lambda d: texto(d, 'oficiante', max_len=120), 'local': lambda d: texto(d, 'local', max_len=150),
                       'congregacao_id': lambda d: inteiro(d, 'congregacao_id'), 'livro': lambda d: texto(d, 'livro', max_len=20),
                       'folha': lambda d: texto(d, 'folha', max_len=20), 'numero': lambda d: texto(d, 'numero', max_len=20),
                       'testemunhas': lambda d: texto(d, 'testemunhas', max_len=300),
                       'observacoes': lambda d: texto(d, 'observacoes', max_len=1000),
                   })

    registrar_crud(app, rota='atas', tabela='atas', modulo='secretaria', rotulo='ata', ordem='t.data DESC',
                   filtros=('tipo', 'situacao'), campos={
                       'numero': lambda d: texto(d, 'numero', max_len=20),
                       'tipo': lambda d: opcao(d, 'tipo', ('assembleia_ordinaria', 'assembleia_extraordinaria', 'ministerio',
                                                           'conselho_fiscal', 'diretoria', 'departamento'), padrao='ministerio'),
                       'data': lambda d: data_iso(d, 'data', obrigatorio=True), 'local': lambda d: texto(d, 'local', max_len=150),
                       'presidente': lambda d: texto(d, 'presidente', max_len=120), 'secretario': lambda d: texto(d, 'secretario', max_len=120),
                       'presentes': lambda d: texto(d, 'presentes', max_len=3000), 'pauta': lambda d: texto(d, 'pauta', max_len=3000),
                       'deliberacoes': lambda d: texto(d, 'deliberacoes', max_len=20000),
                       'situacao': lambda d: opcao(d, 'situacao', ('rascunho', 'aprovada'), padrao='rascunho'),
                   })

    registrar_crud(app, rota='ebd/classes', tabela='ebd_classes', modulo='secretaria', rotulo='classe', chave_lista='classes',
                   escopo=True, ordem='t.ativo DESC, t.nome', campos={
                       'nome': lambda d: texto(d, 'nome', obrigatorio=True, max_len=80), 'faixa': lambda d: texto(d, 'faixa', max_len=60),
                       'professor': lambda d: texto(d, 'professor', max_len=120), 'auxiliar': lambda d: texto(d, 'auxiliar', max_len=120),
                       'sala': lambda d: texto(d, 'sala', max_len=60), 'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
                       'matriculados': lambda d: inteiro(d, 'matriculados', minimo=0) or 0, 'ativo': _ativo,
                   })

    def _aula(d):
        return {'classe_id': inteiro(d, 'classe_id', obrigatorio=True), 'data': data_iso(d, 'data', obrigatorio=True),
                'licao': texto(d, 'licao', max_len=150), 'matriculados': inteiro(d, 'matriculados', minimo=0) or 0,
                'presentes': inteiro(d, 'presentes', minimo=0) or 0, 'visitantes': inteiro(d, 'visitantes', minimo=0) or 0,
                'biblias': inteiro(d, 'biblias', minimo=0) or 0, 'revistas': inteiro(d, 'revistas', minimo=0) or 0,
                'oferta': numero(d, 'oferta', minimo=0) or 0, 'observacao': texto(d, 'observacao', max_len=300)}

    @app.route('/api/ebd/chamada', methods=['GET'])
    @requer_permissao('secretaria.consultar')
    def ebd_chamada():
        """Relatório do domingo: uma linha por classe ativa, com o que já foi lançado."""
        dia = request.args.get('data') or date.today().isoformat()
        conn = get_db()
        try:
            rows = rows_to_dicts(conn.execute('''
                SELECT c.id AS classe_id, c.nome, c.professor, c.matriculados AS matriculados_classe, a.id AS aula_id,
                       a.licao, a.matriculados, a.presentes, a.visitantes, a.biblias, a.revistas, a.oferta, a.observacao
                FROM ebd_classes c LEFT JOIN ebd_aulas a ON a.classe_id = c.id AND a.data = ?
                WHERE c.ativo = 1 ORDER BY c.nome''', (dia,)))
            for r in rows:
                r['classe_id'] = r['classe_id'] or r.get('classe_id')
            return jsonify({'data': dia, 'classes': rows}), 200
        finally:
            conn.close()

    @app.route('/api/ebd/chamada', methods=['PUT'])
    @requer_permissao('secretaria.criar')
    def ebd_salvar():
        d = request.get_json(silent=True) or {}
        try:
            aulas = [_aula({**a, 'data': d.get('data')}) for a in (d.get('aulas') or [])]
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            for a in aulas:
                if a['presentes'] > a['matriculados'] + a['visitantes'] and a['matriculados']:
                    return _erro('Presentes não pode passar de matriculados + visitantes')
                cols = list(a)
                conn.execute(f'''INSERT INTO ebd_aulas ({", ".join(cols)}) VALUES ({", ".join("?" for _ in cols)})
                                 ON CONFLICT (classe_id, data) DO UPDATE SET {", ".join(f"{c} = excluded.{c}" for c in cols[2:])}''',
                             [a[c] for c in cols])
            registrar('secretaria', f"Lançou a chamada da EBD de {d.get('data')}", f'{len(aulas)} classe(s)', conn)
            conn.commit()
            return jsonify({'msg': 'Chamada da EBD salva'}), 200
        finally:
            conn.close()

    @app.route('/api/ebd/resumo', methods=['GET'])
    @requer_permissao('secretaria.consultar')
    def ebd_resumo():
        ano = request.args.get('ano') or str(date.today().year)
        conn = get_db()
        try:
            domingos = rows_to_dicts(conn.execute('''
                SELECT data, SUM(matriculados) AS matriculados, SUM(presentes) AS presentes, SUM(visitantes) AS visitantes,
                       SUM(biblias) AS biblias, SUM(revistas) AS revistas, ROUND(SUM(oferta), 2) AS oferta
                FROM ebd_aulas WHERE substr(data, 1, 4) = ? GROUP BY data ORDER BY data DESC''', (ano,)))
            classes = rows_to_dicts(conn.execute('''
                SELECT c.nome, c.professor, COUNT(a.id) AS aulas, ROUND(AVG(a.presentes), 1) AS media_presentes,
                       ROUND(100.0 * SUM(a.presentes) / NULLIF(SUM(a.matriculados), 0), 1) AS frequencia
                FROM ebd_classes c LEFT JOIN ebd_aulas a ON a.classe_id = c.id AND substr(a.data, 1, 4) = ?
                GROUP BY c.id ORDER BY c.nome''', (ano,)))
            return jsonify({'ano': ano, 'domingos': domingos, 'classes': classes}), 200
        finally:
            conn.close()

    registrar_crud(app, rota='frequencia', tabela='frequencia_cultos', modulo='secretaria', rotulo='registro de culto',
                   chave_lista='registros', escopo=True, ordem='t.data DESC', filtros=('congregacao_id',), campos={
                       'data': lambda d: data_iso(d, 'data', obrigatorio=True), 'culto': lambda d: texto(d, 'culto', max_len=80),
                       'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
                       'adultos': lambda d: inteiro(d, 'adultos', minimo=0) or 0, 'criancas': lambda d: inteiro(d, 'criancas', minimo=0) or 0,
                       'visitantes': lambda d: inteiro(d, 'visitantes', minimo=0) or 0,
                       'decisoes': lambda d: inteiro(d, 'decisoes', minimo=0) or 0,
                       'reconciliacoes': lambda d: inteiro(d, 'reconciliacoes', minimo=0) or 0,
                       'pregador': lambda d: texto(d, 'pregador', max_len=120), 'tema': lambda d: texto(d, 'tema', max_len=200),
                       'observacao': lambda d: texto(d, 'observacao', max_len=500),
                   })

    # ============================== PATRIMÔNIO ==============================
    registrar_crud(app, rota='espacos', tabela='espacos', modulo='patrimonio', rotulo='espaço', escopo=True,
                   ordem='t.ativo DESC, t.nome', campos={
                       'nome': lambda d: texto(d, 'nome', obrigatorio=True, max_len=100),
                       'congregacao_id': lambda d: inteiro(d, 'congregacao_id'),
                       'capacidade': lambda d: inteiro(d, 'capacidade', minimo=0), 'recursos': lambda d: texto(d, 'recursos', max_len=300),
                       'observacoes': lambda d: texto(d, 'observacoes', max_len=500), 'ativo': _ativo,
                   })

    @app.route('/api/espacos/opcoes', methods=['GET'])
    @requer_permissao('secretaria.consultar')
    def espacos_opcoes():
        """Lista simples de espaços para a agenda (a Secretaria reserva sem precisar do módulo Patrimônio)."""
        conn = get_db()
        try:
            return jsonify({'espacos': rows_to_dicts(conn.execute('''
                SELECT id, nome, capacidade, congregacao_id FROM espacos WHERE ativo = 1 ORDER BY nome'''))}), 200
        finally:
            conn.close()

    registrar_crud(app, rota='patrimonio/preventivas', tabela='manutencoes_programadas', modulo='patrimonio',
                   rotulo='manutenção preventiva', chave_lista='preventivas', ordem='t.ativo DESC, t.proxima_data', campos={
                       'patrimonio_id': lambda d: inteiro(d, 'patrimonio_id'), 'espaco': lambda d: texto(d, 'espaco', max_len=100),
                       'descricao': lambda d: texto(d, 'descricao', obrigatorio=True, max_len=200),
                       'periodicidade_meses': lambda d: inteiro(d, 'periodicidade_meses', obrigatorio=True, minimo=1),
                       'proxima_data': lambda d: data_iso(d, 'proxima_data', obrigatorio=True),
                       'prestador': lambda d: texto(d, 'prestador', max_len=150),
                       'custo_estimado': lambda d: numero(d, 'custo_estimado', minimo=0) or 0, 'ativo': _ativo,
                   })

    @app.route('/api/patrimonio/preventivas/<int:id>/realizada', methods=['POST'])
    @requer_permissao('patrimonio.editar')
    def preventiva_realizada(id):
        d = request.get_json(silent=True) or {}
        try:
            quando = data_iso(d, 'data') or date.today().isoformat()
            custo = numero(d, 'custo', minimo=0) or 0
            obs = texto(d, 'observacao', max_len=500)
        except ErroValidacao as e:
            return _erro(e)
        conn = get_db()
        try:
            p = conn.execute('SELECT * FROM manutencoes_programadas WHERE id = ?', (id,)).fetchone()
            if not p:
                return _erro('Manutenção não encontrada', 404)
            proxima = _soma_meses(quando, p['periodicidade_meses'])
            conn.execute('UPDATE manutencoes_programadas SET ultima_data = ?, proxima_data = ? WHERE id = ?', (quando, proxima, id))
            if p['patrimonio_id']:
                conn.execute('''INSERT INTO patrimonio_mov (patrimonio_id, tipo, data, prestador, valor, motivo, usuario_id, origem)
                                VALUES (?, 'preventiva', ?, ?, ?, ?, ?, 'Manutenção preventiva')''',
                             (p['patrimonio_id'], quando, p['prestador'], custo, f"{p['descricao']}. {obs or ''}".strip(),
                              usuario_atual()['id']))
            registrar('patrimonio', f'Registrou manutenção preventiva #{id}', f"{p['descricao']} · próxima {proxima}", conn)
            conn.commit()
            return jsonify({'msg': f'Registrada. Próxima em {proxima[8:10]}/{proxima[5:7]}/{proxima[:4]}', 'proxima_data': proxima}), 200
        finally:
            conn.close()


def contagens_v12(conn, pode):
    """Pendências da v1.2 para o Painel."""
    out, hoje = {}, date.today().isoformat()
    if pode('patrimonio.consultar'):
        out['preventivas_vencidas'] = conn.execute(
            'SELECT COUNT(*) FROM manutencoes_programadas WHERE ativo = 1 AND proxima_data <= ?', (hoje,)).fetchone()[0]
        out['garantias_seguros_vencendo'] = conn.execute('''SELECT COUNT(*) FROM patrimonio WHERE status != 'descartado' AND (
            (seguro_ate BETWEEN ? AND date(?, '+30 day')) OR (garantia_ate BETWEEN ? AND date(?, '+30 day')))''',
            (hoje, hoje, hoje, hoje)).fetchone()[0]
    if pode('secretaria.consultar'):
        out['eventos_semana'] = conn.execute("SELECT COUNT(*) FROM eventos WHERE status != 'cancelado' AND data BETWEEN ? AND date(?, '+7 day')",
                                             (hoje, hoje)).fetchone()[0]
        out['escalas_sem_confirmar'] = conn.execute(
            "SELECT COUNT(*) FROM escalas WHERE confirmado = 0 AND data BETWEEN ? AND date(?, '+7 day')", (hoje, hoje)).fetchone()[0]
    return out
