"""Acesso ao banco SQLite e definição do schema.

Todas as rotas usam get_db() daqui, para que o caminho do banco seja sempre o mesmo
(independente da pasta de onde o servidor foi iniciado).
"""
import os
import sqlite3

from app.config import DB_PATH  # noqa: E402  (caminho central em app/config.py)

# Colunas esperadas por tabela (usadas para detectar schema antigo)
SCHEMA = {
    'usuarios': """
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            senha_hash TEXT NOT NULL,
            perfil_id INTEGER NOT NULL,
            ativo INTEGER DEFAULT 1,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'membros': """
        CREATE TABLE IF NOT EXISTS membros (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT,
            telefone TEXT,
            data_nascimento DATE,
            endereco TEXT,
            cidade TEXT,
            estado TEXT,
            cep TEXT,
            status TEXT NOT NULL DEFAULT 'ativo',
            observacoes TEXT,
            data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'financeiro': """
        CREATE TABLE IF NOT EXISTS financeiro (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo TEXT NOT NULL CHECK (tipo IN ('receita', 'despesa')),
            descricao TEXT NOT NULL,
            valor REAL NOT NULL CHECK (valor > 0),
            data DATE NOT NULL,
            categoria TEXT,
            status TEXT,
            usuario_id INTEGER,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )""",
    'patrimonio': """
        CREATE TABLE IF NOT EXISTS patrimonio (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            categoria TEXT,
            local TEXT,
            valor REAL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'bom',
            data_aquisicao DATE,
            observacoes TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'congregacoes': """
        CREATE TABLE IF NOT EXISTS congregacoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            endereco TEXT,
            cidade TEXT,
            estado TEXT,
            cep TEXT,
            telefone TEXT,
            data_fundacao DATE,
            ativo INTEGER DEFAULT 1,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
}

# ---------- Tabelas dos módulos novos ----------
SCHEMA.update({
    'auditoria': """
        CREATE TABLE IF NOT EXISTS auditoria (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            usuario_id INTEGER, usuario_nome TEXT,
            modulo TEXT, acao TEXT, detalhe TEXT
        )""",
    'documentos': """
        CREATE TABLE IF NOT EXISTS documentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero INTEGER NOT NULL, ano INTEGER NOT NULL, tipo TEXT NOT NULL,
            membro_id INTEGER, membro_nome TEXT, destino TEXT, observacoes TEXT,
            codigo TEXT UNIQUE NOT NULL, emitido_por TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE (ano, numero)
        )""",
    'contratos': """
        CREATE TABLE IF NOT EXISTS contratos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            descricao TEXT NOT NULL, tipo TEXT, parte TEXT, valor REAL DEFAULT 0,
            inicio DATE, vencimento DATE, congregacao_id INTEGER, observacoes TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
})

SCHEMA.update({
    'caixa_dias': """
        CREATE TABLE IF NOT EXISTS caixa_dias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data DATE NOT NULL, culto TEXT, congregacao_id INTEGER,
            dizimos REAL DEFAULT 0, ofertas REAL DEFAULT 0, outras REAL DEFAULT 0, pix REAL DEFAULT 0,
            conferente1 TEXT, conferente2 TEXT, observacoes TEXT,
            status TEXT DEFAULT 'aberto', criado_por TEXT, conferido_em TIMESTAMP,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'campanhas': """
        CREATE TABLE IF NOT EXISTS campanhas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL, tipo TEXT, meta REAL DEFAULT 0, inicio DATE, fim DATE,
            restrito INTEGER DEFAULT 1, ativo INTEGER DEFAULT 1, descricao TEXT
        )""",
    'extrato': """
        CREATE TABLE IF NOT EXISTS extrato (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data DATE NOT NULL, descricao TEXT, valor REAL NOT NULL,
            financeiro_id INTEGER, status TEXT DEFAULT 'pendente',
            importado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE (data, descricao, valor)
        )""",
    'contas_bancarias': """
        CREATE TABLE IF NOT EXISTS contas_bancarias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            apelido TEXT NOT NULL, banco TEXT DEFAULT '001', agencia TEXT, conta TEXT, chave_pix TEXT,
            categoria_padrao TEXT DEFAULT 'oferta', campanha_id INTEGER, congregacao_id INTEGER,
            token_webhook TEXT UNIQUE, ativo INTEGER DEFAULT 1, ultima_sincronizacao TIMESTAMP
        )""",
    'banco_movimentos': """
        CREATE TABLE IF NOT EXISTS banco_movimentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conta_id INTEGER NOT NULL, origem TEXT NOT NULL, tipo TEXT NOT NULL,
            identificador TEXT NOT NULL UNIQUE, txid TEXT, valor REAL NOT NULL, horario TIMESTAMP,
            pagador_nome TEXT, pagador_documento TEXT, mensagem TEXT, categoria TEXT,
            membro_id INTEGER, financeiro_id INTEGER, recebido_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'membros_fotos': """
        CREATE TABLE IF NOT EXISTS membros_fotos (membro_id INTEGER PRIMARY KEY, foto TEXT NOT NULL)""",
})


# ---------- Acertos das congregações, compras (Secretaria -> Financeiro) e almoxarifado ----------
SCHEMA.update({
    'acertos': """
        CREATE TABLE IF NOT EXISTS acertos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            congregacao_id INTEGER NOT NULL, periodo_inicio DATE NOT NULL, periodo_fim DATE NOT NULL,
            dizimos REAL DEFAULT 0, ofertas REAL DEFAULT 0, ofertas_alcadas REAL DEFAULT 0, missoes REAL DEFAULT 0,
            outras REAL DEFAULT 0, despesas_locais REAL DEFAULT 0, debitos REAL DEFAULT 0, valor_repasse REAL DEFAULT 0,
            valor_recebido REAL, forma TEXT, data_recebimento DATE, banco_movimento_id INTEGER,
            status TEXT DEFAULT 'enviado', observacoes TEXT, criado_por TEXT, recebido_por TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'congregacao_debitos': """
        CREATE TABLE IF NOT EXISTS congregacao_debitos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            congregacao_id INTEGER NOT NULL, descricao TEXT NOT NULL, valor REAL NOT NULL,
            pedido_id INTEGER, status TEXT DEFAULT 'aberto', acerto_id INTEGER,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'pedidos_compra': """
        CREATE TABLE IF NOT EXISTS pedidos_compra (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo TEXT NOT NULL, descricao TEXT NOT NULL, fornecedor TEXT, periodo TEXT,
            valor_total REAL DEFAULT 0, status TEXT DEFAULT 'rascunho', solicitante TEXT,
            decidido_por TEXT, decidido_em TIMESTAMP, motivo TEXT, financeiro_id INTEGER,
            entregue_em TIMESTAMP, observacoes TEXT, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'pedidos_itens': """
        CREATE TABLE IF NOT EXISTS pedidos_itens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pedido_id INTEGER NOT NULL, descricao TEXT NOT NULL, congregacao_id INTEGER,
            quantidade REAL NOT NULL, valor_unitario REAL DEFAULT 0
        )""",
    'materiais': """
        CREATE TABLE IF NOT EXISTS materiais (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL, categoria TEXT, unidade_medida TEXT DEFAULT 'un',
            estoque_minimo REAL DEFAULT 0, ativo INTEGER DEFAULT 1
        )""",
    'materiais_mov': """
        CREATE TABLE IF NOT EXISTS materiais_mov (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            material_id INTEGER NOT NULL, tipo TEXT NOT NULL, quantidade REAL NOT NULL,
            valor_unitario REAL DEFAULT 0, data DATE NOT NULL, origem TEXT, destino_congregacao_id INTEGER,
            recebido_por TEXT, observacao TEXT, criado_por TEXT, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
})

SCHEMA.update({
    'modelos_documento': """
        CREATE TABLE IF NOT EXISTS modelos_documento (tipo TEXT PRIMARY KEY, texto TEXT NOT NULL,
            atualizado_por TEXT, atualizado_em TIMESTAMP)""",
    'arquivos': """
        CREATE TABLE IF NOT EXISTS arquivos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL, categoria TEXT, descricao TEXT, membro_id INTEGER, contrato_id INTEGER,
            congregacao_id INTEGER, vencimento DATE, nome_arquivo TEXT NOT NULL, nome_original TEXT,
            mime TEXT, tamanho INTEGER, enviado_por TEXT, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
})

SCHEMA['configuracoes'] = """
        CREATE TABLE IF NOT EXISTS configuracoes (chave TEXT PRIMARY KEY, valor TEXT)"""


SCHEMA.update({
    # ---- Tesouraria: cadastros e controles contábeis ----
    'fornecedores': """
        CREATE TABLE IF NOT EXISTS fornecedores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL, documento TEXT, ramo TEXT, contato TEXT, telefone TEXT, email TEXT,
            pix TEXT, banco TEXT, endereco TEXT, observacoes TEXT, ativo INTEGER DEFAULT 1,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'plano_contas': """
        CREATE TABLE IF NOT EXISTS plano_contas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT NOT NULL, chave TEXT NOT NULL, nome TEXT NOT NULL,
            tipo TEXT NOT NULL CHECK (tipo IN ('receita', 'despesa')), grupo TEXT, ativo INTEGER DEFAULT 1,
            UNIQUE (tipo, chave)
        )""",
    'contas_recorrentes': """
        CREATE TABLE IF NOT EXISTS contas_recorrentes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            descricao TEXT NOT NULL, fornecedor_id INTEGER, categoria TEXT, valor REAL NOT NULL,
            dia_vencimento INTEGER NOT NULL, forma TEXT, congregacao_id INTEGER, observacoes TEXT,
            ativo INTEGER DEFAULT 1, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'periodos_fechados': """
        CREATE TABLE IF NOT EXISTS periodos_fechados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            competencia TEXT NOT NULL UNIQUE, receitas REAL, despesas REAL, saldo REAL,
            observacao TEXT, fechado_por TEXT, fechado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    # ---- Secretaria ----
    'visitantes': """
        CREATE TABLE IF NOT EXISTS visitantes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL, telefone TEXT, email TEXT, bairro TEXT, data_visita DATE,
            congregacao_id INTEGER, convidado_por TEXT, como_conheceu TEXT, igreja_atual TEXT,
            pedido_oracao TEXT, situacao TEXT DEFAULT 'novo', responsavel TEXT, ultimo_contato DATE,
            observacoes TEXT, membro_id INTEGER, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'departamentos': """
        CREATE TABLE IF NOT EXISTS departamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL, tipo TEXT DEFAULT 'departamento', lider TEXT, vice_lider TEXT, secretario TEXT,
            congregacao_id INTEGER, reunioes TEXT, participantes INTEGER, descricao TEXT, ativo INTEGER DEFAULT 1,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    # ---- Patrimônio ----
    'patrimonio_mov': """
        CREATE TABLE IF NOT EXISTS patrimonio_mov (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patrimonio_id INTEGER NOT NULL, tipo TEXT NOT NULL, data DATE NOT NULL,
            origem TEXT, destino_congregacao_id INTEGER, destino_local TEXT, responsavel TEXT,
            prestador TEXT, valor REAL DEFAULT 0, motivo TEXT, usuario_id INTEGER,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'inventarios': """
        CREATE TABLE IF NOT EXISTS inventarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL, congregacao_id INTEGER, status TEXT DEFAULT 'aberto',
            observacoes TEXT, criado_por TEXT, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP, concluido_em TIMESTAMP
        )""",
    'inventario_itens': """
        CREATE TABLE IF NOT EXISTS inventario_itens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inventario_id INTEGER NOT NULL, patrimonio_id INTEGER NOT NULL, situacao TEXT DEFAULT 'pendente',
            observacao TEXT, conferido_por TEXT, conferido_em TIMESTAMP
        )""",
})

SCHEMA.update({
    # ---- Segurança ----
    'acessos': """
        CREATE TABLE IF NOT EXISTS acessos (
            id INTEGER PRIMARY KEY AUTOINCREMENT, data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            usuario_id INTEGER, email TEXT, ip TEXT, agente TEXT, sucesso INTEGER, motivo TEXT
        )""",
    # ---- Tesouraria v1.2 ----
    'contas_financeiras': """
        CREATE TABLE IF NOT EXISTS contas_financeiras (
            id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, tipo TEXT DEFAULT 'banco',
            banco TEXT, agencia TEXT, numero TEXT, saldo_inicial REAL DEFAULT 0, data_saldo_inicial DATE,
            congregacao_id INTEGER, ativo INTEGER DEFAULT 1, observacoes TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'transferencias': """
        CREATE TABLE IF NOT EXISTS transferencias (
            id INTEGER PRIMARY KEY AUTOINCREMENT, data DATE NOT NULL, origem_id INTEGER NOT NULL,
            destino_id INTEGER NOT NULL, valor REAL NOT NULL CHECK (valor > 0), descricao TEXT,
            usuario_id INTEGER, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'orcamento': """
        CREATE TABLE IF NOT EXISTS orcamento (
            id INTEGER PRIMARY KEY AUTOINCREMENT, ano INTEGER NOT NULL, tipo TEXT NOT NULL, categoria TEXT NOT NULL,
            valor_anual REAL NOT NULL DEFAULT 0, observacao TEXT, UNIQUE (ano, tipo, categoria)
        )""",
    # ---- Secretaria v1.2 ----
    'espacos': """
        CREATE TABLE IF NOT EXISTS espacos (
            id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, congregacao_id INTEGER, capacidade INTEGER,
            recursos TEXT, observacoes TEXT, ativo INTEGER DEFAULT 1
        )""",
    'eventos': """
        CREATE TABLE IF NOT EXISTS eventos (
            id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT NOT NULL, tipo TEXT DEFAULT 'culto',
            data DATE NOT NULL, hora_inicio TEXT, hora_fim TEXT, congregacao_id INTEGER, espaco_id INTEGER,
            departamento_id INTEGER, responsavel TEXT, publico TEXT, descricao TEXT, status TEXT DEFAULT 'confirmado',
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'escalas': """
        CREATE TABLE IF NOT EXISTS escalas (
            id INTEGER PRIMARY KEY AUTOINCREMENT, data DATE NOT NULL, evento_id INTEGER, funcao TEXT NOT NULL,
            pessoa TEXT NOT NULL, membro_id INTEGER, congregacao_id INTEGER, confirmado INTEGER DEFAULT 0,
            observacao TEXT, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'registros_eclesiasticos': """
        CREATE TABLE IF NOT EXISTS registros_eclesiasticos (
            id INTEGER PRIMARY KEY AUTOINCREMENT, tipo TEXT NOT NULL, data DATE NOT NULL, nome TEXT NOT NULL,
            membro_id INTEGER, segundo_nome TEXT, pais TEXT, oficiante TEXT, local TEXT, congregacao_id INTEGER,
            livro TEXT, folha TEXT, numero TEXT, testemunhas TEXT, observacoes TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'atas': """
        CREATE TABLE IF NOT EXISTS atas (
            id INTEGER PRIMARY KEY AUTOINCREMENT, numero TEXT, tipo TEXT DEFAULT 'ministerio', data DATE NOT NULL,
            local TEXT, presidente TEXT, secretario TEXT, presentes TEXT, pauta TEXT, deliberacoes TEXT,
            situacao TEXT DEFAULT 'rascunho', criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'ebd_classes': """
        CREATE TABLE IF NOT EXISTS ebd_classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, faixa TEXT, professor TEXT, auxiliar TEXT,
            sala TEXT, congregacao_id INTEGER, matriculados INTEGER DEFAULT 0, ativo INTEGER DEFAULT 1
        )""",
    'ebd_aulas': """
        CREATE TABLE IF NOT EXISTS ebd_aulas (
            id INTEGER PRIMARY KEY AUTOINCREMENT, classe_id INTEGER NOT NULL, data DATE NOT NULL, licao TEXT,
            matriculados INTEGER DEFAULT 0, presentes INTEGER DEFAULT 0, visitantes INTEGER DEFAULT 0,
            biblias INTEGER DEFAULT 0, revistas INTEGER DEFAULT 0, oferta REAL DEFAULT 0, observacao TEXT,
            UNIQUE (classe_id, data)
        )""",
    'frequencia_cultos': """
        CREATE TABLE IF NOT EXISTS frequencia_cultos (
            id INTEGER PRIMARY KEY AUTOINCREMENT, data DATE NOT NULL, culto TEXT, congregacao_id INTEGER,
            adultos INTEGER DEFAULT 0, criancas INTEGER DEFAULT 0, visitantes INTEGER DEFAULT 0,
            decisoes INTEGER DEFAULT 0, reconciliacoes INTEGER DEFAULT 0, pregador TEXT, tema TEXT, observacao TEXT
        )""",
    # ---- Patrimônio v1.2 ----
    'manutencoes_programadas': """
        CREATE TABLE IF NOT EXISTS manutencoes_programadas (
            id INTEGER PRIMARY KEY AUTOINCREMENT, patrimonio_id INTEGER, espaco TEXT, descricao TEXT NOT NULL,
            periodicidade_meses INTEGER NOT NULL DEFAULT 6, proxima_data DATE NOT NULL, prestador TEXT,
            custo_estimado REAL DEFAULT 0, ultima_data DATE, ativo INTEGER DEFAULT 1
        )""",
    # ---- Pessoal (Tesouraria v1.3) ----
    'funcionarios': """
        CREATE TABLE IF NOT EXISTS funcionarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, cargo TEXT, tipo TEXT DEFAULT 'clt',
            membro_id INTEGER, cpf TEXT, telefone TEXT, email TEXT, data_admissao DATE, data_desligamento DATE,
            remuneracao REAL DEFAULT 0, periodicidade TEXT DEFAULT 'mensal', dia_pagamento INTEGER,
            forma_pagamento TEXT, pix TEXT, banco TEXT, congregacao_id INTEGER, ativo INTEGER DEFAULT 1,
            observacoes TEXT, criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    # ---- Permissões personalizadas dos níveis de acesso ----
    'perfis_custom': """
        CREATE TABLE IF NOT EXISTS perfis_custom (
            perfil_id INTEGER PRIMARY KEY, permissoes TEXT NOT NULL, atualizado_por TEXT,
            atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    # ---- Documentos editáveis (Word/PDF com revisões) ----
    'docs_editaveis': """
        CREATE TABLE IF NOT EXISTS docs_editaveis (
            id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT NOT NULL, tipo TEXT DEFAULT 'outro', pasta TEXT NOT NULL,
            conteudo TEXT, versao INTEGER DEFAULT 1, status TEXT DEFAULT 'rascunho', modelo INTEGER DEFAULT 0,
            origem TEXT, arquivo_original TEXT, gerado_de INTEGER, criado_por TEXT, atualizado_por TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP, atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""",
    'docs_revisoes': """
        CREATE TABLE IF NOT EXISTS docs_revisoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT, documento_id INTEGER NOT NULL, versao INTEGER NOT NULL, conteudo TEXT,
            comentario TEXT, autor TEXT, data TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE (documento_id, versao)
        )""",
    # ---- Tryout (homologação antes da produção) ----
    'tryout_resultados': """
        CREATE TABLE IF NOT EXISTS tryout_resultados (
            id INTEGER PRIMARY KEY AUTOINCREMENT, cenario TEXT NOT NULL, usuario_id INTEGER, usuario_nome TEXT,
            perfil TEXT, status TEXT NOT NULL, comentario TEXT, data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE (cenario, usuario_id)
        )""",
})

# Plano de contas inicial (padrão de entidade religiosa: 3 = receitas, 4 = despesas).
PLANO_CONTAS_PADRAO = [
    ('3.1.01', 'dizimo', 'Dízimos', 'receita', 'Contribuições'),
    ('3.1.02', 'oferta', 'Ofertas', 'receita', 'Contribuições'),
    ('3.1.03', 'oferta_alcada', 'Ofertas alçadas (PIX)', 'receita', 'Contribuições'),
    ('3.1.04', 'campanha', 'Campanhas e votos', 'receita', 'Contribuições'),
    ('3.2.01', 'evento', 'Eventos e congressos', 'receita', 'Outras receitas'),
    ('3.9.99', 'outro', 'Outras receitas', 'receita', 'Outras receitas'),
    ('4.1.01', 'salario', 'Salários e prebendas', 'despesa', 'Pessoal'),
    ('4.1.02', 'servicos_terceiros', 'Serviços de terceiros e autônomos', 'despesa', 'Pessoal'),
    ('4.1.03', 'encargos', 'Encargos sociais (INSS, FGTS)', 'despesa', 'Pessoal'),
    ('4.1.04', 'prebenda', 'Prebenda / sustento pastoral', 'despesa', 'Ministério'),
    ('4.1.05', 'ajuda_custo', 'Ajuda de custo (obreiros e dirigentes)', 'despesa', 'Ministério'),
    ('4.1.06', 'auxilios', 'Auxílios (moradia, transporte, alimentação)', 'despesa', 'Ministério'),
    ('4.2.01', 'aluguel', 'Aluguéis', 'despesa', 'Ocupação'),
    ('4.2.02', 'agua_luz', 'Água, luz e telefone', 'despesa', 'Ocupação'),
    ('4.2.03', 'manutencao', 'Manutenção e conservação', 'despesa', 'Ocupação'),
    ('4.3.01', 'material', 'Material de consumo', 'despesa', 'Materiais'),
    ('4.3.02', 'material_ebd', 'Material da Escola Dominical', 'despesa', 'Materiais'),
    ('4.4.01', 'missoes', 'Missões', 'despesa', 'Obra social e missões'),
    ('4.4.02', 'acao_social', 'Ação social', 'despesa', 'Obra social e missões'),
    ('4.5.01', 'evento', 'Eventos e congressos', 'despesa', 'Eventos'),
    ('4.9.99', 'outro', 'Outras despesas', 'despesa', 'Outras despesas'),
]


def obter_config(chave, padrao=None):
    conn = get_db()
    try:
        row = conn.execute('SELECT valor FROM configuracoes WHERE chave = ?', (chave,)).fetchone()
        return row['valor'] if row else padrao
    finally:
        conn.close()


# Colunas acrescentadas depois (ALTER TABLE preserva os dados existentes)
COLUNAS_NOVAS = {
    'caixa_dias': [('alcadas', 'REAL DEFAULT 0')],
    'banco_movimentos': [('classificado', 'INTEGER DEFAULT 1'), ('acerto_id', 'INTEGER')],
    'usuarios': [('congregacao_id', 'INTEGER'), ('trocar_senha', 'INTEGER DEFAULT 0'), ('falhas_login', 'INTEGER DEFAULT 0'),
                 ('bloqueado_ate', 'TEXT'), ('token_versao', 'INTEGER DEFAULT 0'), ('totp_segredo', 'TEXT'),
                 ('totp_ativo', 'INTEGER DEFAULT 0'), ('ultimo_login', 'TEXT'), ('senha_alterada_em', 'TEXT')],
    'auditoria': [('hash', 'TEXT'), ('hash_anterior', 'TEXT'), ('ip', 'TEXT')],
    'membros': [('sexo', 'TEXT'), ('estado_civil', 'TEXT'), ('conjuge', 'TEXT'), ('data_casamento', 'DATE'),
                ('nome_pai', 'TEXT'), ('nome_mae', 'TEXT'), ('naturalidade', 'TEXT'), ('nacionalidade', 'TEXT'),
                ('cpf', 'TEXT'), ('rg', 'TEXT'), ('profissao', 'TEXT'), ('escolaridade', 'TEXT'), ('celular', 'TEXT'),
                ('bairro', 'TEXT'), ('data_conversao', 'DATE'), ('batismo_espirito', 'TEXT'), ('igreja_origem', 'TEXT'),
                ('forma_admissao', 'TEXT'), ('data_admissao', 'DATE'), ('data_consagracao', 'DATE'), ('ministerios', 'TEXT'),
                ('motivo_saida', 'TEXT'), ('data_saida', 'DATE'), ('consentimento_lgpd', 'INTEGER DEFAULT 0'),
                ('congregacao_id', 'INTEGER'), ('funcao', "TEXT DEFAULT 'Membro'"),
                ('data_batismo', 'DATE'), ('aprovacao', "TEXT DEFAULT 'aprovado'"),
                ('obs_aprovacao', 'TEXT')],
    'financeiro': [('congregacao_id', 'INTEGER'), ('forma', 'TEXT'), ('membro_id', 'INTEGER'),
                   ('caixa_id', 'INTEGER'), ('campanha_id', 'INTEGER'), ('fornecedor_id', 'INTEGER'),
                   ('vencimento', 'DATE'), ('documento', 'TEXT'), ('recorrente_id', 'INTEGER'), ('competencia', 'TEXT'), ('conta_id', 'INTEGER'), ('funcionario_id', 'INTEGER'),
                   ('aprovacao', "TEXT DEFAULT 'aprovado'"), ('obs_aprovacao', 'TEXT')],
    'patrimonio': [('congregacao_id', 'INTEGER'), ('responsavel', 'TEXT'), ('tombo', 'TEXT'), ('marca', 'TEXT'),
                   ('modelo', 'TEXT'), ('numero_serie', 'TEXT'), ('nota_fiscal', 'TEXT'), ('fornecedor_id', 'INTEGER'),
                   ('garantia_ate', 'DATE'), ('seguradora', 'TEXT'), ('apolice', 'TEXT'), ('seguro_ate', 'DATE'),
                   ('vida_util_anos', 'INTEGER'), ('espaco_id', 'INTEGER'),
                   ('aprovacao', "TEXT DEFAULT 'aprovado'"), ('obs_aprovacao', 'TEXT')],
    'congregacoes': [('periodicidade_acerto', "TEXT DEFAULT 'mensal'"), ('dirigente', 'TEXT'), ('bairro', 'TEXT'), ('latitude', 'REAL'),
                     ('longitude', 'REAL'), ('observacoes', 'TEXT'),
                     ('fechamento', "TEXT DEFAULT 'aberto'")],
}

COLUNAS_OBRIGATORIAS = {
    'membros': {'status', 'observacoes', 'data_cadastro'},
    'financeiro': {'data', 'status'},
    'patrimonio': {'nome', 'local', 'valor', 'status', 'observacoes'},
}


def get_db():
    """Abrir conexão com o banco SQLite (linhas acessíveis por nome)."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def rows_to_dicts(rows):
    return [dict(r) for r in rows]


def _colunas(conn, tabela):
    return {r['name'] for r in conn.execute(f'PRAGMA table_info({tabela})')}


def _colunas_do_ddl(ddl):
    """Colunas que o CREATE TABLE define: {nome: (tipo, padrão)} (lido de uma tabela criada em memória)."""
    mem = sqlite3.connect(':memory:')
    try:
        mem.execute(ddl)
        nome = mem.execute("SELECT name FROM sqlite_master WHERE type = 'table'").fetchone()[0]
        return {r[1]: (r[2] or 'TEXT', r[4]) for r in mem.execute(f'PRAGMA table_info({nome})')}
    finally:
        mem.close()


def inicializar_banco():
    """Cria tabelas ausentes e migra tabelas de schema antigo.

    Tabelas antigas vazias são recriadas. Tabelas antigas com dados não são tocadas
    (é lançado um erro explicando o problema, para não perder informação).
    Retorna a lista de tabelas migradas.
    """
    migradas = []
    conn = get_db()
    try:
        for tabela, ddl in SCHEMA.items():
            existentes = _colunas(conn, tabela)
            faltando = COLUNAS_OBRIGATORIAS.get(tabela, set()) - existentes
            if existentes and faltando:
                total = conn.execute(f'SELECT COUNT(*) FROM {tabela}').fetchone()[0]
                if total:
                    raise RuntimeError(
                        f"A tabela '{tabela}' usa um schema antigo (faltam {sorted(faltando)}) "
                        f"e possui {total} registro(s). Faça backup e migre manualmente."
                    )
                conn.execute(f'DROP TABLE {tabela}')
                migradas.append(tabela)
                existentes = set()
            if existentes:
                # Tabela de versão antiga com estrutura diferente: vazia -> recria; com dados -> acrescenta as colunas
                esperadas = _colunas_do_ddl(ddl)
                faltam = [c for c in esperadas if c not in existentes]
                if faltam:
                    if not conn.execute(f'SELECT COUNT(*) FROM {tabela}').fetchone()[0]:
                        conn.execute(f'DROP TABLE {tabela}')
                        migradas.append(tabela)
                    else:
                        for c in faltam:
                            tipo, padrao = esperadas[c]
                            conn.execute(f'ALTER TABLE {tabela} ADD COLUMN {c} {tipo}'
                                         + (f' DEFAULT {padrao}' if padrao is not None else ''))
            conn.execute(ddl)
        for tabela, colunas in COLUNAS_NOVAS.items():
            existentes = _colunas(conn, tabela)
            for nome, tipo in colunas:
                if nome not in existentes:
                    conn.execute(f'ALTER TABLE {tabela} ADD COLUMN {nome} {tipo}')
        from app.seguranca import TRIGGERS_AUDITORIA
        for trig in TRIGGERS_AUDITORIA:
            conn.execute(trig)
        conn.executemany('INSERT OR IGNORE INTO plano_contas (codigo, chave, nome, tipo, grupo) VALUES (?, ?, ?, ?, ?)',
                         PLANO_CONTAS_PADRAO)
        conn.commit()
    finally:
        conn.close()
    return migradas
