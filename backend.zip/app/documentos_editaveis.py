"""Documentos editáveis (atas, contratos, cartas): importação de Word/PDF, limpeza de segurança do HTML
e geração de Word (.docx) — tudo em Python puro (funciona no servidor, no EXE e no simulador web).
"""
import io
import re
import zipfile
from html import escape
from html.parser import HTMLParser

from app.validacao import ErroValidacao

TAGS = {'p', 'br', 'b', 'strong', 'i', 'em', 'u', 's', 'h1', 'h2', 'h3', 'h4', 'ul', 'ol', 'li', 'table', 'thead', 'tbody',
        'tr', 'td', 'th', 'blockquote', 'hr', 'span', 'div', 'sup', 'sub'}
VAZIAS = {'br', 'hr'}
DESCARTAR = {'script', 'style', 'iframe', 'object', 'embed', 'head', 'title', 'svg', 'math', 'noscript', 'template'}
ALINHAR = {'p', 'h1', 'h2', 'h3', 'h4', 'div', 'td', 'th', 'li', 'blockquote'}


class _Limpador(HTMLParser):
    """Mantém só formatação de texto (lista branca). Remove scripts, eventos, links, imagens e estilos perigosos."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.saida, self.pilha, self.pular = [], [], 0

    def handle_starttag(self, tag, attrs):
        if tag in DESCARTAR:
            self.pular += 1
            return
        if self.pular or tag not in TAGS:
            return
        extra = ''
        a = dict(attrs)
        if tag in ('td', 'th'):
            for k in ('colspan', 'rowspan'):
                if str(a.get(k) or '').isdigit():
                    extra += f' {k}="{int(a[k])}"'
        if tag in ALINHAR:
            m = re.search(r'text-align\s*:\s*(left|right|center|justify)', a.get('style') or '', re.I)
            al = (m.group(1) if m else a.get('align') or '').lower()
            if al in ('left', 'right', 'center', 'justify'):
                extra += f' style="text-align:{al}"'
        self.saida.append(f'<{tag}{extra}>')
        if tag not in VAZIAS:
            self.pilha.append(tag)

    def handle_startendtag(self, tag, attrs):
        if tag in VAZIAS and not self.pular:
            self.saida.append(f'<{tag}>')

    def handle_endtag(self, tag):
        if tag in DESCARTAR:
            self.pular = max(0, self.pular - 1)
            return
        if self.pular or tag not in TAGS or tag in VAZIAS or tag not in self.pilha:
            return
        while self.pilha:
            t = self.pilha.pop()
            self.saida.append(f'</{t}>')
            if t == tag:
                break

    def handle_data(self, data):
        if not self.pular:
            self.saida.append(escape(data, quote=False))

    def resultado(self):
        return ''.join(self.saida) + ''.join(f'</{t}>' for t in reversed(self.pilha))


def limpar_html(html):
    lp = _Limpador()
    lp.feed(html or '')
    lp.close()
    return lp.resultado().strip()


def texto_puro(html):
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', html or '')).strip()


def _paragrafos(texto):
    blocos = [b.strip() for b in re.split(r'\n\s*\n', texto.replace('\r', '')) if b.strip()]
    return ''.join(f'<p>{escape(" ".join(l.strip() for l in b.splitlines()))}</p>' for b in blocos)


def importar(nome, dados):
    """Arquivo enviado -> HTML editável (já limpo)."""
    ext = nome.lower().rsplit('.', 1)[-1] if '.' in nome else ''
    if ext == 'docx':
        import mammoth
        try:
            html = mammoth.convert_to_html(io.BytesIO(dados)).value
        except Exception:
            raise ErroValidacao('Não foi possível ler o arquivo do Word. Abra no Word e salve de novo como .docx.')
    elif ext == 'pdf':
        from pypdf import PdfReader
        try:
            leitor = PdfReader(io.BytesIO(dados))
            texto = '\n\n'.join((p.extract_text() or '') for p in leitor.pages)
        except Exception:
            raise ErroValidacao('Não foi possível ler o PDF (pode estar protegido por senha).')
        if len(texto.strip()) < 20:
            raise ErroValidacao('Este PDF é uma imagem (documento escaneado): o texto não pode ser lido automaticamente. '
                                'Guarde-o no Arquivo digital ou crie o documento em branco e digite o texto.')
        html = _paragrafos(texto)
    elif ext in ('txt',):
        html = _paragrafos(dados.decode('utf-8', 'replace'))
    elif ext in ('html', 'htm'):
        html = dados.decode('utf-8', 'replace')
    elif ext == 'doc':
        raise ErroValidacao('Arquivo do Word antigo (.doc): abra no Word e use "Salvar como" .docx.')
    else:
        raise ErroValidacao('Envie um arquivo do Word (.docx), PDF, ou texto (.txt).')
    html = limpar_html(html)
    if not texto_puro(html):
        raise ErroValidacao('O arquivo não tem texto para editar.')
    return html


# ------------------------------------------------------------------ Word (.docx)
def _x(t):
    return escape(t, quote=False)


class _ParaDocx(HTMLParser):
    TAMANHO = {'h1': 32, 'h2': 28, 'h3': 26, 'h4': 24}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.corpo, self.runs, self.fmt, self.listas = [], [], {'b': 0, 'i': 0, 'u': 0, 's': 0}, []
        self.par = None            # (tipo, alinhamento, prefixo)
        self.tabela = None         # [[ [paragrafos da célula] ]]

    def _alvo(self):
        return self.tabela[-1][-1] if self.tabela is not None and self.tabela and self.tabela[-1] else self.corpo

    def _abrir(self, tipo='p', al=None, prefixo=''):
        self._fechar()
        self.par = (tipo, al, prefixo)
        if prefixo:
            self.runs.append(('t', prefixo, dict(self.fmt)))

    def _fechar(self):
        if self.par is None and not self.runs:
            return
        tipo, al, _ = self.par or ('p', None, '')
        ppr = (f'<w:jc w:val="{ {"justify": "both"}.get(al, al)}"/>' if al else '') + \
            ('<w:spacing w:before="240" w:after="120"/>' if tipo in self.TAMANHO else '<w:spacing w:after="120"/>')
        xml = []
        for kind, txt, f in self.runs:
            rpr = ('<w:b/>' if f['b'] or tipo in self.TAMANHO else '') + ('<w:i/>' if f['i'] else '') + \
                  ('<w:u w:val="single"/>' if f['u'] else '') + ('<w:strike/>' if f['s'] else '') + \
                  (f'<w:sz w:val="{self.TAMANHO[tipo]}"/>' if tipo in self.TAMANHO else '')
            corpo = '<w:br/>' if kind == 'br' else f'<w:t xml:space="preserve">{_x(txt)}</w:t>'
            xml.append(f'<w:r><w:rPr>{rpr}</w:rPr>{corpo}</w:r>')
        self._alvo().append(f'<w:p><w:pPr>{ppr}</w:pPr>{"".join(xml)}</w:p>')
        self.par, self.runs = None, []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        m = re.search(r'text-align:(\w+)', a.get('style') or '')
        al = m.group(1) if m else None
        if tag in ('b', 'strong'):
            self.fmt['b'] += 1
        elif tag in ('i', 'em'):
            self.fmt['i'] += 1
        elif tag == 'u':
            self.fmt['u'] += 1
        elif tag == 's':
            self.fmt['s'] += 1
        elif tag == 'br':
            if self.par is None:
                self._abrir()
            self.runs.append(('br', '', dict(self.fmt)))
        elif tag in ('ul', 'ol'):
            self._fechar()
            self.listas.append([tag, 0])
        elif tag == 'li':
            prefixo = '• '
            if self.listas:
                self.listas[-1][1] += 1
                if self.listas[-1][0] == 'ol':
                    prefixo = f'{self.listas[-1][1]}. '
            self._abrir('li', al, '    ' * (len(self.listas) - 1) + prefixo)
        elif tag in ('p', 'div', 'blockquote', 'h1', 'h2', 'h3', 'h4'):
            self._abrir(tag if tag in self.TAMANHO else 'p', al)
        elif tag == 'table':
            self._fechar()
            self.tabela = []
        elif tag == 'tr' and self.tabela is not None:
            self.tabela.append([])
        elif tag in ('td', 'th') and self.tabela is not None:
            self._fechar()
            if not self.tabela:
                self.tabela.append([])
            self.tabela[-1].append([])
            if tag == 'th':
                self.fmt['b'] += 1
        elif tag == 'hr':
            self._fechar()
            self.corpo.append('<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="999999"/></w:pBdr></w:pPr></w:p>')

    def handle_endtag(self, tag):
        if tag in ('b', 'strong'):
            self.fmt['b'] = max(0, self.fmt['b'] - 1)
        elif tag in ('i', 'em'):
            self.fmt['i'] = max(0, self.fmt['i'] - 1)
        elif tag == 'u':
            self.fmt['u'] = max(0, self.fmt['u'] - 1)
        elif tag == 's':
            self.fmt['s'] = max(0, self.fmt['s'] - 1)
        elif tag in ('p', 'div', 'blockquote', 'h1', 'h2', 'h3', 'h4', 'li'):
            self._fechar()
        elif tag in ('ul', 'ol') and self.listas:
            self._fechar()
            self.listas.pop()
        elif tag in ('td', 'th') and self.tabela is not None:
            self._fechar()
            if tag == 'th':
                self.fmt['b'] = max(0, self.fmt['b'] - 1)
        elif tag == 'table' and self.tabela is not None:
            self._fechar()
            linhas = self.tabela
            self.tabela = None
            borda = ''.join(f'<w:{b} w:val="single" w:sz="4" w:space="0" w:color="999999"/>' for b in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'))
            xml = [f'<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/><w:tblBorders>{borda}</w:tblBorders></w:tblPr>']
            for linha in linhas:
                xml.append('<w:tr>' + ''.join(f'<w:tc><w:tcPr/>{"".join(c) or "<w:p/>"}</w:tc>' for c in linha) + '</w:tr>')
            xml.append('</w:tbl>')
            self.corpo.append(''.join(xml))

    def handle_data(self, data):
        if not data.strip() and self.par is None:
            return
        if self.par is None:
            self._abrir()
        self.runs.append(('t', re.sub(r'\s+', ' ', data), dict(self.fmt)))


def gerar_docx(titulo, html, cabecalho='Assembleia de Deus Ministério do Belém – São José dos Campos'):
    conv = _ParaDocx()
    conv.feed(f'<p style="text-align:center"><b>{escape(cabecalho)}</b></p><h2 style="text-align:center">{escape(titulo)}</h2>' + (html or ''))
    conv.close()
    conv._fechar()
    W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
    documento = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {W}><w:body>{"".join(conv.corpo)}'
                 '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1418" w:right="1418" w:bottom="1418" w:left="1701" '
                 'w:header="709" w:footer="709" w:gutter="0"/></w:sectPr></w:body></w:document>')
    estilos = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles {W}><w:docDefaults><w:rPrDefault><w:rPr>'
               '<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:sz w:val="24"/><w:lang w:val="pt-BR"/></w:rPr></w:rPrDefault>'
               '</w:docDefaults></w:styles>')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
                   '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
                   '</Types>')
        z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
                   '</Relationships>')
        z.writestr('word/_rels/document.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                   '</Relationships>')
        z.writestr('word/document.xml', documento)
        z.writestr('word/styles.xml', estilos)
    return buf.getvalue()
