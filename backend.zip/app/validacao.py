"""Validação simples de payloads JSON."""
from datetime import date


class ErroValidacao(Exception):
    pass


def texto(data, campo, obrigatorio=False, max_len=500):
    valor = data.get(campo)
    valor = '' if valor is None else str(valor).strip()
    if obrigatorio and not valor:
        raise ErroValidacao(f"O campo '{campo}' é obrigatório")
    if len(valor) > max_len:
        raise ErroValidacao(f"O campo '{campo}' excede {max_len} caracteres")
    return valor


def opcao(data, campo, opcoes, padrao=None):
    valor = (data.get(campo) or padrao)
    if valor not in opcoes:
        raise ErroValidacao(f"Valor inválido para '{campo}'. Use: {', '.join(opcoes)}")
    return valor


def numero(data, campo, obrigatorio=False, minimo=None, positivo=False):
    valor = data.get(campo)
    if valor in (None, ''):
        if obrigatorio:
            raise ErroValidacao(f"O campo '{campo}' é obrigatório")
        return 0.0
    try:
        valor = float(valor)
    except (TypeError, ValueError):
        raise ErroValidacao(f"O campo '{campo}' deve ser numérico")
    if positivo and valor <= 0:
        raise ErroValidacao(f"O campo '{campo}' deve ser maior que zero")
    if minimo is not None and valor < minimo:
        raise ErroValidacao(f"O campo '{campo}' deve ser no mínimo {minimo}")
    return round(valor, 2)


def data_iso(data, campo, obrigatorio=False):
    valor = data.get(campo)
    if not valor:
        if obrigatorio:
            raise ErroValidacao(f"O campo '{campo}' é obrigatório")
        return None
    try:
        return date.fromisoformat(str(valor)[:10]).isoformat()
    except ValueError:
        raise ErroValidacao(f"O campo '{campo}' deve ser uma data no formato AAAA-MM-DD")


def inteiro(data, campo, obrigatorio=False, minimo=None):
    """Inteiro opcional (ex.: chaves como congregacao_id). Vazio vira None."""
    valor = data.get(campo)
    if valor in (None, ''):
        if obrigatorio:
            raise ErroValidacao(f"O campo '{campo}' é obrigatório")
        return None
    try:
        valor = int(valor)
    except (TypeError, ValueError):
        raise ErroValidacao(f"O campo '{campo}' deve ser um número inteiro")
    if minimo is not None and valor < minimo:
        raise ErroValidacao(f"O campo '{campo}' deve ser no mínimo {minimo}")
    return valor


def brl(valor):
    """Formata em reais no padrão brasileiro: 1234.5 -> 'R$ 1.234,50'."""
    return 'R$ ' + f'{valor:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')


def cpf(data, campo='cpf'):
    """CPF opcional; se informado, confere os dígitos verificadores. Devolve no formato 000.000.000-00."""
    v = ''.join(c for c in str(data.get(campo) or '') if c.isdigit())
    if not v:
        return ''
    if len(v) != 11 or v == v[0] * 11:
        raise ErroValidacao('CPF inválido')
    for n in (9, 10):
        soma = sum(int(v[i]) * (n + 1 - i) for i in range(n))
        if (soma * 10 % 11) % 10 != int(v[n]):
            raise ErroValidacao('CPF inválido (dígitos verificadores não conferem)')
    return f'{v[:3]}.{v[3:6]}.{v[6:9]}-{v[9:]}'
