"""Intranet AD Belém SJC: backend (Flask + SQLite)."""
