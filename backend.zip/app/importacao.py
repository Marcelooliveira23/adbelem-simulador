"""Importação de cadastros de planilhas e bancos antigos, sem cadastro em dobro.

Fontes : Excel (.xlsx), CSV, cópia de banco MySQL (.sql do phpMyAdmin/mysqldump), banco SQLite (.db/.sqlite)
         e conexão direta a um servidor MySQL.
Destinos: membros, patrimônio (bens), fornecedores e funcionários.
Fluxo  : ler (guarda as linhas num arquivo temporário) -> mapear colunas (sugestão automática) ->
         analisar (novos, duplicados, inválidos) -> executar (backup antes; duplicados ignorados ou só completados).
"""
import csv
import io
import json
import os
import re
import secrets
import sqlite3
import tempfile
import time
import unicodedata
from datetime import date, datetime, timedelta
from decimal import Decimal

from app.config import DATA_DIR
from app.validacao import ErroValidacao

PASTA = os.path.join(DATA_DIR, 'importacoes')
LIMITE_LINHAS = 50000


def norm(v):
    """'  José da Silva ' -> 'jose da silva' (para comparar nomes e cabeçalhos)."""
    s = unicodedata.normalize('NFKD', str(v or '')).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]+', ' ', s)).strip()


def digitos(v):
    return re.sub(r'\D', '', str(v or ''))


def _valor_simples(v):
    if v is None:
        return None
    if isinstance(v, (bytes, bytearray)):
        return v.decode('utf-8', 'replace')
    if isinstance(v, datetime):
        return v.date().isoformat() if not (v.hour or v.minute) else v.isoformat(sep=' ', timespec='minutes')
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, Decimal):
        return float(v)
    return v


def _tabela(colunas, linhas):
    colunas = [str(c).strip() if c not in (None, '') else f'Coluna {i + 1}' for i, c in enumerate(colunas)]
    vistos = {}
    for i, c in enumerate(colunas):            # cabeçalhos repetidos ganham sufixo
        if c in vistos:
            vistos[c] += 1
            colunas[i] = f'{c} ({vistos[c]})'
        else:
            vistos[c] = 1
    out = []
    for l in linhas[:LIMITE_LINHAS]:
        l = [_valor_simples(x) for x in l]
        if any(x not in (None, '') for x in l):
            out.append(dict(zip(colunas, list(l) + [None] * (len(colunas) - len(l)))))
    return {'colunas': colunas, 'linhas': out}


# ------------------------------------------------------------------ leitores
def ler_csv(dados):
    for cod in ('utf-8-sig', 'cp1252', 'latin-1'):
        try:
            texto = dados.decode(cod)
            break
        except UnicodeDecodeError:
            continue
    amostra = texto[:5000]
    sep = max((';', ',', '\t', '|'), key=amostra.count)
    linhas = list(csv.reader(io.StringIO(texto), delimiter=sep))
    if not linhas:
        raise ErroValidacao('Planilha vazia')
    return {'Planilha': _tabela(linhas[0], linhas[1:])}


def ler_xlsx(dados):
    import openpyxl
    try:
        wb = openpyxl.load_workbook(io.BytesIO(dados), read_only=True, data_only=True)
    except Exception:
        raise ErroValidacao('Não foi possível abrir a planilha. Salve como .xlsx ou .csv e tente de novo.')
    out = {}
    for ws in wb.worksheets:
        linhas = [list(r) for r in ws.iter_rows(values_only=True)]
        while linhas and not any(x not in (None, '') for x in linhas[0]):
            linhas.pop(0)          # pula linhas em branco antes do cabeçalho
        if linhas:
            out[ws.title] = _tabela(linhas[0], linhas[1:])
    wb.close()
    if not out:
        raise ErroValidacao('A planilha não tem dados')
    return out


def _valores_sql(s, i):
    """Lê '(...),(...);' de um INSERT do MySQL, respeitando aspas e escapes. Devolve (linhas, posição)."""
    linhas, n = [], len(s)
    while i < n:
        c = s[i]
        if c in ' \t\r\n,':
            i += 1
            continue
        if c == ';':
            return linhas, i + 1
        if c != '(':
            return linhas, i
        i += 1
        linha = []
        while i < n:
            while s[i] in ' \t\r\n':
                i += 1
            if s[i] in "'\"":
                q, i, buf = s[i], i + 1, []
                while i < n:
                    ch = s[i]
                    if ch == '\\' and i + 1 < n:
                        buf.append({'n': '\n', 'r': '\r', 't': '\t', '0': '\0'}.get(s[i + 1], s[i + 1]))
                        i += 2
                        continue
                    if ch == q:
                        if i + 1 < n and s[i + 1] == q:
                            buf.append(q)
                            i += 2
                            continue
                        i += 1
                        break
                    buf.append(ch)
                    i += 1
                linha.append(''.join(buf))
                while s[i] in ' \t\r\n':
                    i += 1
            else:
                j = i
                while s[i] not in ',)':
                    i += 1
                tok = s[j:i].strip()
                linha.append(None if tok.upper() == 'NULL' else tok)
            if s[i] == ',':
                i += 1
                continue
            i += 1          # ')'
            break
        linhas.append(linha)
    return linhas, i


def ler_sql(dados):
    texto = dados.decode('utf-8', 'replace')
    colunas, tabelas = {}, {}
    nome_tab = None
    for linha in texto.splitlines():          # colunas de cada CREATE TABLE
        m = re.match(r'\s*CREATE TABLE\s+(?:IF NOT EXISTS\s+)?[`"\[]?(\w+)[`"\]]?', linha, re.I)
        if m:
            nome_tab = m.group(1)
            colunas[nome_tab] = []
            continue
        if nome_tab:
            if linha.strip().startswith(')'):
                nome_tab = None
                continue
            m = re.match(r'\s*[`"\[]?(\w+)[`"\]]?\s+\w+', linha)
            if m and m.group(1).upper() not in ('PRIMARY', 'KEY', 'UNIQUE', 'CONSTRAINT', 'INDEX', 'FOREIGN', 'FULLTEXT', 'CHECK'):
                colunas[nome_tab].append(m.group(1))
    for m in re.finditer(r'INSERT\s+(?:IGNORE\s+)?INTO\s+[`"\[]?(\w+)[`"\]]?\s*(\(([^)]*)\))?\s*VALUES\s*', texto, re.I):
        tab = m.group(1)
        cols = [c.strip(' `"[]') for c in m.group(3).split(',')] if m.group(3) else colunas.get(tab, [])
        linhas, _ = _valores_sql(texto, m.end())
        t = tabelas.setdefault(tab, {'colunas': cols or [f'Coluna {i + 1}' for i in range(len(linhas[0]) if linhas else 0)], 'linhas': []})
        t['linhas'].extend(linhas)
    if not tabelas:
        raise ErroValidacao('Nenhum INSERT encontrado no arquivo .sql (exporte com os dados, não só a estrutura)')
    return {k: _tabela(v['colunas'], v['linhas']) for k, v in tabelas.items()}


def ler_sqlite(dados):
    fd, caminho = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    try:
        with open(caminho, 'wb') as f:
            f.write(dados)
        conn = sqlite3.connect(caminho)
        try:
            nomes = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")]
            out = {}
            for n in nomes:
                cur = conn.execute(f'SELECT * FROM "{n}" LIMIT {LIMITE_LINHAS}')
                out[n] = _tabela([d[0] for d in cur.description], [list(r) for r in cur.fetchall()])
            return out
        except sqlite3.DatabaseError:
            raise ErroValidacao('O arquivo não é um banco SQLite válido')
        finally:
            conn.close()
    finally:
        os.remove(caminho)


def mysql_conectar(p):
    import pymysql
    try:
        return pymysql.connect(host=p.get('host') or 'localhost', port=int(p.get('porta') or 3306), user=p.get('usuario') or 'root',
                               password=p.get('senha') or '', database=p.get('banco'), charset='utf8mb4',
                               connect_timeout=8, read_timeout=120)
    except Exception as e:
        raise ErroValidacao(f'Não foi possível conectar ao MySQL: {e}')


def mysql_tabelas(p):
    conn = mysql_conectar(p)
    try:
        with conn.cursor() as c:
            c.execute('SELECT table_name, table_rows FROM information_schema.tables WHERE table_schema = %s ORDER BY table_name',
                      (p.get('banco'),))
            return [{'nome': r[0], 'linhas': r[1]} for r in c.fetchall()]
    finally:
        conn.close()


def mysql_ler(p, tabela):
    if tabela not in {t['nome'] for t in mysql_tabelas(p)}:
        raise ErroValidacao('Tabela não encontrada no banco')
    conn = mysql_conectar(p)
    try:
        with conn.cursor() as c:
            c.execute(f'SELECT * FROM `{tabela}` LIMIT {LIMITE_LINHAS}')
            return {tabela: _tabela([d[0] for d in c.description], [list(r) for r in c.fetchall()])}
    finally:
        conn.close()


def ler_arquivo(nome, dados):
    ext = os.path.splitext(nome.lower())[1]
    if ext in ('.xlsx', '.xlsm'):
        return ler_xlsx(dados)
    if ext in ('.csv', '.txt'):
        return ler_csv(dados)
    if ext == '.sql':
        return ler_sql(dados)
    if ext in ('.db', '.sqlite', '.sqlite3'):
        return ler_sqlite(dados)
    if ext == '.xls':
        raise ErroValidacao('Planilha do Excel antigo (.xls): abra no Excel e use "Salvar como" .xlsx ou .csv')
    raise ErroValidacao('Formato não suportado. Use .xlsx, .csv, .sql (MySQL) ou .db (SQLite)')


# ------------------------------------------------------------------ armazenamento temporário
def guardar(fonte, tabelas):
    os.makedirs(PASTA, exist_ok=True)
    for f in os.listdir(PASTA):                 # limpa leituras com mais de 24 h
        c = os.path.join(PASTA, f)
        if time.time() - os.path.getmtime(c) > 86400:
            try:
                os.remove(c)
            except OSError:
                pass
    token = secrets.token_urlsafe(16)
    with open(os.path.join(PASTA, token + '.json'), 'w', encoding='utf-8') as f:
        json.dump({'fonte': fonte, 'tabelas': tabelas}, f, ensure_ascii=False, default=str)
    return token


def carregar(token):
    if not re.fullmatch(r'[\w-]{10,40}', token or ''):
        raise ErroValidacao('Leitura inválida')
    caminho = os.path.join(PASTA, token + '.json')
    if not os.path.isfile(caminho):
        raise ErroValidacao('A leitura expirou. Envie o arquivo de novo.')
    with open(caminho, encoding='utf-8') as f:
        return json.load(f)


def descartar(token):
    try:
        os.remove(os.path.join(PASTA, token + '.json'))
    except OSError:
        pass


# ------------------------------------------------------------------ normalização de valores
def data_br(v):
    if v in (None, ''):
        return None
    if isinstance(v, (int, float)) and 1000 < float(v) < 80000:          # número de série do Excel
        return (date(1899, 12, 30) + timedelta(days=int(float(v)))).isoformat()
    s = str(v).strip()
    if s.startswith('0000'):
        return None
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d-%m-%Y', '%d.%m.%Y', '%d/%m/%y', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M',
                '%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M', '%Y/%m/%d'):
        try:
            return datetime.strptime(s, fmt).date().isoformat()
        except ValueError:
            continue
    raise ErroValidacao(f'data "{s}" não reconhecida')


def dinheiro(v):
    if v in (None, ''):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = re.sub(r'[^\d,.-]', '', str(v))
    if ',' in s and '.' in s:
        s = s.replace('.', '').replace(',', '.') if s.rfind(',') > s.rfind('.') else s.replace(',', '')
    elif ',' in s:
        s = s.replace(',', '.')
    try:
        return float(s)
    except ValueError:
        raise ErroValidacao(f'valor "{v}" não reconhecido')


def por_sinonimo(v, tabela, padrao=None):
    """Mapeia um texto livre para um valor do sistema por palavras-chave ({valor: [palavras]})."""
    n = norm(v)
    if not n:
        return padrao
    frase = f' {n} '
    for valor, palavras in tabela.items():          # 1º: palavra inteira (abreviações como "Pr", "Pb" só valem assim)
        if n == norm(valor) or any(p == n or f' {p} ' in frase for p in palavras):
            return valor
    for valor, palavras in tabela.items():          # 2º: começo de palavra, só para termos com 4+ letras ("cadeiras" -> cadeira)
        if any(len(p) >= 4 and (n.startswith(p) or f' {p}' in frase) for p in palavras):
            return valor
    return padrao


SEXO = {'M': ['m', 'masc', 'masculino', 'h', 'homem'], 'F': ['f', 'fem', 'feminino', 'mulher']}
STATUS_MEMBRO = {'ativo': ['ativo', 'ativa', 'a', '1', 'sim', 's', 'true', 'regular', 'comungante'],
                 'inativo': ['inativo', 'inativa', 'desligado', 'excluido', 'falecido', 'transferido', '0', 'nao', 'n', 'false', 'afastado'],
                 'visitante': ['visitante', 'congregado', 'frequentador']}
ESTADO_CIVIL = {'solteiro': ['solteiro', 'solteira'], 'casado': ['casado', 'casada'], 'divorciado': ['divorciado', 'divorciada', 'separado', 'separada'],
                'viuvo': ['viuvo', 'viuva'], 'uniao_estavel': ['uniao estavel', 'amasiado', 'amasiada', 'convivente']}
FUNCOES = {'Pastor': ['pastor', 'pr'], 'Evangelista': ['evangelista', 'ev'], 'Presbítero': ['presbitero', 'pb', 'presb'],
           'Diácono': ['diacono', 'dc'], 'Diaconisa': ['diaconisa'], 'Missionário(a)': ['missionario', 'missionaria', 'miss'],
           'Cooperador(a)': ['cooperador', 'cooperadora', 'coop'], 'Obreiro': ['obreiro', 'obreira'], 'Membro': ['membro']}
CATEGORIA_BEM = {'imovel': ['imovel', 'terreno', 'predio', 'casa', 'templo', 'salao', 'edificacao'],
                 'veiculo': ['veiculo', 'carro', 'van', 'onibus', 'microonibus', 'moto', 'automovel'],
                 'instrumento': ['instrumento', 'teclado', 'bateria', 'violao', 'guitarra', 'baixo', 'piano', 'orgao', 'sax', 'trompete', 'violino'],
                 'eletronico': ['eletronico', 'som', 'mesa de som', 'caixa de som', 'microfone', 'projetor', 'computador', 'notebook',
                                'informatica', 'impressora', 'tv', 'televisao', 'ar condicionado', 'equipamento', 'amplificador'],
                 'movel': ['movel', 'moveis', 'mobiliario', 'cadeira', 'mesa', 'banco', 'armario', 'estante', 'pulpito', 'sofa']}
STATUS_BEM = {'bom': ['bom', 'otimo', 'novo', 'regular', 'ok', 'usado', 'em uso', 'ativo'],
              'manutencao': ['manutencao', 'conserto', 'quebrado', 'defeito', 'avariado'],
              'emprestado': ['emprestado', 'cedido'], 'descartado': ['descartado', 'baixado', 'baixa', 'vendido', 'doado', 'furtado', 'perdido']}
TIPO_FUNC = {'clt': ['clt', 'registrado', 'carteira', 'efetivo', 'funcionario'], 'temporario': ['temporario', 'temporaria', 'contrato'],
             'autonomo': ['autonomo', 'rpa', 'freelancer', 'free lancer', 'diarista'], 'prestador': ['prestador', 'empresa', 'mei', 'pj', 'terceirizado'],
             'estagiario': ['estagio', 'estagiario', 'estagiaria'], 'pastoral': ['pastoral', 'prebenda', 'pastor', 'sustento pastoral'],
             'obreiro': ['obreiro', 'dirigente', 'ajuda de custo', 'evangelista', 'presbitero', 'diacono', 'missionario']}

# ------------------------------------------------------------------ destinos: campos e sinônimos dos cabeçalhos
DESTINOS = {
    'membros': {'rotulo': 'Membros (Secretaria)', 'permissao': 'membros.criar', 'tabela': 'membros', 'campos': [
        ('nome', 'Nome completo', ['nome', 'nome completo', 'membro', 'nome do membro']),
        ('cpf', 'CPF', ['cpf', 'cpf membro']), ('rg', 'RG', ['rg', 'identidade', 'documento']),
        ('data_nascimento', 'Nascimento', ['nascimento', 'data nascimento', 'dt nasc', 'data de nascimento', 'nasc', 'aniversario']),
        ('sexo', 'Sexo', ['sexo', 'genero']), ('estado_civil', 'Estado civil', ['estado civil', 'civil']),
        ('conjuge', 'Cônjuge', ['conjuge', 'esposo', 'esposa', 'marido']),
        ('nome_pai', 'Pai', ['pai', 'nome do pai', 'filiacao pai']), ('nome_mae', 'Mãe', ['mae', 'nome da mae', 'filiacao mae']),
        ('celular', 'Celular', ['celular', 'whatsapp', 'whats', 'cel', 'fone celular']), ('telefone', 'Telefone', ['telefone', 'fone', 'tel']),
        ('email', 'E-mail', ['email', 'e mail']), ('endereco', 'Endereço', ['endereco', 'logradouro', 'rua']),
        ('bairro', 'Bairro', ['bairro']), ('cidade', 'Cidade', ['cidade', 'municipio']), ('estado', 'UF', ['uf', 'estado']),
        ('cep', 'CEP', ['cep']), ('profissao', 'Profissão', ['profissao', 'ocupacao']),
        ('data_batismo', 'Batismo nas águas', ['batismo', 'data batismo', 'batismo aguas', 'dt batismo']),
        ('data_conversao', 'Conversão', ['conversao', 'data conversao']), ('data_admissao', 'Admissão', ['admissao', 'data admissao', 'recepcao']),
        ('funcao', 'Função / cargo', ['funcao', 'cargo', 'cargo eclesiastico', 'ministerio']),
        ('status', 'Situação', ['situacao', 'status', 'ativo']), ('congregacao', 'Congregação', ['congregacao', 'igreja', 'unidade', 'local']),
        ('igreja_origem', 'Igreja de origem', ['igreja origem', 'procedencia']), ('observacoes', 'Observações', ['observacoes', 'obs', 'observacao'])]},
    'patrimonio': {'rotulo': 'Bens do patrimônio', 'permissao': 'patrimonio.criar', 'tabela': 'patrimonio', 'campos': [
        ('nome', 'Descrição do bem', ['descricao', 'bem', 'item', 'nome', 'produto', 'patrimonio']),
        ('tombo', 'Nº de tombo / etiqueta', ['tombo', 'patrimonio numero', 'n patrimonio', 'plaqueta', 'etiqueta', 'codigo', 'cod']),
        ('categoria', 'Categoria', ['categoria', 'tipo', 'grupo', 'classe']), ('local', 'Local', ['local', 'localizacao', 'sala', 'setor', 'ambiente']),
        ('congregacao', 'Congregação', ['congregacao', 'unidade', 'igreja']), ('valor', 'Valor', ['valor', 'preco', 'valor aquisicao', 'custo']),
        ('data_aquisicao', 'Data de aquisição', ['aquisicao', 'data aquisicao', 'data compra', 'compra', 'data']),
        ('status', 'Estado', ['estado', 'status', 'situacao', 'conservacao']), ('responsavel', 'Responsável', ['responsavel']),
        ('marca', 'Marca', ['marca', 'fabricante']), ('modelo', 'Modelo', ['modelo']), ('numero_serie', 'Nº de série', ['serie', 'numero serie', 'n serie', 'serial']),
        ('nota_fiscal', 'Nota fiscal', ['nota fiscal', 'nf', 'nfe']), ('observacoes', 'Observações', ['observacoes', 'obs'])]},
    'fornecedores': {'rotulo': 'Fornecedores (Tesouraria)', 'permissao': 'tesouraria.criar', 'tabela': 'fornecedores', 'campos': [
        ('nome', 'Nome / razão social', ['nome', 'razao social', 'fornecedor', 'empresa', 'nome fantasia']),
        ('documento', 'CNPJ / CPF', ['cnpj', 'cpf', 'documento', 'cnpj cpf']), ('ramo', 'Ramo', ['ramo', 'atividade', 'categoria', 'segmento']),
        ('contato', 'Contato', ['contato', 'responsavel']), ('telefone', 'Telefone', ['telefone', 'fone', 'celular', 'whatsapp']),
        ('email', 'E-mail', ['email', 'e mail']), ('pix', 'Chave PIX', ['pix', 'chave pix']), ('banco', 'Dados bancários', ['banco', 'conta', 'agencia']),
        ('endereco', 'Endereço', ['endereco']), ('observacoes', 'Observações', ['observacoes', 'obs'])]},
    'funcionarios': {'rotulo': 'Funcionários e prestadores (Tesouraria)', 'permissao': 'tesouraria.criar', 'tabela': 'funcionarios', 'campos': [
        ('nome', 'Nome', ['nome', 'funcionario', 'colaborador', 'nome completo']), ('cargo', 'Cargo / posição', ['cargo', 'funcao', 'posicao', 'ocupacao']),
        ('tipo', 'Vínculo', ['tipo', 'vinculo', 'regime', 'contrato']), ('cpf', 'CPF', ['cpf']), ('telefone', 'Telefone', ['telefone', 'celular', 'fone']),
        ('email', 'E-mail', ['email']), ('data_admissao', 'Admissão', ['admissao', 'data admissao', 'inicio']),
        ('remuneracao', 'Remuneração', ['salario', 'remuneracao', 'valor', 'pagamento']), ('pix', 'Chave PIX', ['pix', 'chave pix']),
        ('banco', 'Dados bancários', ['banco', 'conta']), ('observacoes', 'Observações', ['observacoes', 'obs'])]},
}


def sugerir_mapa(destino, colunas):
    """Para cada campo do destino, a coluna da origem com cabeçalho mais parecido."""
    mapa, usadas = {}, set()
    normal = {c: norm(c) for c in colunas}
    for campo, _rot, sinonimos in DESTINOS[destino]['campos']:
        alvo = [norm(s) for s in [campo.replace('_', ' ')] + sinonimos]
        escolha = next((c for c in colunas if c not in usadas and normal[c] in alvo), None)
        if not escolha:
            escolha = next((c for c in colunas if c not in usadas and any(a and (a in normal[c].split() or normal[c].startswith(a))
                                                                          for a in alvo if len(a) > 3)), None)
        if escolha:
            mapa[campo] = escolha
            usadas.add(escolha)
    return mapa
